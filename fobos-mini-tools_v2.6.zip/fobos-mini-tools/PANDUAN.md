# Panduan Operasi Fobos Mini v2 — dari Persiapan sampai Demo

Panduan ini memandu anda menyiapkan Fobos Mini sampai demo. Dalam demo itu posisi GPS tampil di peta OpenStreetMap, sementara raw GNSS dan IMU direkam dan dapat diunduh.

> **Broker cloud = flespi.** Panduan langkah demi langkah untuk pemula (membuat akun, token, uji, dan mengisi ESP32 serta web app) ada di **`PANDUAN_FLESPI.md`**. Kerjakan panduan itu sebelum bagian 4–7 di bawah.

Gambar rujukan:
- `gambar/Pengkabelan_Fobos_Mini.png` (pengkabelan v2)
- `gambar/Alur_Data_Fobos_Mini.png` (alur data)

Versi `.drawio` dari kedua gambar dapat disunting di diagrams.net.

---

## 0. Gambaran sistem (v2)

ZED-F9P **sudah diatur lewat u-center**: jenis pesan, frekuensi, dan baud. Firmware ESP32 **tidak mengubah** konfigurasi penerima. Tugasnya hanya membaca, meneruskan, menyimpan, dan mengirim data.

| Jalur | Isi | Ke mana |
|---|---|---|
| UART1 ZED → ESP32 (Serial2, 230400) | NMEA GGA/RMC/GST + UBX NAV-PVT | Diparse menjadi posisi dan status FIX/FLOAT/DGNSS/SINGLE. Hasilnya ditulis ke SD `_pos.csv` dan dikirim ke web 10 Hz. |
| ESP32 → UART1 ZED | RTCM Ina-CORS (NTRIP) | Koreksi RTK |
| UART2 ZED → ESP32 (Serial1, 460800) | UBX RAWX + SFRBX | Disalin **apa adanya** ke SD `_raw.ubx`. Saat Record, RAWX 1 Hz + SFRBX juga dikirim ke web. |
| ICM-20948 (I2C) | Akselerometer + giroskop 200 Hz | SD `_imu.csv` (200 Hz). Web menerima ringkasan **5 Hz**: rata-rata 200 ms ditambah indeks getaran per detik. |
| TIMEPULSE → GPIO34 | 1 pulsa per detik | Stempel waktu GPS untuk IMU (dibutuhkan KF-GINS) |

**Kartu SD**
- Merekam **terus sejak menyala**, satu set file baru setiap menyala, termasuk setelah upload firmware. File lama tidak pernah ditimpa.
- Nama file memakai nomor urut, misalnya `F0007_raw.ubx`, `F0007_pos.csv`, `F0007_imu.csv`, `F0007_event.csv`.

**Tombol Record di web**
- Browser merekam posisi, IMU 5 Hz, dan UBX.
- Saat **Stop Record**, browser otomatis mengunduh **satu file .zip** berisi semuanya.
- ESP32 menulis penanda `REC_START` dan `REC_STOP` di `_event.csv`. Penanda ini dipakai untuk memotong bagian sesi dari file SD (`fobos_post.py cut`).

**Portal pengaturan di ESP32**
- Dibuka dari browser HP atau laptop di `http://IP-ESP32/`.
- Bila belum ada WiFi, ESP32 memancarkan AP `FobosMini-FM01`; portal ada di `http://192.168.4.1`.
- Isi portal: pindai dan pilih WiFi (dengan password), pengaturan NTRIP Ina-CORS (termasuk daftar mountpoint terdekat), dan broker MQTT.

---

## 1. Yang perlu disiapkan

### Perangkat keras
- ESP32 DevKitC (ESP32-WROOM-32) dan kabel USB data.
- Papan ZED-F9P dengan antena L1/L2 (TOPGNSS GN-GGB0710).
- Papan ICM-20948 yang pin I2C-nya terbuka (SDA, SCL).
- Modul microSD SPI dan kartu microSD FAT32 (8–32 GB, Class 10/A1).
- Kabel jumper.
- Catu 5 V kendaraan atau power bank.
- HP sebagai **hotspot 2,4 GHz**. ESP32 tidak mendukung 5 GHz.
- Laptop.

### Akun gratis
| Layanan | Untuk apa |
|---|---|
| GitHub | Repo **publik** dan GitHub Pages untuk web app |
| flespi (Free) | Broker MQTT cloud: 50 sesi, 20 000 pesan/menit (lihat `PANDUAN_FLESPI.md`). Akun gratis dihapus bila tidak aktif 2 bulan. |
| Ina-CORS BIG | Koreksi RTK. Registrasi di nrtk.big.go.id; caster nrtk.big.go.id (103.22.171.6) port 2001. |

### Perangkat lunak laptop
- **Arduino IDE 2.x**:
  - Boards Manager URL: `https://espressif.github.io/arduino-esp32/package_esp32_index.json`
  - Pasang **esp32 by Espressif Systems** versi 3.x.
  - Pasang library **PubSubClient** (Nick O'Leary).
  - WebServer, ESPmDNS, Preferences, Wire, SD, dan WiFiClientSecure sudah termasuk dalam paket esp32.
- **Python 3.10+**: `pip install -r tools/requirements.txt`
- Opsional: **RTKLIB demo5** (convbin, RTKPOST) dan **KF-GINS**.
- **u-center** (Windows), untuk mengatur ZED-F9P (bagian 2).

---

## 2. Setelan ZED-F9P di u-center (sekali, sebelum dirakit ke ESP32)

Firmware v2 bergantung pada setelan ini. **Baud harus sama** dengan `config.h`.

| Antarmuka | Setelan | Nilai |
|---|---|---|
| UART1 | Baud | **230400** (`U1_BAUD`) |
| UART1 | Protokol keluar | NMEA + UBX |
| UART1 | Protokol masuk | RTCM3 (+ UBX) |
| UART1 | Pesan keluar | NMEA **GGA**, **RMC**, **GST**; UBX **NAV-PVT** |
| UART2 | Baud | **460800** (`U2_BAUD`) |
| UART2 | Protokol keluar | UBX |
| UART2 | Pesan keluar | UBX **RXM-RAWX**, **RXM-SFRBX** |
| Laju navigasi | `CFG-RATE-MEAS` | 100 ms (10 Hz) |
| Konstelasi | GNSS aktif | GPS + GLONASS + Galileo (BeiDou dimatikan) agar RTK 10 Hz tercapai (datasheet ZED-F9P) |
| Model dinamika | `CFG-NAVSPG-DYNMODEL` | Automotive |
| TIMEPULSE | | Bawaan (1 Hz) sudah cukup |

Catatan setelan:
- Simpan setelan ke **BBR + Flash** agar tetap ada setelah daya dilepas.
- RAWX 10 Hz berukuran sekitar 20 KB/s. Pada 230400 baud (sekitar 23 KB/s) data akan hilang, karena itu UART2 memakai **460800**.

---

## 3. Perakitan dan pengkabelan

| Dari | Ke ESP32 | Keterangan |
|---|---|---|
| ZED TX1 | GPIO16 (RX Serial2) | NMEA + NAV-PVT |
| ZED RX1 | GPIO17 (TX Serial2) | RTCM Ina-CORS |
| ZED TX2 | **GPIO25** (RX Serial1) | RAWX + SFRBX; cukup satu kabel |
| ZED TIMEPULSE | GPIO34 | PPS |
| ICM-20948 SDA / SCL | **GPIO21 / GPIO22** | I2C 400 kHz; alamat 0x69 atau 0x68 dideteksi otomatis |
| microSD SCK / MISO / MOSI / CS | GPIO18 / 19 / 23 / 4 | SPI |
| Semua GND | GND | Wajib disatukan |

Catatan pemasangan:
- ICM-20948 diberi 3,3 V (maksimum 3,6 V), kecuali papannya punya regulator.
- Bila PPS tidak dipasang, set `PPS_ENABLE 0`. Waktu IMU tetap GPS tetapi lebih kasar (ditandai `tflag=1` pada data).
- Pasang IMU **kaku** ke badan kendaraan. Catat arah sumbu x/y/z terhadap arah depan kendaraan; ini dibutuhkan untuk KF-GINS.
- Pasang antena di atap dengan langit terbuka. Ukur lengan tuas antena–IMU.

---

## 4. Menyiapkan broker cloud flespi (sekali)

Ikuti **`PANDUAN_FLESPI.md`** langkah 1–3. Ringkasnya:

1. Daftar di **flespi.io** (Google, GitHub, atau email).
2. Buat dua token ACL (modul `mqtt`, topik `fobos/#`, publish + subscribe):
   - **fobos-perangkat** untuk ESP32;
   - **fobos-web** untuk web app.
3. Uji keduanya dengan MQTT Board.

| | ESP32 | Web app |
|---|---|---|
| Alamat | `mqtt.flespi.io` port **8883** (TLS) | `wss://mqtt.flespi.io:443` (cadangan: `…:443/mqtt`) |
| Username | token PERANGKAT | token WEB |
| Password | kosong | kosong |

Catatan:
- `ca_cert.h` memuat GlobalSign Root CA – R6 (dipakai contoh ESP32 resmi flespi) dan 8 sertifikat akar umum lain, sehingga broker lain juga dapat dipakai.
- HiveMQ Cloud Serverless tidak dipakai lagi, karena sudah tidak menerima cluster baru dan dihentikan 31-12-2026.

---

## 5. Menerbitkan web app di GitHub Pages (sekali)

1. Buat repo **Public**, lalu unggah seluruh isi folder.
   - **Jangan** ikut mengunggah `firmware/FobosMini/secrets.h`.
2. Buka **Settings → Pages**, pilih *Deploy from a branch*, lalu **main**, **/docs**, dan **Save**. Web app akan ada di `https://<akun>.github.io/<repo>/`.
3. Di web app, buka **Pengaturan**:
   - Pilih broker **Cloud (flespi)**.
   - URL `wss://mqtt.flespi.io:443` (bawaan).
   - Tempel token **WEB** di kolom Username/token; password kosong.
   - Centang "ingat token" hanya di perangkat anda sendiri.
   - Biarkan "unduh otomatis .zip saat Stop Record" tercentang.
   - Klik **Simpan**, lalu **Sambungkan**.

---

## 6. Mengisi dan mengunggah firmware

1. Salin `firmware/FobosMini/secrets_example.h` menjadi **`secrets.h`**, lalu isi:
   - `DEVICE_ID`: `FM01`, `FM02`, dan seterusnya.
   - `AP_PASS`, `PORTAL_USER`, `PORTAL_PASS`: kata sandi AP dan login portal (AP minimal 8 karakter). **Ganti nilai bawaannya.**
   - Nilai awal WiFi, NTRIP, dan MQTT. Semuanya boleh dikosongkan karena bisa diisi nanti lewat portal.
2. Buka `FobosMini.ino` di Arduino IDE. Tab `config.h`, `portal.h`, `fobos_proto.h`, `icm20948.h`, dan `ca_cert.h` ikut terbuka.
3. Atur **Tools**: Board **ESP32 Dev Module**, Partition **Default**, lalu pilih port. Klik **Upload**.
4. Buka **Serial Monitor 115200**. Pesan yang benar kira-kira seperti ini:
   ```
   === Fobos Mini 2.0.0, perangkat FM01 ===
   [SD] OK, file F0007_*, kosong 29xxx MB
   [IMU] ICM-20948 OK (alamat 0x69)
   [WiFi] hasil pindai: 6 jaringan ...
   [WiFi] tersambung: HotspotFobos 192.168.43.57  -> portal http://192.168.43.57/
   [MQTT] tersambung
   [NTRIP] ICY 200 OK
   ```
5. Perintah di Serial Monitor:
   - `status`: ringkasan laju PVT, RAWX, IMU, PPS, SD, dan NTRIP.
   - `scan`: pindai ulang WiFi.
   - `start NAMA` / `stop`: cadangan tombol Record.

---

## 7. Portal pengaturan ESP32

**Membuka portal**
- **Belum ada WiFi yang dikenal**: ESP32 memancarkan AP **`FobosMini-FM01`** (password `AP_PASS`). Sambungkan HP ke AP itu, lalu buka **http://192.168.4.1**.
- **Sudah tersambung**: buka `http://IP-ESP32/`. IP ini tampil di Serial Monitor dan di kartu perangkat web app (baris "Portal ESP32"). Bisa juga `http://fobos-fm01.local/` di laptop yang mendukung mDNS.
- Login dengan `PORTAL_USER` / `PORTAL_PASS`.

| Halaman | Fungsi |
|---|---|
| Status | WiFi, IP, NTRIP, MQTT, posisi, laju data, file SD aktif. Tombol mulai ulang. |
| WiFi | Daftar WiFi tersimpan (sampai 5), hasil pindai jaringan sekitar, dan form SSID + password → **Simpan & sambungkan**. |
| NTRIP | Host, port, mountpoint, user, password. **Lihat daftar mountpoint caster** (diurutkan dari yang terdekat bila sudah ada posisi), klik untuk memakai. |
| MQTT | Broker 1 (flespi: host, port 8883, TLS, token; opsi uji "lewati verifikasi sertifikat"; laju posisi ke web 10/5/2/1 Hz) dan broker 2 (laptop cadangan) |

Perilaku penyimpanan dan koneksi:
- Pengaturan disimpan di memori ESP32 (NVS), jadi tetap ada setelah dimatikan atau di-upload ulang. Isian di `secrets.h` hanya dipakai sebagai nilai awal.
- Saat menyala, ESP32 **memindai WiFi sekitar**, lalu tersambung ke WiFi **tersimpan yang sinyalnya terkuat**.
- Bila gagal, AP portal menyala dan pemindaian diulang tiap 30 s.
- AP portal mati sendiri 60 s setelah tersambung, bila tidak ada HP yang sedang tersambung ke AP.

---

## 8. Server lokal di laptop (cadangan)

```bash
cd tools
python fobos_local.py
```

1. Catat IP laptop yang tercetak, lalu isi sebagai broker 2 di **portal ESP32 → MQTT** (port 1883).
2. Buka web app dari `http://IP-laptop:8000`, bukan dari GitHub Pages, lalu pilih broker **Lokal**.
3. Laptop, ESP32, dan HP harus berada di hotspot yang sama.
4. Izinkan Python di Windows Firewall (jaringan Private).

---

## 9. Gladi tanpa perangkat (simulator)

```bash
python fobos_sim.py --broker mqtt://127.0.0.1:1883 --id FM01,FM02 --sd-dir sim_sd
python fobos_sim.py --broker mqtts://mqtt.flespi.io:8883 --user KUNCI_TOKEN_PERANGKAT
python fobos_sim.py --broker mqtt://127.0.0.1:1883 --loss 0.1     # uji pesan hilang
```

Simulator meniru protokol v2 dengan data **sintetis**. Dengan `--sd-dir`, simulator juga menulis berkas tiruan kartu SD (`F0001_*`) untuk berlatih `fobos_post.py`.

---

## 10. Prosedur demo

### H-1
- [ ] Setelan u-center tersimpan (bagian 2).
- [ ] Firmware ter-upload. `status` menunjukkan:
  - PVT ±10 Hz;
  - RAWX ±10 Hz;
  - IMU ±200 Hz;
  - PPS "ya".
- [ ] WiFi hotspot tersimpan di portal. NTRIP OK, dengan mountpoint dipilih dari daftar terdekat.
- [ ] Uji keliling 10–15 menit:
  1. Tekan **Record**, lalu **Stop Record**. File .zip harus terunduh.
  2. Ambil kartu SD, lalu jalankan `python fobos_post.py check <folder SD>` dan `python fobos_post.py cut <folder SD>`.
- [ ] Siapkan tangkapan layar cadangan.

### T-60 menit
1. Pasang antena, IMU, dan kartu SD. Nyalakan hotspot HP. Nyalakan Fobos Mini di area terbuka.
2. Di laptop, buka web app GitHub Pages lalu klik **Sambungkan**. Jalankan `fobos_local.py` sebagai cadangan siaga.
3. Periksa kartu perangkat di web app:

| Baris | Kondisi yang diharapkan |
|---|---|
| online | hijau |
| Posisi | berubah dari Single ke RTK float, lalu RTK fix |
| GNSS | UART1 PVT ±10 Hz · UART2 RAWX ±10 Hz |
| IMU | ±200 Hz, jeda maks < 10 ms |
| Waktu IMU | GPS + PPS |
| Kartu SD | OK, nomor file tampil |

### Saat demo
1. Jelaskan peta. Hijau berarti RTK fix (cm), jingga float, biru DGNSS, merah single. Akurasi tampil di kartu sebagai `hAcc` dan σN/σE dari GST.
2. Klik **● Record**. Kartu menampilkan **● RECORD**, nama sesi, durasi, dan jumlah posisi, IMU, serta UBX yang diterima.
3. Jalankan kendaraan. Tunjukkan:
   - jejak bergerak;
   - tombol **Getaran** di legenda;
   - grafik getaran 120 s.
4. Klik **■ Stop Record**. Browser otomatis mengunduh **`<sesi>_web.zip`**, berisi:
   - `_web_posisi.csv` (10 Hz, kolom sama dengan `_pos.csv` SD);
   - `_web_imu5hz.csv`;
   - `_web_rawx1hz.ubx`;
   - `_web_jejak.geojson`;
   - `_laporan.json` (kelengkapan dan nama file SD terkait).
5. Menu **Rekaman** menampilkan semua sesi di browser ini, dengan tombol **Unduh semua (.zip)** atau per file.

### Bila terjadi masalah
- **Internet lokasi mati**: buka `http://IP-laptop:8000` dan pilih broker **Lokal**. ESP32 pindah ke broker 2 setelah sekitar 3 kali gagal.
- **WiFi berubah**: buka portal ESP32 (lewat AP `FobosMini-FM01` → `192.168.4.1` bila perlu) lalu pilih WiFi baru.
- **Kartu SD tetap merekam** selama perangkat menyala, apa pun kondisi jaringan.

---

## 10a. Fitur tampilan web app (v2.2)

**Tata letak.**
- Panel **Ringkasan**, **Keterangan** (kualitas posisi dan warna getaran), **Indeks getaran**, dan **Perangkat** dapat dibuka/ditutup dengan satu ketukan pada judulnya. Keadaan terakhir diingat di browser.
- Di ponsel, daftar perangkat berupa *bottom sheet*: seret pegangan di atasnya untuk mengubah tinggi (kecil / setengah / penuh), sehingga peta mendapat sebagian besar layar. Pada ponsel hanya satu panel melayang yang terbuka pada satu waktu.
- Tombol Rekaman, Putar ulang, Mode pameran, dan Pengaturan ada di menu ⋮ pada ponsel.

**Fitur tambahan.**
- **Putar ulang** (Putar ulang pada menu): memutar kembali sesi dari berkas `.zip` unduhan web, `_pos.csv` (+ `_imu.csv`) dari kartu SD, `_web_posisi.csv`, berkas RTKLIB `.pos` (format lintang/bujur derajat), atau sesi yang tersimpan di browser. Untuk CSV SD 200 Hz, indeks getaran dihitung ulang di browser dengan rumus yang sama seperti firmware.
- **Mode pameran**: layar penuh, peta gelap, panel besar (kualitas, ketelitian, kecepatan, getaran, jarak, durasi, % RTK fix, jumlah guncangan), layar dijaga tetap menyala (Wake Lock bila didukung browser). Keluar dengan tombol ✕.
- **Lingkaran ketelitian**: lingkaran ketelitian horizontal saat ini (hacc) dibandingkan dengan GNSS standar (acuan 3,3 m, garis putus-putus merah). Tampil hanya pada zum ≥ 19 dan saat posisi valid.
- **Penanda guncangan**: ditandai saat indeks getaran melewati ambang (bawaan 2 m/s², jeda 3 detik antar penanda).
- **Mode warna Segmen**: jejak diwarnai rata-rata getaran per segmen jarak (bawaan 20 m; pilihan 10/20/50/100 m).
- **Kartu Ringkasan**: jarak, durasi, % RTK fix, kecepatan maksimum, getaran rata-rata, jumlah guncangan.

Nilai ambang guncangan, panjang segmen, dan ketelitian acuan diatur di **Pengaturan** (`shockTh`, `segLen`, `refAcc`). Nilai bawaan adalah titik awal dan perlu disetel dengan uji lapangan.

## 10b. Cuaca di web app (v2.3)

Panel **Cuaca** (sudut kanan atas, bisa dilipat) menampilkan cuaca di posisi perangkat terpilih. Semua data diambil langsung oleh browser, jadi perangkat yang membuka web app harus punya internet. Bila tidak ada internet, panel hanya menampilkan pesan dan semua fitur lain tetap berjalan.

| Sumber | Tampil sebagai | Catatan |
|---|---|---|
| **Open-Meteo** | Ikon bergerak, suhu, panah dan kecepatan angin, kelembapan, hujan, awan, hembusan, bilah prakiraan 12 jam | Tanpa API key. Gratis untuk non-komersial (di bawah 10.000 panggilan/hari). Data diperbarui tiap 10 menit atau saat posisi bergeser lebih dari 5 km. |
| **RainViewer** | Lapisan radar hujan di peta, riwayat 2 jam, tombol putar | Centang "radar hujan". Zum maksimum sumber = 7, jadi radar hanya tampil pada zum ≤ 11. Gratis untuk keperluan pribadi dan edukasi. |
| **BMKG** (opsional) | Prakiraan kelurahan: jam, kondisi, suhu, kelembapan | Isi **Kode wilayah BMKG (adm4)** di Pengaturan (format xx.xx.xx.xxxx, kode kelurahan/desa Kemendagri). |

- Atribusi sumber otomatis muncul di pojok kanan bawah peta. Jangan dihapus karena merupakan syarat penggunaan.
- **Mode pameran** menampilkan satu baris cuaca di HUD (di ponsel) atau panel cuaca (di layar lebar).
- **Catatan per sesi:** selama **Record** aktif, kondisi cuaca dicatat tiap pembaruan. Kartu Ringkasan menampilkan "Cuaca selama sesi", dan berkas `.zip` unduhan menyertakan `<sesi>_cuaca.json`. Catatan ini hanya ada selama tab tidak dimuat ulang.
- Pada **Putar ulang**, sejak v2.4 panel Cuaca menampilkan cuaca model pada tanggal dan jam rekaman (lihat 10c).
- Pengaturan: kotak "tampilkan cuaca" mematikan seluruh modul.

**Keterbatasan:** modul ini diuji dengan data tiruan (bentuk respons mengikuti dokumentasi API), karena server pengembangan tidak dapat menjangkau API aslinya. Bila pada pemakaian pertama muncul pesan galat, kirimkan pesannya. Khusus BMKG, dukungan CORS dari browser belum terverifikasi; bila diblokir, panel menampilkan pesan dan fitur lain tidak terganggu. Open-Meteo dan RainViewer hanya untuk penggunaan non-komersial/pribadi; untuk layanan komersial PT diperlukan lisensi atau sumber lain.

## 10c. Cuaca perjalanan, elevasi, dan ruas jalan (v2.4)

**Urutan informasi di layar.** Informasi utama tetap: kualitas posisi, ketelitian, kecepatan, getaran (kartu perangkat, Ringkasan, HUD pameran). Cuaca, elevasi, dan ruas jalan adalah pelengkap dan bisa dilipat. Di ponsel, tiga chip (Ringkasan, Keterangan, Cuaca) berjajar di atas; panel yang dibuka tampil selebar layar di bawahnya.

| Fitur | Letak | Keterangan |
|---|---|---|
| Peringatan hujan | Baris atas panel Cuaca, HUD pameran | "Sedang hujan", "Hujan diperkirakan sekitar pukul …", atau "Tidak ada hujan 3 jam ke depan". Ketelitian per jam. |
| Cuaca di jejak | Ikon kecil di sepanjang rute; mode warna **Hujan** di Keterangan | Titik contoh tiap ±2 km atau 15 menit (maksimum 24). Untuk rute pendek hanya muncul 1–2 ikon. |
| Linimasa cuaca perjalanan | Kartu Ringkasan | Pita berwarna per kelas hujan, ikon, rentang suhu. Saat Putar ulang ada garis merah penanda posisi waktu. |
| Cuaca saat rekaman | Panel Cuaca saat Putar ulang | Diambil untuk tanggal dan jam rekaman. Rekaman lebih dari ±88 hari memakai arsip historis Open-Meteo. |
| Peta hujan | Centang "peta hujan" di panel Cuaca | Kisi berwarna dari model (±11 km per sel atau lebih kasar), kondisi saat ini. Bukan pengamatan radar. |
| Profil elevasi | Panel grafik kiri bawah, tab **Elevasi** | Dari tinggi GNSS Fobos: tinggi, total naik/turun, kemiringan 20 m terakhir. Garis abu-abu = bukan RTK fix. Pita biru di tepi atas = hujan (model). |
| Ruas jalan | Kartu Ringkasan, HUD pameran | Nama, kelas, permukaan, dan batas kecepatan dari OpenStreetMap, serta rekap "Getaran per ruas jalan". |

**Catatan penting.**
- Semua nilai cuaca adalah **keluaran model**, bukan pengamatan. Hujan lokal bisa tidak tertangkap. Resolusi model beberapa kilometer, sehingga titik berdekatan mendapat nilai sama.
- Info ruas jalan memakai layanan publik Overpass. Web app membatasi diri: satu kueri per area ±1,3 km, jeda minimal 20 detik, paling banyak 80 kueri per hari per browser. Saat Putar ulang kecepatan tinggi, ruas jalan bisa tertinggal ("menunggu data jalan…").
- Nama dan kelas jalan bergantung pada kelengkapan OpenStreetMap di lokasi; jenis permukaan sering kosong.
- Titik dicocokkan ke ruas terdekat dalam 20 m. Rekap getaran per ruas hanya memuat titik yang berhasil dicocokkan.
- Kedua modul bisa dimatikan di Pengaturan ("tampilkan cuaca", "tampilkan info ruas jalan").
- **Status uji:** diuji di Chromium headless dengan data tiruan untuk Open-Meteo dan Overpass. Belum pernah dijalankan terhadap layanan aslinya dari lingkungan pengembangan.

## 10d. Putar ulang banyak kendaraan (v2.5)

Untuk demo "armada" tanpa Fobos Mini yang sedang berjalan: tiap rekaman posisi diputar sebagai satu kendaraan, bersamaan atau sendiri-sendiri.

**Memuat.** Menu **Putar ulang** → pilih beberapa file sekaligus (Ctrl/Shift + klik), misalnya `gnss_main.pos`, `gnss_main2.pos`, `imu.csv`, `imu2.csv`.
- Tiap file posisi (`.pos` RTKLIB, `_pos.csv`, `_web_posisi.csv`, atau `.zip` web) menjadi satu kendaraan.
- File IMU dipasangkan otomatis ke rekaman posisi yang **rentang waktunya bertumpang tindih**. Bila waktunya tidak cocok dengan rekaman mana pun, file itu dilewati dan disebutkan di notifikasi.
- IMU bisa juga dipasang belakangan lewat tombol **＋ IMU** di kartu kendaraan.
- Membuka dialog lagi **menambah** kendaraan. File yang sama boleh dimuat dua kali (nama mendapat akhiran "(2)").

**Format CSV IMU yang dikenali.** Kolom waktu `tow_s` (+ `gps_week`) atau `time_s` (waktu Unix UTC, detik atau milidetik), serta kolom `ax, ay, az`. Satuan m/s²; bila nilainya dalam g (gravitasi ≈ 1), dikonversi otomatis. Indeks getaran dihitung per detik dengan rumus yang sama seperti firmware (perlu ≥ 10 sampel per detik). Kolom giroskop tidak dipakai.

**Kontrol per kendaraan (kartu di panel Perangkat).** ▶/❚❚, penggeser waktu, kecepatan (1–50×), lewati jeda, ✎ ganti nama (diingat browser untuk file yang sama), centang **grup**, ✕ tutup. Baris kedua menampilkan waktu putar dan jam serta tanggal asli rekaman.

**Kontrol bersama (kotak "Putar ulang" di atas daftar).** Berlaku untuk kendaraan yang dicentang **grup**:
- **Mulai bersamaan:** semua kendaraan grup mulai dari awal rekamannya masing-masing pada saat yang sama, walau tanggal rekamannya berbeda.
- **Jeda grup / Lanjut grup**, kecepatan bersama, **ulang otomatis** (kendaraan yang selesai mulai lagi setelah 2 detik), **Tampilkan semua** (peta memuat semua rute), **Tambah rekaman**, **Tutup semua**.
- Di ponsel, tombol ▶/❚❚ grup juga ada di kepala panel Perangkat, jadi bisa dipakai tanpa membuka panel.

**Mode pameran.** HUD menampilkan daftar **Armada dipantau** (nama, kualitas posisi, kecepatan, getaran untuk tiap kendaraan); klik baris untuk memilih kendaraan. Tombol ▶/❚❚ grup tampil di bawah layar.

**Catatan.**
- Grafik getaran, ringkasan, cuaca, elevasi, dan ruas jalan mengikuti kendaraan **terpilih**.
- "Mulai bersamaan" bukan sinkronisasi waktu asli: kendaraan dengan durasi berbeda akan selesai pada saat berbeda.
- Rute dari lokasi yang berjauhan membuat "Tampilkan semua" memperkecil peta; pilih kendaraan atau centang "ikuti perangkat terpilih" untuk mendekat.

## 10e. Putar ulang file trajektori ESKF / KF-GINS (v2.6)

File trajektori keluaran `ESKF_v7_..._single_Antena.py` atau `KF_GINS_Matlab_single_run.py` (CSV dengan kolom `timestamp_s, lat_deg, lon_deg, alt_m, vn_ms, ve_ms, vd_ms, roll_deg, pitch_deg, yaw_deg, std_n_m, ...`) bisa diputar ulang **sendirian**, tanpa file posisi atau IMU.

- **Waktu:** di dialog Putar ulang pilih sistem waktu `timestamp_s`: **UTC** (bawaan kedua script) atau **GPST** (bila dijalankan dengan `--output-time-system gpst`). Pilihan salah menggeser waktu 18 detik, yang berpengaruh pada pemasangan IMU dan jam cuaca.
- **Yang tampil:** posisi, ketinggian elipsoid (tab Elevasi), sikap (roll, pitch, arah), ketelitian dari `std_n_m`/`std_e_m` (lingkaran ketelitian), kecepatan dari `vn_ms`/`ve_ms`.
- **Label kualitas:** `gnss_status` = full dengan `n_amb_fixed` > 0 menjadi "ESKF fix" (warna sama dengan RTK fix), full tanpa ambiguitas fix menjadi "ESKF float", poor menjadi "geometri lemah", outage menjadi "tanpa GNSS (INS)". Kartu Ringkasan menyebutnya "Ambiguitas fix", bukan "RTK fix".
- **Getaran tanpa file IMU:** dihitung dari percepatan vertikal, yaitu turunan `vd_ms` pada grid 10 Hz, RMS per detik. Ini **tidak setara** dengan indeks getaran IMU 100 Hz: lebar pitanya hanya sampai 5 Hz, dan hasil yang sudah dihaluskan (RTS) menekan getaran, sehingga nilainya lebih kecil. Untuk indeks yang sebanding dengan rekaman Fobos, pilih juga CSV IMU-nya; IMU otomatis menggantikan getaran turunan bila waktunya bertumpang tindih.
- **Laju tampilan:** paling banyak 10 titik per detik. Keluaran pada laju IMU (100–200 Hz) dirapikan otomatis.
- **Cuaca pada tanggal rekaman:** rekaman yang lebih dari 7 hari lalu memakai arsip historis Open-Meteo (reanalisis, resolusi kasar); yang lebih baru memakai API prakiraan. Bila satu gagal, yang lain dicoba.
- Trajektori bisa diputar bersama rekaman lain (misalnya `.pos` RTKLIB dari sesi yang sama) untuk perbandingan, dengan **Mulai bersamaan**.

## 11. Setelah sesi: mengolah data

### 11.1 Berkas
| Sumber | Berkas | Isi |
|---|---|---|
| Web (.zip) | `<sesi>_web_posisi.csv` | Posisi 10 Hz + status + GST |
| Web (.zip) | `<sesi>_web_imu5hz.csv` | Ringkasan IMU 5 Hz + indeks getaran |
| Web (.zip) | `<sesi>_web_rawx1hz.ubx` | RAWX 1 Hz + SFRBX |
| Kartu SD | `F0007_raw.ubx` | **Salinan penuh UART2** (RAWX 10 Hz + SFRBX) sejak menyala |
| Kartu SD | `F0007_pos.csv` | Posisi 10 Hz sejak menyala |
| Kartu SD | `F0007_imu.csv` | IMU **200 Hz** sejak menyala |
| Kartu SD | `F0007_event.csv` | BOOT, WIFI_OK, NTRIP_OK, REC_START, REC_STOP, … |

Kolom `_pos.csv`:
`utc, gps_week, tow_s, lat, lon, h_msl, h_ell, q (0–4), status, fix_type, carr_soln, num_sv, h_acc, v_acc, std_lat, std_lon, std_alt (GST), gga_q, hdop, diff_age, speed, heading, pdop`

Kolom `_imu.csv`:
`gps_week, tow_s, ax, ay, az (m/s²), gx, gy, gz (rad/s), temp_c, tflag` (0 = waktu lokal, 1 = GPS, 3 = GPS+PPS)

### 11.2 Perintah
```bash
python fobos_post.py check E:/                                  # ringkasan semua set F#### + daftar sesi Record
python fobos_post.py cut E:/ --sess FM01_20261112_081500 -o sesi  # potong bagian sesi dari file SD
python fobos_post.py rinex sesi/FM01_20261112_081500_sd_raw.ubx # RINEX via convbin (RTKLIB)
python fobos_post.py pos2geojson sesi/FM01_20261112_081500_sd_pos.csv
```
Untuk PPK, proses `.obs` di RTKPOST (*Kinematic*) dengan RINEX stasiun Ina-CORS terdekat sebagai base.

### 11.3 KF-GINS (EKF loosely-coupled)
```bash
python fobos_post.py imu2kfgins sesi/<sesi>_sd_imu.csv --axes "x,-y,-z" -o imu_kf.txt
python fobos_post.py pos2kfgins raw.pos -o gnss_kf.txt                       # hasil PPK RTKLIB, atau
python fobos_post.py pos2kfgins sesi/<sesi>_sd_pos.csv --min-q 3 -o gnss_kf.txt  # solusi RTK ZED (FIX/FLOAT) + GST
python fobos_post.py allan diam/F0010_imu.csv                                # sekali: rekam IMU diam 1-3 jam
python fobos_post.py kfgins-yaml --gnss gnss_kf.txt --imu imu_kf.txt --allan diam/F0010_imu_allan.json
```

Hal yang perlu diperiksa:
- **Hanya sampel IMU berwaktu GPS** (`tflag` 1/3) yang dipakai.
- **`gbstd`/`abstd`** dibiarkan `ISI` sampai uji Allan dilakukan.
- **`antlever`** wajib diukur.

---

## 12. Volume data (perkiraan hitungan, bukan pengukuran)

| Aliran web | Laju | Per jam |
|---|---|---|
| Posisi JSON (±420 B) | 10 Hz | ±15 MB |
| IMU ringkasan JSON (±230 B) | 5 Hz | ±4 MB |
| Status | 1 Hz | ±3 MB |
| UBX 1 Hz (hanya saat Record) | ±2,5–3,2 KB/s | ±9–12 MB |
| **Total per perangkat saat Record** | | **±31–34 MB unggah** |

Catatan perhitungan:
- Dalam jumlah pesan, 1 perangkat mengirim ±1 100 pesan/menit, dan setiap penonton menerima jumlah yang sama. Batas flespi gratis 20 000 pesan/menit cukup untuk ±2 perangkat dengan ±5 penonton pada 10 Hz. Bila penonton lebih banyak, turunkan laju posisi ke 5/2 Hz lewat pilihan di kartu perangkat (perhitungan lengkap di `PANDUAN_FLESPI.md` bagian 10).
- Kartu SD per jam:
  - `_raw.ubx` ±75–80 MB;
  - `_imu.csv` (±70 B × 200 Hz) ±50 MB;
  - `_pos.csv` ±6 MB.
- Totalnya ±135 MB/jam, sehingga kartu 16 GB cukup untuk >100 jam.

---

## 13. Pemecahan masalah

| Gejala | Tindakan |
|---|---|
| Kartu web "GNSS UART1 PVT 0 Hz" | Baud UART1 di u-center ≠ `U1_BAUD`, TX1→GPIO16 tertukar, atau NAV-PVT belum diaktifkan |
| "UART2 RAWX 0 Hz" | Baud UART2 ≠ `U2_BAUD`, TX2 belum ke GPIO25, atau RAWX belum diaktifkan di UART2 |
| `std_lat` kosong | GST belum diaktifkan di UART1 |
| `[IMU] TIDAK TERDETEKSI` | Cek SDA21/SCL22, 3,3 V, GND; papan harus mode I2C |
| `[SD] TIDAK ADA/gagal` | Format FAT32; cek CS GPIO4 |
| NTRIP `401` / tidak fix | Cek akun dan mountpoint di portal → NTRIP; pilih mountpoint terdekat dari daftar |
| AP `FobosMini-…` tidak muncul | ESP32 sedang tersambung ke WiFi tersimpan; buka portal lewat IP-nya |
| `[MQTT] gagal, rc=4/5` | Token flespi salah, kedaluwarsa, atau ACL kurang; perbaiki di portal → MQTT |
| `[MQTT] gagal, rc=-2` | Internet/TLS. Uji sementara dengan "lewati verifikasi sertifikat" (lihat `PANDUAN_FLESPI.md` bagian 12) |
| IMU "jeda maks" > 20 ms sering | Beban CPU/I2C. Laporkan angka `status`; I2C 400 kHz seharusnya cukup |
| Data web hilang (laporan) | Sinyal hotspot lemah; gunakan file SD (`fobos_post.py cut`) |

---

## 14. Protokol MQTT v2 (awalan `fobos/<ID>/…`)

| Topik | Arah | Isi |
|---|---|---|
| `pvt` | perangkat → web | JSON 10 Hz (atau 5/2/1 Hz sesuai `rate`): `id, seq, tow (ms), wk, utc, lat, lon, h, hae, q, fix, carr, sv, hacc, vacc, slat, slon, salt, hdop, age, spd, hdg, pdop, vib, sess` |
| `imu` | perangkat → web | JSON 5 Hz: `id, seq, wk, tow (s), ax, ay, az, gx, gy, gz (rata-rata 200 ms), n, vib, tflag` |
| `raw` | perangkat → web (saat Record) | Biner "FOBR": header 16 byte (`"FOBR"`, ver, flags, rsv, seq u32, tow_ms u32) + frame UBX utuh (RAWX detik bulat + SFRBX) |
| `status` | perangkat → web | JSON 1 Hz retained; LWT `{"online":false}`. Isi: `ip, ssid, ap, file, ntrip, gnss, imu, time, sd, sess, …` |
| `cmd` | web → perangkat | `{"cmd":"start","sess":"FM01_YYYYMMDD_hhmmss"}`, `{"cmd":"stop"}`, `{"cmd":"ping"}`, `{"cmd":"rate","pvt_hz":5}` (laju posisi ke web 10/5/2/1 Hz; SD tetap semua epoch) |
| `ack` | perangkat → web | `start`: `file, pvt_seq0, imu_seq0`. `stop`: `dur_s, raw_pkts, pvt_seq0/1, imu_seq0/1`, untuk menghitung kelengkapan. |

**Indeks getaran (`vib`)**: RMS percepatan searah gravitasi rata-rata per jendela 1 s, setelah rata-rata jendela dibuang. Nilai ini **relatif, bukan IRI**, dan harus dikalibrasi sebelum dipakai sebagai nilai kekasaran jalan.

---

## 15. Status pengujian dan keterbatasan

**Sudah diuji di lingkungan pengembangan:**
- **Logika portabel firmware** (`test/t_proto.cpp`):
  - parser campuran NMEA + UBX dengan sampah di tengah aliran;
  - penggabung epoch PVT + GGA + GST untuk dua urutan kedatangan;
  - format CSV/JSON, GGA, dan indeks getaran.
- **Firmware v2** lolos cek sintaks terhadap tiruan API Arduino-ESP32.
- **Alur ujung-ke-ujung** dengan simulator v2, broker lokal, dan web app di Chromium headless:
  - Record, lalu Stop, lalu **.zip otomatis** (CRC valid, UBX terbaca pyubx2);
  - kelengkapan 100% tanpa kehilangan;
  - uji 15% pesan hilang ditambah muat ulang halaman: kehilangan terdeteksi per nomor urut.
- **`fobos_post.py`**: `check`, `cut` (jumlah baris potongan SD cocok dengan sesi web), `imu2kfgins`, `pos2kfgins`, `kfgins-yaml`, `pos2geojson`.

**Belum diuji (perlu perangkat dan akun anda):**
- **Kompilasi dengan toolchain ESP32 asli.** Server pengembangan tidak dapat mengunduh toolchain Espressif. Bila Arduino IDE memunculkan galat, kirimkan pesannya.
- **Portal pada perangkat nyata**: AP, pindai WiFi, dan daftar mountpoint Ina-CORS. Format sourcetable diasumsikan standar NTRIP (baris `STR;`).
- **flespi dan Ina-CORS** dengan akun anda. Untuk flespi, khususnya: path WebSocket browser, sertifikat TLS di ESP32, dan label panel (lihat `PANDUAN_FLESPI.md` bagian 13).
- **Laju nyata pada perangkat**:
  - 10 Hz dengan GPS+GLO+GAL;
  - 460800 baud UART2;
  - kestabilan IMU 200 Hz bersamaan dengan WiFi/TLS dan penulisan SD.

**Keterbatasan (tampilan v2.2):** fitur baru (panel lipat, bottom sheet, putar ulang, mode pameran, lingkaran ketelitian, penanda guncangan, segmen) diuji di Chromium headless (desktop dan emulasi Pixel 7) dengan data simulator dan contoh berkas; belum diuji di ponsel Android nyata maupun dengan ubin peta OSM (diblokir di lingkungan pengujian). Lingkaran ketelitian baru bermakna pada kondisi RTK nyata.

**Keterbatasan:**
- Rekaman browser hanya berjalan selama tab terbuka dan tersambung. Kartu SD adalah salinan acuan.
- Mode lokal tanpa kata sandi broker; gunakan hanya di hotspot pribadi.
- Portal memakai login Basic tanpa HTTPS; gunakan di jaringan pribadi dan ganti kata sandi bawaan.
