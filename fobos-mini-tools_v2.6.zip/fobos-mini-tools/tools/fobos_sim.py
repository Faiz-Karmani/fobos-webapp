#!/usr/bin/env python3
"""fobos_sim.py — simulator Fobos Mini v2 untuk gladi demo dan uji web app tanpa perangkat.

Meniru protokol firmware v2:
  pvt    JSON 10 Hz (posisi + status fix/float/single + GST)
  imu    JSON 5 Hz (rata-rata 200 ms + indeks getaran per detik)
  status JSON 1 Hz retained (+ LWT), ack
  raw    paket FOBR (RAWX 1 Hz + SFRBX) hanya saat Record
Data GNSS/IMU-nya SINTETIS (bukan pengamatan nyata) — hanya untuk menguji alur aplikasi.

  python fobos_sim.py --broker mqtt://127.0.0.1:1883 --id FM01,FM02
  python fobos_sim.py --broker mqtts://mqtt.flespi.io:8883 --user <TOKEN_PERANGKAT_FLESPI>   # flespi: password kosong
  python fobos_sim.py --broker mqtt://127.0.0.1:1883 --sd-dir sim_sd   # juga tulis berkas tiruan kartu SD
"""
import argparse
import glob
import json
import math
import os
import random
import ssl
import struct
import threading
import time
from urllib.parse import urlparse

import paho.mqtt.client as mqtt

import fobos_lib as fl

R_EARTH = 6378137.0
POS_HEADER = ('utc,gps_week,tow_s,lat,lon,h_msl,h_ell,q,status,fix_type,carr_soln,num_sv,h_acc,v_acc,'
              'std_lat,std_lon,std_alt,gga_q,hdop,diff_age,speed,heading,pdop\n')
STATUS = {4: 'FIX', 3: 'FLOAT', 2: 'DGNSS', 1: 'SINGLE', 0: 'TANPA_FIX'}


class SimDevice:
    def __init__(self, dev_id, args, k):
        self.id, self.a = dev_id, args
        self.prefix = args.prefix
        self.lat0 = args.lat + 0.0006 * k
        self.lon0 = args.lon + 0.0006 * k
        self.phase = random.random() * 1000
        self.sess = ''
        self.sess_t0 = 0
        self.raw_seq = self.pvt_seq = self.imu_seq = 0
        self.sess_pvt0 = self.sess_imu0 = 0
        self.lock = threading.Lock()
        self.stop_evt = threading.Event()
        self.vib = None
        self._flush_req = False
        self.pvt_hz = 10
        self.sd = None
        self.file = 'F----'
        if args.sd_dir:
            os.makedirs(args.sd_dir, exist_ok=True)
            used = [int(os.path.basename(p)[1:5]) for p in glob.glob(os.path.join(args.sd_dir, 'F[0-9][0-9][0-9][0-9]_raw.ubx'))]
            n = max(used) + 1 if used else 1
            self.file = f'F{n:04d}'
            base = os.path.join(args.sd_dir, self.file)
            self.sd = {'raw': open(base + '_raw.ubx', 'wb'), 'pos': open(base + '_pos.csv', 'w'),
                       'imu': open(base + '_imu.csv', 'w'), 'evt': open(base + '_event.csv', 'w')}
            self.sd['pos'].write(POS_HEADER)
            self.sd['imu'].write('gps_week,tow_s,ax,ay,az,gx,gy,gz,temp_c,tflag\n')
            self.sd['evt'].write('utc,gps_week,tow_s,kejadian,keterangan\n')
            self.event('BOOT', f'sim id {dev_id}')
        u = urlparse(args.broker)
        self.cli = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=f'fobos-sim-{dev_id}-{random.randint(0, 65535):04x}',
                               transport='websockets' if u.scheme in ('ws', 'wss') else 'tcp')
        if u.scheme in ('mqtts', 'wss'):
            self.cli.tls_set(cert_reqs=ssl.CERT_REQUIRED)
        if u.scheme in ('ws', 'wss'):
            self.cli.ws_set_options(path=u.path or '/mqtt')
        if args.user:
            self.cli.username_pw_set(args.user, args.password or None)   # flespi: token sebagai username, tanpa password
        self.cli.will_set(self.t('status'), json.dumps({'id': dev_id, 'online': False}), qos=0, retain=True)
        self.cli.on_connect = self.on_connect
        self.cli.on_message = self.on_message
        self.host, self.port = u.hostname, u.port or {'mqtt': 1883, 'mqtts': 8883, 'ws': 80, 'wss': 443}[u.scheme]

    def t(self, k):
        return f'{self.prefix}/{self.id}/{k}'

    def event(self, ev, detail=''):
        if not self.sd:
            return
        now = time.time()
        wk, tow = fl.unix_to_gps(now)
        with self.lock:
            self.sd['evt'].write(time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(now)) + f',{wk},{tow:.3f},{ev},{detail}\n')
            self.sd['evt'].flush()

    def on_connect(self, c, ud, flags, rc, props=None):
        print(f'[{self.id}] tersambung ke broker (rc={rc})')
        c.subscribe(self.t('cmd'))

    def on_message(self, c, ud, msg):
        try:
            cmd = json.loads(msg.payload.decode())
        except ValueError:
            return
        if cmd.get('cmd') == 'start':
            self.start(cmd.get('sess') or f'{self.id}_{int(time.time())}')
        elif cmd.get('cmd') == 'stop':
            self.stop()
        elif cmd.get('cmd') == 'rate':
            hz = int(cmd.get('pvt_hz', 10))
            if hz in (10, 5, 2, 1):
                self.pvt_hz = hz
            c.publish(self.t('ack'), json.dumps({'cmd': 'rate', 'ok': True, 'pvt_hz': self.pvt_hz}))
        elif cmd.get('cmd') == 'ping':
            c.publish(self.t('ack'), json.dumps({'cmd': 'ping', 'ok': True}))

    def start(self, name):
        with self.lock:
            if self.sess:
                self.cli.publish(self.t('ack'), json.dumps({'cmd': 'start', 'ok': False, 'sess': self.sess, 'msg': 'sesi sedang berjalan'}))
                return
            self.sess = ''.join(ch for ch in name if ch.isalnum() or ch in '_-')[:47]
            self.sess_t0 = time.time()
            self.raw_seq = 0
            self.sess_pvt0, self.sess_imu0 = self.pvt_seq, self.imu_seq
        self.event('REC_START', self.sess)
        print(f'[{self.id}] Record mulai: {self.sess}')
        self.cli.publish(self.t('ack'), json.dumps({'cmd': 'start', 'ok': True, 'sess': self.sess, 'file': self.file, 'sd': bool(self.sd),
                                                    'pvt_seq0': self.sess_pvt0, 'imu_seq0': self.sess_imu0}))

    def stop(self):
        with self.lock:
            if not self.sess:
                self.cli.publish(self.t('ack'), json.dumps({'cmd': 'stop', 'ok': False, 'msg': 'tidak ada sesi'}))
                return
            sess = self.sess
            ack = {'cmd': 'stop', 'ok': True, 'sess': sess, 'file': self.file, 'dur_s': int(time.time() - self.sess_t0),
                   'raw_pkts': self.raw_seq, 'pvt_seq0': self.sess_pvt0, 'pvt_seq1': self.pvt_seq,
                   'imu_seq0': self.sess_imu0, 'imu_seq1': self.imu_seq, 'drop_mqtt': 0}
        self._flush_req = True                 # kirim paket raw terakhir sebelum sesi ditutup
        for _ in range(30):
            if not self._flush_req:
                break
            time.sleep(0.02)
        with self.lock:
            ack['raw_pkts'] = self.raw_seq
            ack['pvt_seq1'], ack['imu_seq1'] = self.pvt_seq, self.imu_seq
            self.sess = ''
        self.event('REC_STOP', sess)
        time.sleep(0.3)
        self.cli.publish(self.t('ack'), json.dumps(ack))
        print(f'[{self.id}] Record selesai: {ack}')

    # ---------------------------------------------------------- lintasan sintetis
    def pose(self, t):
        L, W, v = 240.0, 120.0, self.a.speed
        per = 2 * (L + W)
        s = ((t + self.phase) * v) % per
        if s < L:
            e, n, hdg = s, 0.0, 90.0
        elif s < L + W:
            e, n, hdg = L, s - L, 0.0
        elif s < 2 * L + W:
            e, n, hdg = L - (s - L - W), W, 270.0
        else:
            e, n, hdg = 0.0, W - (s - 2 * L - W), 180.0
        lat = self.lat0 + math.degrees(n / R_EARTH)
        lon = self.lon0 + math.degrees(e / (R_EARTH * math.cos(math.radians(self.lat0))))
        bump = any(abs(s - x) < 4 for x in (60, 420))
        return lat, lon, hdg, bump

    def quality(self, t):
        c = (t + self.phase) % 90
        return 4 if c < 60 else 3 if c < 75 else 1

    def drop(self):
        return random.random() < self.a.loss

    # ---------------------------------------------------------- loop posisi 10 Hz
    def run(self):
        self.cli.connect(self.host, self.port, keepalive=15)
        self.cli.loop_start()
        threading.Thread(target=self.imu_loop, daemon=True).start()
        threading.Thread(target=self.raw_loop, daemon=True).start()
        last_status = 0
        nxt = math.ceil(time.time() * 10) / 10
        while not self.stop_evt.is_set():
            nxt += 0.1
            time.sleep(max(0.0, nxt - time.time()))
            now = round(time.time(), 1)
            wk, tow = fl.unix_to_gps(now)
            tow_ms = int(round(tow * 10)) * 100
            lat, lon, hdg, bump = self.pose(now)
            q = self.quality(now)
            sd = {4: 0.012, 3: 0.25, 1: 1.8}[q] * random.uniform(0.8, 1.2)
            lat += math.degrees(random.gauss(0, sd * 0.7) / R_EARTH)
            lon += math.degrees(random.gauss(0, sd * 0.7) / R_EARTH)
            sv = random.randint(22, 28)
            p = {'id': self.id, 'seq': self.pvt_seq, 'tow': tow_ms, 'wk': wk,
                 'utc': time.strftime('%Y-%m-%dT%H:%M:%S', time.gmtime(now)) + f'.{int(round(now * 100)) % 100:02d}Z',
                 'lat': round(lat, 9), 'lon': round(lon, 9), 'h': 120.0, 'hae': 147.6, 'q': q, 'fix': 3,
                 'carr': {4: 2, 3: 1}.get(q, 0), 'sv': sv, 'hacc': round(sd, 3), 'vacc': round(sd * 1.6, 3),
                 'slat': round(sd * 0.7, 3), 'slon': round(sd * 0.7, 3), 'salt': round(sd * 1.6, 3),
                 'hdop': 0.7, 'age': 1.0 if q >= 2 else None, 'spd': round(self.a.speed, 2), 'hdg': hdg, 'pdop': 1.3,
                 'vib': self.vib, 'sess': self.sess}
            if tow_ms % (1000 // self.pvt_hz) == 0:      # penipisan ke web; SD tetap semua epoch
                self.pvt_seq += 1
                if not self.drop():
                    self.cli.publish(self.t('pvt'), json.dumps(p))
            if self.sd:
                gq = {4: 4, 3: 5, 1: 1}[q]
                row = (f"{p['utc']},{wk},{tow_ms / 1000:.3f},{p['lat']:.9f},{p['lon']:.9f},120.000,147.600,{q},{STATUS[q]},3,"
                       f"{p['carr']},{sv},{sd:.3f},{sd * 1.6:.3f},{p['slat']:.3f},{p['slon']:.3f},{p['salt']:.3f},{gq},0.70,"
                       f"{'1.0' if q >= 2 else ''},{self.a.speed:.3f},{hdg:.2f},1.30\n")
                with self.lock:
                    self.sd['pos'].write(row)
            if now - last_status >= 1.0:
                last_status = now
                st = {'id': self.id, 'online': True, 'fw': 'sim-2.0', 'up': int(now) % 100000, 'ssid': 'SimHotspot',
                      'rssi': random.randint(-70, -50), 'ip': '127.0.0.1', 'ap': False, 'broker': 'sim', 'file': self.file,
                      'ntrip': {'en': True, 'ok': q >= 3, 'age': 1.0, 'kb': self.pvt_seq // 10, 'err': '', 'mount': 'SIM'},
                      'gnss': {'cfg': True, 'hz': 10.0, 'rawx_hz': 10.0, 'q': q, 'sv': sv, 'nmea_bad': 0, 'u2_kb': self.pvt_seq * 2},
                      'imu': {'ok': True, 'hz': 200.0, 'maxdt': 5.3, 'err': 0}, 'time': {'valid': True, 'pps': True},
                      'vib': self.vib, 'sd': {'ok': bool(self.sd), 'free_mb': 30000, 'kb_raw': 0, 'kb_pos': 0, 'kb_imu': 0},
                      'sess': self.sess, 'sess_s': int(now - self.sess_t0) if self.sess else 0, 'raw_1hz': 1, 'pvt_hz': self.pvt_hz,
                      'drop': {'sd': 0, 'mq': 0}, 'heap': 120000}
                self.cli.publish(self.t('status'), json.dumps(st), retain=True)
                if self.sd:
                    with self.lock:
                        for f in self.sd.values():
                            f.flush()

    # ---------------------------------------------------------- IMU 200 Hz (SD) + ringkasan 5 Hz (web)
    def imu_loop(self):
        nxt = time.time()
        sq, acc, first = [], [], None
        while not self.stop_evt.is_set():
            nxt += 0.005
            time.sleep(max(0.0, nxt - time.time()))
            now = time.time()
            wk, tow = fl.unix_to_gps(now)
            bump = self.pose(now)[3]
            amp = 2.5 if bump else 0.35
            a = [random.gauss(0, 0.03), random.gauss(0, 0.03), 9.80665 + amp * math.sqrt(2) * math.sin(2 * math.pi * 45 * now) + random.gauss(0, 0.05)]
            g = [random.gauss(0, 0.002), random.gauss(0, 0.002), math.radians(1.5) * math.sin(now * 0.3)]
            if self.sd:
                with self.lock:
                    self.sd['imu'].write(f'{wk},{tow:.6f},{a[0]:.4f},{a[1]:.4f},{a[2]:.4f},{g[0]:.6f},{g[1]:.6f},{g[2]:.6f},30.00,3\n')
            sq.append(a[2] - 9.80665)
            if len(sq) >= 200:
                self.vib = round(math.sqrt(sum(x * x for x in sq) / len(sq)), 3)
                sq = []
            if first is None:
                first = (wk, tow)
            acc.append(a + g)
            if len(acc) >= 40:
                m = [sum(r[k] for r in acc) / len(acc) for k in range(6)]
                msg = {'id': self.id, 'seq': self.imu_seq, 'wk': first[0], 'tow': round(first[1], 3),
                       'ax': round(m[0], 4), 'ay': round(m[1], 4), 'az': round(m[2], 4),
                       'gx': round(m[3], 5), 'gy': round(m[4], 5), 'gz': round(m[5], 5), 'n': len(acc), 'vib': self.vib, 'tflag': 3}
                self.imu_seq += 1
                acc, first = [], None
                if not self.drop():
                    self.cli.publish(self.t('imu'), json.dumps(msg))

    # ---------------------------------------------------------- UART2: RAWX 10 Hz + SFRBX
    def rawx(self, now):
        wk, tow = fl.unix_to_gps(now)
        meas = []
        for k in range(36):
            gnss = [0, 2, 6][k % 3]
            meas.append(struct.pack('<ddfBBBBHBBBBBB', 2.2e7 + 1000 * k + random.random(), 1.1e8 + k, -500.0 + k, gnss,
                                    1 + k // 3, k % 2, 7 if gnss == 6 else 0, 40000, 42, 4, 3, 2, 0x0F, 0))
        pl = struct.pack('<dHbBBBH', round(tow, 3), wk, 18, len(meas), 1, 1, 0) + b''.join(meas)
        return fl.ubx_frame(0x02, 0x15, pl), int(round(tow * 1000))

    def raw_loop(self):
        nxt = math.ceil(time.time() * 10) / 10
        pend = None
        while not self.stop_evt.is_set():
            nxt += 0.1
            time.sleep(max(0.0, nxt - time.time()))
            now = round(time.time(), 1)
            if self._flush_req:
                if pend is not None:
                    self.send_raw(pend)
                pend = None
                self._flush_req = False
            rx, tow_ms = self.rawx(now)
            sf = [fl.ubx_frame(0x02, 0x13, struct.pack('<BBBBBBBB', 0, 5 + i, 0, 0, 10, i, 2, 0) + bytes(40)) for i in range(2)]
            if self.sd:
                with self.lock:
                    for fr in [rx] + sf:
                        self.sd['raw'].write(fr)
            if not self.sess:
                pend = None
                continue
            if tow_ms % 1000 == 0:          # RAWX detik bulat -> paket baru; kirim paket detik sebelumnya
                if pend is not None:
                    self.send_raw(pend)
                pend = [tow_ms, rx]
            if pend is not None:
                pend.extend(sf)

    def send_raw(self, pend):
        with self.lock:
            if not self.sess:
                return
            pkt = fl.RAW_HDR.pack(b'FOBR', 1, 0, 0, self.raw_seq, pend[0]) + b''.join(pend[1:])
            self.raw_seq += 1
        if not self.drop():
            self.cli.publish(self.t('raw'), pkt)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--broker', default='mqtt://127.0.0.1:1883', help='mqtt://, mqtts://, ws:// atau wss://host:port[/path]')
    ap.add_argument('--user', default='')
    ap.add_argument('--password', default='')
    ap.add_argument('--prefix', default='fobos')
    ap.add_argument('--id', default='FM01', help='satu atau beberapa ID dipisah koma')
    ap.add_argument('--lat', type=float, default=-7.7713)
    ap.add_argument('--lon', type=float, default=110.3775)
    ap.add_argument('--speed', type=float, default=8.0, help='m/s')
    ap.add_argument('--loss', type=float, default=0.0, help='peluang pesan sengaja dibuang (uji kelengkapan)')
    ap.add_argument('--sd-dir', default='', help='folder untuk menulis berkas tiruan kartu SD (satu set per ID)')
    ap.add_argument('--duration', type=float, default=0, help='detik (0 = sampai Ctrl+C)')
    a = ap.parse_args()
    ids = [i.strip() for i in a.id.split(',') if i.strip()]
    devs = []
    for k, i in enumerate(ids):
        sub = argparse.Namespace(**vars(a))
        if a.sd_dir and len(ids) > 1:
            sub.sd_dir = os.path.join(a.sd_dir, i)
        devs.append(SimDevice(i, sub, k))
    for d in devs:
        threading.Thread(target=d.run, daemon=True).start()
    t0 = time.time()
    try:
        while not a.duration or time.time() - t0 < a.duration:
            time.sleep(0.5)
    except KeyboardInterrupt:
        pass
    for d in devs:
        if d.sess:
            d.stop()
        d.stop_evt.set()
        d.cli.publish(d.t('status'), json.dumps({'id': d.id, 'online': False}), retain=True)
        time.sleep(0.3)
        if d.sd:
            for f in d.sd.values():
                f.close()
        d.cli.loop_stop()


if __name__ == '__main__':
    main()
