"""fobos_lib.py — fungsi bersama alat Python Fobos Mini v2 (UBX, waktu GPS, berkas SD/web)."""
import csv
import struct

GPS_EPOCH_UNIX = 315964800      # 1980-01-06 00:00:00 UTC
GPS_UTC_LEAP_S = 18             # GPS - UTC sejak 2017-01-01
WEEK_S = 604800

RAW_HDR = struct.Struct('<4sBBHII')        # paket web "FOBR": 16 byte


def unix_to_gps(t_unix):
    g = t_unix - GPS_EPOCH_UNIX + GPS_UTC_LEAP_S
    wk = int(g // WEEK_S)
    return wk, g - wk * WEEK_S


def gps_to_unix(week, tow):
    return GPS_EPOCH_UNIX + week * WEEK_S + tow - GPS_UTC_LEAP_S


# ------------------------------------------------------------------ UBX
def ubx_frame(cls, mid, payload):
    body = bytes([cls, mid]) + struct.pack('<H', len(payload)) + payload
    a = b = 0
    for x in body:
        a = (a + x) & 0xFF
        b = (b + a) & 0xFF
    return b'\xb5\x62' + body + bytes([a, b])


def iter_ubx(data):
    """Iterasi (cls, id, payload, frame) dari aliran byte UBX; byte lain dilewati."""
    i, n = 0, len(data)
    while i + 8 <= n:
        if data[i] != 0xB5 or data[i + 1] != 0x62:
            j = data.find(b'\xb5\x62', i + 1)
            if j < 0:
                break
            i = j
            continue
        ln = data[i + 4] | (data[i + 5] << 8)
        if ln > 8192:
            i += 1
            continue
        if i + 8 + ln > n:
            break
        body = data[i + 2:i + 6 + ln]
        a = b = 0
        for x in body:
            a = (a + x) & 0xFF
            b = (b + a) & 0xFF
        if data[i + 6 + ln] == a and data[i + 7 + ln] == b:
            yield data[i + 2], data[i + 3], data[i + 6:i + 6 + ln], data[i:i + 8 + ln]
            i += 8 + ln
        else:
            i += 1


def rawx_head(pl):
    rcvtow, week, leaps, nummeas = struct.unpack_from('<dHbB', pl, 0)
    return rcvtow, week, nummeas


# ------------------------------------------------------------------ berkas CSV
def _f(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def read_csv(path):
    with open(path, newline='', errors='replace') as f:
        return list(csv.DictReader(f))


def abs_time(row, wk_key='gps_week', tow_key='tow_s'):
    """Waktu GPS mutlak [s] dari kolom minggu + detik-minggu; None bila belum valid."""
    wk, tow = _f(row.get(wk_key)), _f(row.get(tow_key))
    if wk is None or tow is None or wk <= 0:
        return None
    return wk * WEEK_S + tow


def imu_rows(path):
    """Baris IMU SD (_imu.csv 200 Hz) atau web (_imu5hz.csv): dict + 't' waktu GPS mutlak."""
    for r in read_csv(path):
        t = abs_time(r)
        r['t'] = t
        yield r
