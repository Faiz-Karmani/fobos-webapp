#!/usr/bin/env python3
"""fobos_post.py — olah data Fobos Mini v2 setelah pengambilan data.

Berkas kartu SD (satu set per nyala, tidak pernah menimpa):
  F0007_raw.ubx    salinan mentah UART2 ZED-F9P (RAWX + SFRBX)
  F0007_pos.csv    posisi hasil parse UART1 (NAV-PVT + GGA + GST)
  F0007_imu.csv    IMU 200 Hz (m/s², rad/s) dengan waktu GPS
  F0007_event.csv  kejadian: BOOT, WIFI, NTRIP, REC_START/REC_STOP (penanda Record dari web)

Subperintah:
  check        ringkasan & kelengkapan berkas (folder SD, satu set F####, atau berkas unduhan web)
  cut          potong bagian sesi Record dari berkas SD memakai penanda di _event.csv
  rinex        .ubx -> RINEX obs/nav lewat convbin (RTKLIB)
  pos2geojson  _pos.csv (SD) / _web_posisi.csv -> GeoJSON
  imu2kfgins   _imu.csv (200 Hz) -> berkas IMU KF-GINS (detik-minggu, inkremen, sumbu depan-kanan-bawah)
  pos2kfgins   .pos RTKLIB (PPK) atau _pos.csv (solusi RTK ZED) -> berkas GNSS KF-GINS
  allan        deviasi Allan dari rekaman IMU DIAM (ARW/VRW & ketidakstabilan bias)
  kfgins-yaml  membuat kf-gins.yaml awal

Contoh:
  python fobos_post.py check E:/
  python fobos_post.py cut E:/ --sess FM01_20261112_081500 -o sesi
  python fobos_post.py rinex sesi/FM01_20261112_081500_sd_raw.ubx
  python fobos_post.py imu2kfgins sesi/FM01_20261112_081500_sd_imu.csv --axes "x,-y,-z"
"""
import argparse
import glob
import json
import math
import os
import re
import shutil
import statistics
import subprocess
import sys

import fobos_lib as fl

Q_NAMES = {4: 'FIX', 3: 'FLOAT', 2: 'DGNSS', 1: 'SINGLE', 0: 'TANPA_FIX'}


def read(p):
    with open(p, 'rb') as f:
        return f.read()


def gaps(ts, factor=1.5):
    dts = [b - a for a, b in zip(ts, ts[1:])]
    if not dts:
        return 0, 0, []
    med = statistics.median(dts)
    g = [d for d in dts if med > 0 and d > factor * med]
    return med, sum(1 for d in dts if d <= 0), g


# ------------------------------------------------------------------ check
def sets_in(path):
    """Kumpulkan set berkas: {nama_set: {raw,pos,imu,event}}."""
    out = {}
    files = glob.glob(os.path.join(path, '*')) if os.path.isdir(path) else [path]
    for f in sorted(files):
        b = os.path.basename(f)
        m = re.match(r'(.+?)_(raw\.ubx|pos\.csv|imu\.csv|event\.csv)$', b) or \
            re.match(r'(.+?)_(web_rawx1hz\.ubx|web_posisi\.csv|web_imu5hz\.csv|sd_raw\.ubx|sd_pos\.csv|sd_imu\.csv)$', b)
        if not m:
            continue
        kind = m.group(2).split('.')[0].replace('web_', '').replace('sd_', '')
        kind = {'rawx1hz': 'raw', 'posisi': 'pos', 'imu5hz': 'imu'}.get(kind, kind)
        out.setdefault(m.group(1), {})[kind] = f
    return out


def check_ubx(p):
    data = read(p)
    cnt, ts, nmeas = {}, [], []
    for c, i, pl, _f in fl.iter_ubx(data):
        k = {(2, 0x15): 'RXM-RAWX', (2, 0x13): 'RXM-SFRBX', (1, 7): 'NAV-PVT'}.get((c, i), f'{c:02X}-{i:02X}')
        cnt[k] = cnt.get(k, 0) + 1
        if k == 'RXM-RAWX':
            t, wk, n = fl.rawx_head(pl)
            ts.append(wk * fl.WEEK_S + t)
            nmeas.append(n)
    print(f'  UBX  {os.path.basename(p)}  {len(data) / 1e6:.2f} MB  ' + ', '.join(f'{k} {v}' for k, v in sorted(cnt.items())))
    if ts:
        med, back, g = gaps(ts)
        print(f'       RAWX {1 / med if med else 0:.1f} Hz, rentang {ts[-1] - ts[0]:.1f} s, celah {len(g)}'
              f'{f" (terbesar {max(g):.1f} s)" if g else ""}, sinyal/epoch {statistics.mean(nmeas):.1f}')
    elif not cnt:
        print('       (tidak ada frame UBX valid — cek baud UART2 di u-center vs U2_BAUD)')


def check_pos(p):
    rows = fl.read_csv(p)
    ts = [t for t in (fl.abs_time(r) for r in rows) if t is not None]
    qs = {}
    for r in rows:
        q = int(float(r.get('q') or 0))
        qs[q] = qs.get(q, 0) + 1
    print(f'  POS  {os.path.basename(p)}  {len(rows)} baris')
    if ts:
        med, back, g = gaps(ts)
        print(f'       {1 / med if med else 0:.1f} Hz, rentang {ts[-1] - ts[0]:.1f} s, celah {len(g)}')
    if rows:
        tot = len(rows)
        print('       kualitas: ' + ', '.join(f'{Q_NAMES.get(q, q)} {100 * n / tot:.1f}%' for q, n in sorted(qs.items(), reverse=True)))
        sl = [fl._f(r.get('std_lat')) for r in rows if fl._f(r.get('std_lat')) is not None]
        if sl:
            print(f'       GST std_lat median {statistics.median(sl) * 100:.1f} cm (dari {len(sl)} epoch)')
        else:
            print('       tidak ada nilai GST (pastikan GST diaktifkan di UART1 lewat u-center)')


def check_imu(p):
    rows = list(fl.imu_rows(p))
    ts = [r['t'] for r in rows if r['t'] is not None]
    tf = {}
    for r in rows:
        tf[r.get('tflag')] = tf.get(r.get('tflag'), 0) + 1
    print(f'  IMU  {os.path.basename(p)}  {len(rows)} baris')
    if ts:
        med, back, g = gaps(ts)
        print(f'       {1 / med if med else 0:.1f} Hz, rentang {ts[-1] - ts[0]:.1f} s, jeda > 1,5x median {len(g)}'
              f'{f" (terbesar {max(g) * 1000:.0f} ms)" if g else ""}, waktu mundur {back}')
    tot = max(1, len(rows))
    print(f'       waktu: GPS+PPS {100 * tf.get("3", 0) / tot:.1f}%, GPS tanpa PPS {100 * tf.get("1", 0) / tot:.1f}%,'
          f' belum sinkron {100 * tf.get("0", 0) / tot:.1f}%')


def read_events(p):
    return fl.read_csv(p) if p and os.path.exists(p) else []


def sessions_from_events(evs):
    out, open_ = [], {}
    for e in evs:
        t = fl.abs_time(e)
        if e.get('kejadian') == 'REC_START':
            open_[e.get('keterangan')] = (t, e.get('utc'))
        elif e.get('kejadian') == 'REC_STOP':
            name = e.get('keterangan')
            t0, u0 = open_.pop(name, (None, None))
            out.append({'sess': name, 't0': t0, 't1': t, 'utc0': u0, 'utc1': e.get('utc')})
    for name, (t0, u0) in open_.items():
        out.append({'sess': name, 't0': t0, 't1': None, 'utc0': u0, 'utc1': None})
    return out


def cmd_check(a):
    for path in a.paths:
        for name, fs in sets_in(path).items():
            print(f'\n== {name}')
            if 'raw' in fs:
                check_ubx(fs['raw'])
            if 'pos' in fs:
                check_pos(fs['pos'])
            if 'imu' in fs:
                check_imu(fs['imu'])
            for s in sessions_from_events(read_events(fs.get('event'))):
                dur = f'{s["t1"] - s["t0"]:.0f} s' if s['t0'] and s['t1'] else 'tanpa REC_STOP'
                print(f'  REC  {s["sess"]}  {s["utc0"]} -> {s["utc1"]}  ({dur})')


# ------------------------------------------------------------------ cut
def cut_ubx(src, dst, t0, t1):
    data = read(src)
    out, cur, n = bytearray(), None, 0
    for c, i, pl, fr in fl.iter_ubx(data):
        if (c, i) == (2, 0x15):
            t, wk, _ = fl.rawx_head(pl)
            cur = wk * fl.WEEK_S + t
        if cur is None or cur < t0 or (t1 is not None and cur > t1):
            continue
        out += fr
        n += 1
    with open(dst, 'wb') as f:
        f.write(out)
    return n


def cut_csv(src, dst, t0, t1):
    import csv
    n = 0
    with open(src, newline='', errors='replace') as fi, open(dst, 'w', newline='') as fo:
        rd = csv.DictReader(fi)
        wr = csv.DictWriter(fo, fieldnames=rd.fieldnames)
        wr.writeheader()
        for r in rd:
            t = fl.abs_time(r)
            if t is None or t < t0 or (t1 is not None and t > t1):
                continue
            wr.writerow(r)
            n += 1
    return n


def cmd_cut(a):
    os.makedirs(a.out, exist_ok=True)
    done = 0
    for name, fs in sets_in(a.sd).items():
        if a.set and name != a.set:
            continue
        for s in sessions_from_events(read_events(fs.get('event'))):
            if a.sess and s['sess'] != a.sess:
                continue
            if s['t0'] is None:
                print(f'{s["sess"]}: penanda tanpa waktu GPS valid (Record dimulai sebelum fix) — dilewati')
                continue
            base = os.path.join(a.out, f'{s["sess"]}_sd')
            print(f'{s["sess"]} dari {name}:')
            if 'raw' in fs:
                print(f'  {cut_ubx(fs["raw"], base + "_raw.ubx", s["t0"] - a.pad, s["t1"] + a.pad if s["t1"] else None)} frame -> {base}_raw.ubx')
            if 'pos' in fs:
                print(f'  {cut_csv(fs["pos"], base + "_pos.csv", s["t0"] - a.pad, s["t1"] + a.pad if s["t1"] else None)} baris -> {base}_pos.csv')
            if 'imu' in fs:
                print(f'  {cut_csv(fs["imu"], base + "_imu.csv", s["t0"] - a.pad, s["t1"] + a.pad if s["t1"] else None)} baris -> {base}_imu.csv')
            done += 1
    if not done:
        print('tidak ada sesi Record yang cocok di _event.csv')


# ------------------------------------------------------------------ RINEX, GeoJSON
def cmd_rinex(a):
    exe = a.convbin or shutil.which('convbin') or shutil.which('convbin.exe')
    base = os.path.splitext(a.ubx)[0]
    args = [exe or 'convbin', '-r', 'ubx', '-v', '3.04', '-od', '-os', '-oi', '-ot', '-ol',
            '-o', base + '.obs', '-n', base + '.nav', a.ubx]
    if not exe:
        print('convbin (RTKLIB) tidak ditemukan. Unduh RTKLIB demo5 (rtklibexplorer) lalu jalankan:')
        print('  ' + ' '.join(args))
        print('atau pakai RTKCONV (GUI) dengan format "u-blox".')
        return 1
    print(' '.join(args))
    return subprocess.call(args)


def cmd_pos2geojson(a):
    rows = fl.read_csv(a.pos)
    feats = []
    for r in rows:
        lat, lon = fl._f(r.get('lat')), fl._f(r.get('lon'))
        q = int(float(r.get('q') or 0))
        if lat is None or lon is None or q < a.min_q:
            continue
        feats.append({'type': 'Feature', 'geometry': {'type': 'Point', 'coordinates': [lon, lat, fl._f(r.get('h_ell'))]},
                      'properties': dict(r)})
    out = a.out or os.path.splitext(a.pos)[0] + '.geojson'
    with open(out, 'w') as f:
        json.dump({'type': 'FeatureCollection', 'features': feats}, f)
    print(f'{len(feats)} titik -> {out}')


# ------------------------------------------------------------------ KF-GINS
def parse_axes(spec):
    m = {'x': 0, 'y': 1, 'z': 2}
    out = []
    for s in spec.replace(' ', '').lower().split(','):
        out.append((m[s.lstrip('+-')], -1 if s.startswith('-') else 1))
    if len(out) != 3 or len({o[0] for o in out}) != 3:
        raise SystemExit('format --axes salah, contoh: "x,-y,-z"')
    return out


def cmd_imu2kfgins(a):
    ax_map = parse_axes(a.axes)
    out = a.out or os.path.splitext(a.imu)[0] + '_kfgins.txt'
    rows = [r for r in fl.imu_rows(a.imu) if r['t'] is not None and r.get('tflag') in ('1', '3')]
    rows.sort(key=lambda r: r['t'])
    if not rows:
        raise SystemExit('tidak ada sampel IMU dengan waktu GPS valid (tflag 1/3)')
    if len({int(float(r['gps_week'])) for r in rows}) > 1:
        print('PERINGATAN: data melewati pergantian minggu GPS; KF-GINS memakai detik-minggu.')
    n = skipped = 0
    prev = None
    with open(out, 'w') as f:
        for r in rows:
            if prev is None:
                prev = r['t']
                continue
            dt = r['t'] - prev
            prev = r['t']
            if dt <= 0 or dt > a.max_dt:
                skipped += 1
                continue
            acc = [float(r['ax']), float(r['ay']), float(r['az'])]
            gyr = [float(r['gx']), float(r['gy']), float(r['gz'])]
            g = [gyr[i] * s for i, s in ax_map]
            v = [acc[i] * s for i, s in ax_map]
            f.write(f'{float(r["tow_s"]):.6f} {g[0] * dt:.10e} {g[1] * dt:.10e} {g[2] * dt:.10e} {v[0] * dt:.10e} {v[1] * dt:.10e} {v[2] * dt:.10e}\n')
            n += 1
    print(f'{n} baris -> {out}  (dilewati {skipped}: jeda > {a.max_dt} s atau waktu mundur)')
    pps = sum(1 for r in rows if r.get('tflag') == '3') / len(rows)
    if pps < 0.99:
        print(f'PERINGATAN: hanya {100 * pps:.1f}% sampel tersinkron PPS; sisanya waktu dari NAV-PVT (lebih kasar).')
    if a.axes == 'x,y,z':
        print('CATATAN: --axes belum diatur. KF-GINS butuh sumbu depan-kanan-bawah; sesuaikan dengan pemasangan ICM-20948.')


def cmd_pos2kfgins(a):
    out = a.out or os.path.splitext(a.pos)[0] + '_kfgins_gnss.txt'
    n = 0
    with open(out, 'w') as fo:
        if a.pos.lower().endswith('.csv'):        # solusi RTK ZED dari _pos.csv
            for r in fl.read_csv(a.pos):
                q = int(float(r.get('q') or 0))
                if q < a.min_q:
                    continue
                sn, se, su = fl._f(r.get('std_lat')), fl._f(r.get('std_lon')), fl._f(r.get('std_alt'))
                if sn is None:      # tanpa GST: pakai hAcc/vAcc ZED
                    sn = se = (fl._f(r.get('h_acc')) or 1.0) / math.sqrt(2)
                    su = fl._f(r.get('v_acc')) or 2.0
                fo.write(f'{float(r["tow_s"]):.3f} {float(r["lat"]):.9f} {float(r["lon"]):.9f} {float(r["h_ell"]):.4f} {sn:.4f} {se:.4f} {su:.4f}\n')
                n += 1
            print(f'{n} epoch -> {out}  (dari _pos.csv, q >= {a.min_q}; 4=FIX 3=FLOAT)')
            return
        import datetime as dtm
        for line in open(a.pos, errors='replace'):    # RTKLIB .pos (lat/lon/height)
            if line.startswith('%') or not line.strip():
                continue
            s = line.split()
            if '/' in s[0]:
                ts = dtm.datetime.strptime(s[0] + ' ' + s[1], '%Y/%m/%d %H:%M:%S.%f').replace(tzinfo=dtm.timezone.utc)
                g = ts.timestamp() - fl.GPS_EPOCH_UNIX
                tow = g - int(g // fl.WEEK_S) * fl.WEEK_S
            else:
                tow = float(s[1])
            lat, lon, h, q = float(s[2]), float(s[3]), float(s[4]), int(s[5])
            sdn, sde, sdu = float(s[7]), float(s[8]), float(s[9])
            if q > a.max_q:            # RTKLIB: 1 fix, 2 float, 5 single
                continue
            fo.write(f'{tow:.3f} {lat:.9f} {lon:.9f} {h:.4f} {sdn:.4f} {sde:.4f} {sdu:.4f}\n')
            n += 1
    print(f'{n} epoch -> {out}  (Q RTKLIB <= {a.max_q}; 1=fix 2=float 5=single)')


def adev(x, fs, taus_n):
    import numpy as np
    theta = np.cumsum(x) / fs
    out = []
    for m in taus_n:
        if 2 * m >= len(theta):
            break
        d = theta[2 * m:] - 2 * theta[m:-m] + theta[:-2 * m]
        tau = m / fs
        out.append((tau, math.sqrt(np.sum(d * d) / (2 * tau * tau * len(d)))))
    return out


def cmd_allan(a):
    import numpy as np
    rows = [r for r in fl.imu_rows(a.imu) if r['t'] is not None]
    if len(rows) < 2000:
        raise SystemExit('data terlalu pendek; rekam IMU diam minimal 30 menit (lebih baik 2-3 jam)')
    t = np.array([r['t'] for r in rows])
    fs = 1.0 / np.median(np.diff(t))
    names = ['ax', 'ay', 'az', 'gx', 'gy', 'gz']
    data = np.array([[float(r[k]) for k in names] for r in rows])
    taus_n = sorted({int(round(10 ** e)) for e in np.arange(0, math.log10(len(rows) / 3), 0.1)})
    res = {'durasi_s': float(t[-1] - t[0]), 'fs_hz': float(fs), 'sumbu': {}}
    print(f'durasi {(t[-1] - t[0]) / 60:.1f} menit, fs {fs:.1f} Hz')
    for k, nm in enumerate(names):
        ad = adev(data[:, k] - data[:, k].mean(), fs, taus_n)
        taus = np.array([x[0] for x in ad])
        sig = np.array([x[1] for x in ad])
        N = 10 ** float(np.interp(0.0, np.log10(taus), np.log10(sig)))   # ADEV pada tau = 1 s
        B = float(sig.min()) / 0.664
        if nm.startswith('g'):
            item = {'ARW_deg_sqrt_h': N * 180 / math.pi * 60, 'bias_instab_deg_h': B * 180 / math.pi * 3600}
        else:
            item = {'VRW_m_s_sqrt_h': N * 60, 'bias_instab_mGal': B * 1e5}
        res['sumbu'][nm] = item
        print(f'  {nm}: ' + ', '.join(f'{k2} {v:.4g}' for k2, v in item.items()))
    out = a.out or os.path.splitext(a.imu)[0] + '_allan.json'
    with open(out, 'w') as f:
        json.dump(res, f, indent=2)
    print(f'-> {out}  (ketidakstabilan bias = min ADEV / 0,664; titik awal gbstd/abstd KF-GINS)')


def cmd_kfgins_yaml(a):
    import numpy as np
    g = [list(map(float, ln.split())) for ln in open(a.gnss) if ln.strip()]
    if not g:
        raise SystemExit('berkas GNSS kosong')
    t0, lat0, lon0, h0 = g[0][:4]
    yaw = None
    for row in g[1:]:
        dn = math.radians(row[1] - lat0) * 6378137.0
        de = math.radians(row[2] - lon0) * 6378137.0 * math.cos(math.radians(lat0))
        if math.hypot(dn, de) > 3.0:
            yaw = (math.degrees(math.atan2(de, dn)) + 360) % 360
            break
    roll = pitch = 0.0
    if a.imu:
        imu_t, acc = [], []
        for ln in open(a.imu):
            s = ln.split()
            if float(s[0]) < t0 - 1:
                continue
            imu_t.append(float(s[0]))
            acc.append([float(x) for x in s[4:7]])
            if len(acc) > 1 and imu_t[-1] - imu_t[0] >= 1.0:
                break
        if len(acc) > 10:
            dt = np.diff(imu_t).mean()
            f = np.array(acc).mean(axis=0) / dt
            roll = math.degrees(math.atan2(-f[1], -f[2]))
            pitch = math.degrees(math.atan2(f[0], math.hypot(f[1], f[2])))
    noise = {'arw': 0.9, 'vrw': 0.135, 'gbstd': 'ISI', 'abstd': 'ISI'}
    src = 'ARW/VRW dari datasheet ICM-20948 (0,015 °/s/√Hz; 230 µg/√Hz)'
    if a.allan:
        al = json.load(open(a.allan))['sumbu']
        noise = {'arw': max(al[k]['ARW_deg_sqrt_h'] for k in ('gx', 'gy', 'gz')),
                 'vrw': max(al[k]['VRW_m_s_sqrt_h'] for k in ('ax', 'ay', 'az')),
                 'gbstd': max(al[k]['bias_instab_deg_h'] for k in ('gx', 'gy', 'gz')),
                 'abstd': max(al[k]['bias_instab_mGal'] for k in ('ax', 'ay', 'az'))}
        src = f'uji Allan {a.allan}'

    def v3(x):
        return f'[{x}, {x}, {x}]' if isinstance(x, str) else f'[{x:.4g}, {x:.4g}, {x:.4g}]'

    yaw_s = f'{yaw:.2f}' if yaw is not None else 'ISI_YAW'
    txt = f"""# kf-gins.yaml untuk Fobos Mini — dibuat fobos_post.py. PERIKSA SEMUA NILAI sebelum dipakai.
# Path tidak boleh mengandung karakter non-ASCII (keterbatasan KF-GINS di Windows).
imupath: "{a.imu or 'ISI_PATH_IMU_KFGINS.txt'}"
gnsspath: "{a.gnss}"
outputpath: "./hasil"
imudatalen: 7
imudatarate: 200
starttime: {t0:.3f}
endtime: -1
initpos: [ {lat0:.9f}, {lon0:.9f}, {h0:.3f} ]
initvel: [ 0.0, 0.0, 0.0 ]          # isi bila mulai dalam keadaan bergerak
# roll/pitch dari rata-rata akselerometer 1 s pertama; yaw dari arah gerak GNSS (>3 m) — ESTIMASI KASAR
initatt: [ {roll:.2f}, {pitch:.2f}, {yaw_s} ]
initgyrbias: [ 0, 0, 0 ]
initaccbias: [ 0, 0, 0 ]
initgyrscale: [ 0, 0, 0 ]
initaccscale: [ 0, 0, 0 ]
initposstd: [ 0.05, 0.05, 0.1 ]
initvelstd: [ 0.1, 0.1, 0.1 ]
initattstd: [ 1.0, 1.0, 5.0 ]
# Derau IMU — sumber: {src}
# gbstd/abstd 'ISI' wajib diisi (jalankan: fobos_post.py allan <rekaman_diam_imu.csv>)
imunoise:
  arw: {v3(noise['arw'])}         # [deg/sqrt(hr)]
  vrw: {v3(noise['vrw'])}         # [m/s/sqrt(hr)]
  gbstd: {v3(noise['gbstd'])}     # [deg/hr]
  abstd: {v3(noise['abstd'])}     # [mGal]
  gsstd: [1000.0, 1000.0, 1000.0] # [ppm] asumsi longgar MEMS konsumen — sesuaikan
  asstd: [1000.0, 1000.0, 1000.0] # [ppm] asumsi longgar MEMS konsumen — sesuaikan
  corrtime: 1.0                   # [hr] asumsi — sesuaikan
# lengan tuas antena: posisi pusat fase antena dari pusat IMU, sumbu depan-kanan-bawah [m] — UKUR
antlever: [ 0.0, 0.0, 0.0 ]
"""
    out = a.out or 'kf-gins_fobos.yaml'
    open(out, 'w').write(txt)
    print(f'-> {out}')


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = ap.add_subparsers(dest='cmd', required=True)
    p = sp.add_parser('check'); p.add_argument('paths', nargs='+'); p.set_defaults(f=cmd_check)
    p = sp.add_parser('cut'); p.add_argument('sd', help='folder kartu SD (atau salinannya)')
    p.add_argument('--set', help='hanya set ini, mis. F0007'); p.add_argument('--sess', help='nama sesi Record; kosong = semua')
    p.add_argument('--pad', type=float, default=0.0, help='tambahan detik sebelum/sesudah'); p.add_argument('-o', '--out', default='potongan')
    p.set_defaults(f=cmd_cut)
    p = sp.add_parser('rinex'); p.add_argument('ubx'); p.add_argument('--convbin'); p.set_defaults(f=cmd_rinex)
    p = sp.add_parser('pos2geojson'); p.add_argument('pos'); p.add_argument('-o', '--out'); p.add_argument('--min-q', type=int, default=1); p.set_defaults(f=cmd_pos2geojson)
    p = sp.add_parser('imu2kfgins'); p.add_argument('imu'); p.add_argument('-o', '--out')
    p.add_argument('--axes', default='x,y,z', help='sumbu sensor untuk depan,kanan,bawah, mis. "x,-y,-z"')
    p.add_argument('--max-dt', type=float, default=0.05); p.set_defaults(f=cmd_imu2kfgins)
    p = sp.add_parser('pos2kfgins'); p.add_argument('pos', help='.pos RTKLIB atau _pos.csv'); p.add_argument('-o', '--out')
    p.add_argument('--max-q', type=int, default=2, help='RTKLIB: Q maksimum (1 fix, 2 float)')
    p.add_argument('--min-q', type=int, default=3, help='_pos.csv: q minimum (4 FIX, 3 FLOAT)'); p.set_defaults(f=cmd_pos2kfgins)
    p = sp.add_parser('allan'); p.add_argument('imu'); p.add_argument('-o', '--out'); p.set_defaults(f=cmd_allan)
    p = sp.add_parser('kfgins-yaml'); p.add_argument('--gnss', required=True); p.add_argument('--imu'); p.add_argument('--allan')
    p.add_argument('-o', '--out'); p.set_defaults(f=cmd_kfgins_yaml)
    a = ap.parse_args()
    sys.exit(a.f(a) or 0)


if __name__ == '__main__':
    main()
