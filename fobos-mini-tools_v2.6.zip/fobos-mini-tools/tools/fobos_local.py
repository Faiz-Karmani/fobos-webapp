#!/usr/bin/env python3
"""fobos_local.py — server cadangan di laptop: broker MQTT + web app, tanpa internet/akun.

Menjalankan:
  * broker MQTT (amqtt): TCP 1883 untuk Fobos Mini, WebSocket 9001 untuk browser
  * server web statis untuk folder docs/ (web app) di http://IP-laptop:8000

Laptop, Fobos Mini, dan HP penonton harus tersambung ke hotspot/WiFi yang sama.
Peta OpenStreetMap tetap butuh internet; tanpa internet jejak tetap tampil di latar kosong.

  pip install -r requirements.txt
  python fobos_local.py
"""
import argparse
import asyncio
import functools
import http.server
import os
import socket
import threading

from amqtt.broker import Broker

HERE = os.path.dirname(os.path.abspath(__file__))


def lan_ips():
    ips = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('10.255.255.255', 1))       # tidak mengirim paket; hanya memilih antarmuka
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except OSError:
        pass
    return sorted(i for i in ips if not i.startswith('127.')) or ['127.0.0.1']


def serve_web(root, port):
    handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=root)
    handler.log_message = lambda *a, **k: None
    httpd = http.server.ThreadingHTTPServer(('0.0.0.0', port), handler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return httpd


async def run(args):
    cfg = {
        'listeners': {
            'default': {'type': 'tcp', 'bind': f'0.0.0.0:{args.mqtt}'},
            'ws': {'type': 'ws', 'bind': f'0.0.0.0:{args.ws}'},
        },
        'plugins': {'amqtt.plugins.authentication.AnonymousAuthPlugin': {'allow_anonymous': True}},
    }
    broker = Broker(cfg)
    await broker.start()
    serve_web(args.web, args.http)
    ips = lan_ips()
    print('=' * 64)
    print(' Fobos Mini — server lokal BERJALAN (tekan Ctrl+C untuk berhenti)')
    print('=' * 64)
    for ip in ips:
        print(f'  Web app (buka di laptop/HP) : http://{ip}:{args.http}')
    for ip in ips:
        print(f'  Isi MQTT2_HOST di secrets.h : "{ip}"   (port {args.mqtt})')
    print(f'  URL lokal di Pengaturan web  : ws://{ips[0]}:{args.ws}')
    print('  Catatan: izinkan Python di Windows Firewall (jaringan Private) saat diminta.')
    print('=' * 64)
    while True:
        await asyncio.sleep(3600)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--http', type=int, default=8000)
    ap.add_argument('--mqtt', type=int, default=1883)
    ap.add_argument('--ws', type=int, default=9001)
    ap.add_argument('--web', default=os.path.join(HERE, '..', 'docs'))
    args = ap.parse_args()
    args.web = os.path.abspath(args.web)
    try:
        asyncio.run(run(args))
    except KeyboardInterrupt:
        print('\nserver dihentikan')


if __name__ == '__main__':
    main()
