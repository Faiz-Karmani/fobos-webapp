# Membuat aliran UART1 campuran (NMEA + UBX NAV-PVT) untuk menguji fobos_proto.h.
# NAV-PVT dibuat dengan pyubx2; kalimat NMEA ditulis manual dengan checksum.
from pyubx2 import UBXMessage
def nmea(body):
    cs = 0
    for c in body: cs ^= ord(c)
    return f'${body}*{cs:02X}\r\n'.encode()
def pvt(itow, sec, nano, carr):
    return UBXMessage('NAV','NAV-PVT',0, iTOW=itow, year=2026, month=11, day=12, hour=8, min=0, sec=sec,
        validDate=1, validTime=1, fullyResolved=1, tAcc=20, nano=nano, fixType=3, gnssFixOk=1, diffSoln=1, carrSoln=carr,
        numSV=24, lon=110.3776543, lat=-7.7705123, height=180123, hMSL=152456, hAcc=14, vAcc=21,
        velN=1000, velE=2000, velD=-30, gSpeed=2236, headMot=63.43494, sAcc=50, headAcc=1.0, pDOP=1.25).serialize()
out = b''
# epoch 1 (08:00:00.00): NMEA dulu, lalu PVT
out += nmea('GNGGA,080000.00,0746.23074,S,11022.65926,E,4,24,0.62,152.456,M,27.667,M,1.0,0000')
out += nmea('GNRMC,080000.00,A,0746.23074,S,11022.65926,E,5.0,63.4,121126,,,R,V')
out += nmea('GNGST,080000.00,0.80,0.012,0.009,45.0,0.011,0.010,0.025')
out += pvt(288018000, 0, 0, 2)
# sampah di tengah aliran
out += b'\x00\x13garbage$GNXXX,bad*00\r\n'
# epoch 2 (08:00:00.10): PVT dulu, lalu NMEA (urutan terbalik)
out += pvt(288018100, 0, 100000000, 1)
out += nmea('GNGGA,080000.10,0746.23074,S,11022.65926,E,5,23,0.70,152.400,M,27.667,M,1.0,0000')
out += nmea('GNGST,080000.10,0.80,0.15,0.10,45.0,0.140,0.120,0.300')
# epoch 3 hanya PVT (akan keluar lewat batas waktu)
out += pvt(288018200, 0, 200000000, 0)
open('uart1.bin','wb').write(out)
print(len(out), 'byte')
