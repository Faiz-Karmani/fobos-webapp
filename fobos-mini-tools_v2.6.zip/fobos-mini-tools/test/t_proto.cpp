// Uji logika portabel fobos_proto.h v2 di PC
#include "../firmware/FobosMini/fobos_proto.h"
#include <vector>
#include <assert.h>
using namespace fobos;
std::vector<uint8_t> rd(const char*f){FILE*fp=fopen(f,"rb");std::vector<uint8_t>v;int c;while((c=fgetc(fp))!=EOF)v.push_back(c);fclose(fp);return v;}
int main(){
  auto s = rd("uart1.bin");
  GnssMux mux; EpochMerger m; std::vector<Epoch> out; Epoch e; uint32_t t = 1000;
  int nPvt = 0, nGga = 0, nGst = 0;
  for (auto b : s) {
    int ev = mux.feed(b);
    if (ev == GnssMux::UBX && mux.ubx.cls == 1 && mux.ubx.id == 7) {
      Pvt p; assert(decodePvt(mux.ubx.payload(), mux.ubx.len, p)); nPvt++;
      t += 100; if (m.onPvt(p, t, e)) out.push_back(e);
    } else if (ev == GnssMux::NMEA) {
      if (nmeaIs(mux.line, "GGA")) { GgaRec g; assert(parseGga(mux.line, g)); m.addGga(g); nGga++; }
      if (nmeaIs(mux.line, "GST")) { GstRec g; assert(parseGst(mux.line, g)); m.addGst(g); nGst++; }
    }
  }
  assert(!m.poll(t + 50, 150, e));
  assert(m.poll(t + 200, 150, e)); out.push_back(e);
  printf("PVT %d GGA %d GST %d, NMEA ok %u rusak %u, epoch keluar %zu\n", nPvt, nGga, nGst, mux.nNmeaOk, mux.nNmeaBad, out.size());
  assert(nPvt == 3 && nGga == 2 && nGst == 2 && mux.nNmeaBad == 1 && out.size() == 3);
  // epoch 1: GST/GGA datang SEBELUM PVT
  assert(out[0].gga.q == 4 && fabs(out[0].gst.sLat - 0.011) < 1e-6 && fabs(out[0].gst.sAlt - 0.025) < 1e-6);
  // epoch 2: GST/GGA datang SESUDAH PVT
  assert(out[1].gga.q == 5 && fabs(out[1].gst.sLon - 0.120) < 1e-6);
  // epoch 3: tanpa NMEA
  assert(out[2].gga.cs < 0 && isnan(out[2].gst.sLat));
  assert(qualityClass(out[0].p) == 4 && qualityClass(out[1].p) == 3);
  char line[400];
  for (auto &x : out) { posCsvLine(line, sizeof(line), x, 2444); printf("%s", line); }
  pvtJson(line, sizeof(line), "FM01", 1, out[1], 2444, 0.42, "S1"); printf("%s\n", line);
  float a[3] = {0.1f, -0.2f, 9.8f}, g[3] = {0.001f, 0.002f, -0.003f};
  imuCsvLine(line, sizeof(line), 2444, 288018.005, a, g, 31.2f, 3); printf("%s", line);
  imuJson(line, sizeof(line), "FM01", 7, 2444, 288018.0, a, g, 40, NAN, 3); printf("%s\n", line);
  char gga[100]; ggaFromPvt(out[0].p, gga, 100); printf("%s", gga); assert(nmeaChecksumOk(gga));
  VibAcc va; for(int i=0;i<200;i++){double s2=sqrt(2.0)*sin(2*M_PI*45*i/200.0); double u=1/sqrt(2.0); va.add(0.0, 6.93+s2*u, 6.93+s2*u);} printf("vib rms %.4f (harap 1.0)\n",va.rms());
  assert(fabs(va.rms() - 1.0) < 0.01);
  printf("SEMUA UJI LULUS\n");
}
