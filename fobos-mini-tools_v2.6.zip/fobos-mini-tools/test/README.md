# Uji logika firmware di PC

```bash
pip install pyubx2
cd test
python gen_ref.py        # membuat aliran UART1 campuran (NMEA GGA/RMC/GST + NAV-PVT) -> uart1.bin
g++ -std=c++17 -O1 t_proto.cpp -o t_proto && ./t_proto
# cek sintaks firmware terhadap tiruan API Arduino (bukan pengganti kompilasi ESP32 asli):
g++ -std=gnu++17 -fsyntax-only -I mock -I ../firmware/FobosMini -x c++ ../firmware/FobosMini/FobosMini.ino
```
