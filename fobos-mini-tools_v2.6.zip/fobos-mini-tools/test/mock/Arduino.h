// Mock minimal Arduino-ESP32 untuk cek sintaks di PC (bukan pengganti kompilasi asli)
#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <ctype.h>
#include <time.h>
#include <string>
#define IRAM_ATTR
#define HIGH 1
#define LOW 0
#define OUTPUT 1
#define INPUT 0
#define RISING 1
#define MSBFIRST 1
#define SPI_MODE0 0
#define VSPI 3
#define SERIAL_8N1 0x800001c
typedef int BaseType_t; typedef unsigned TickType_t; typedef unsigned UBaseType_t;
#define pdTRUE 1
#define pdMS_TO_TICKS(x) ((TickType_t)(x))
#define portMAX_DELAY 0xffffffffu
typedef void* SemaphoreHandle_t; typedef void* QueueHandle_t; typedef void* TaskHandle_t;
struct portMUX_TYPE { int x; };
#define portMUX_INITIALIZER_UNLOCKED {0}
void portENTER_CRITICAL(portMUX_TYPE*); void portEXIT_CRITICAL(portMUX_TYPE*);
SemaphoreHandle_t xSemaphoreCreateMutex(); int xSemaphoreTake(SemaphoreHandle_t, TickType_t); int xSemaphoreGive(SemaphoreHandle_t);
QueueHandle_t xQueueCreate(UBaseType_t, UBaseType_t); BaseType_t xQueueSend(QueueHandle_t, const void*, TickType_t);
BaseType_t xQueueReceive(QueueHandle_t, void*, TickType_t); UBaseType_t uxQueueMessagesWaiting(QueueHandle_t);
TickType_t xTaskGetTickCount(); void vTaskDelayUntil(TickType_t*, TickType_t); void vTaskDelay(TickType_t);
BaseType_t xTaskCreatePinnedToCore(void(*)(void*), const char*, uint32_t, void*, UBaseType_t, TaskHandle_t*, int);
uint32_t millis(); void delay(uint32_t); void delayMicroseconds(uint32_t);
void pinMode(uint8_t, uint8_t); void digitalWrite(uint8_t, uint8_t); int digitalRead(uint8_t);
int digitalPinToInterrupt(int); void attachInterrupt(int, void(*)(), int);
uint32_t esp_random();
#define F(x) (x)
#define M_PI 3.14159265358979323846
class String { public: String(); String(const char*); String(const String&); explicit String(int); explicit String(unsigned); explicit String(long);
  String(float, unsigned char); String(double, unsigned char);
  String& operator=(const String&); String& operator=(const char*);
  String& operator+=(char); String& operator+=(const char*); String& operator+=(const String&);
  friend String operator+(const String&, const String&); friend String operator+(const String&, const char*); friend String operator+(const char*, const String&);
  bool operator==(const char*) const; char operator[](unsigned) const;
  const char* c_str() const; int indexOf(const char*) const; unsigned length() const; void reserve(unsigned);
  void toLowerCase(); void trim(); bool startsWith(const char*) const; String substring(unsigned, unsigned) const; long toInt() const; float toFloat() const; };
template<class T> T min(T a, T b){return a<b?a:b;}
class Print { public: size_t write(const uint8_t*, size_t); size_t write(uint8_t); size_t print(const char*);
  size_t printf(const char*, ...); size_t println(const char*); void flush(); };
class Stream : public Print { public: int available(); int read(); size_t read(uint8_t*, size_t); };
class HardwareSerial : public Stream { public: void begin(unsigned long, uint32_t=SERIAL_8N1, int8_t=-1, int8_t=-1);
  void updateBaudRate(unsigned long); size_t setRxBufferSize(size_t); };
extern HardwareSerial Serial, Serial1, Serial2;
struct EspClass { uint32_t getFreeHeap(); void restart(); }; extern EspClass ESP;
