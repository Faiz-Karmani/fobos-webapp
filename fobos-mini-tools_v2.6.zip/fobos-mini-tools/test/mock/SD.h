#pragma once
#include <SPI.h>
#define FILE_WRITE "w"
class File : public Print { public: operator bool() const; void close(); };
class SDFS { public: bool exists(const char*); bool begin(uint8_t, SPIClass&, uint32_t); File open(const char*, const char*); bool mkdir(const char*); uint64_t totalBytes(); uint64_t usedBytes(); };
extern SDFS SD;
