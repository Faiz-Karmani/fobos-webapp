#pragma once
#include <Arduino.h>
class SPISettings { public: SPISettings(); SPISettings(uint32_t, uint8_t, uint8_t); };
class SPIClass { public: SPIClass(int); void begin(int8_t, int8_t, int8_t, int8_t=-1); void beginTransaction(SPISettings); void endTransaction(); uint8_t transfer(uint8_t); };
