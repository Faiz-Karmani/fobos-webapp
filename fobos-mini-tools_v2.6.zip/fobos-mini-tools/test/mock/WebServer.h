#pragma once
#include <WiFi.h>
#include <functional>
enum HTTPMethod { HTTP_GET, HTTP_POST };
enum HTTPAuthMethod { BASIC_AUTH };
class WebServer { public: WebServer(int); void on(const char*, HTTPMethod, std::function<void()>); void onNotFound(std::function<void()>); void begin(); void handleClient();
 bool authenticate(const char*, const char*); void requestAuthentication(HTTPAuthMethod, const char*, const String&); bool hasArg(const char*); String arg(const char*);
 void send(int, const char*, const String&); void sendHeader(const char*, const char*); };
