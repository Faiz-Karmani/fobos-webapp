#pragma once
#include <Arduino.h>
#define WL_CONNECTED 3
#define WIFI_STA 1
#define WIFI_AP_STA 3
#define WIFI_AUTH_OPEN 0
class IPAddress { public: String toString() const; };
class WiFiClass { public: int status(); int RSSI(); int RSSI(int); IPAddress localIP(); IPAddress softAPIP(); void mode(int); void setSleep(bool); void setAutoReconnect(bool);
  int scanNetworks(); String SSID(); String SSID(int); int encryptionType(int); void scanDelete(); bool softAP(const char*, const char*); bool softAPdisconnect(bool);
  int softAPgetStationNum(); void begin(const char*, const char*); void disconnect(); }; extern WiFiClass WiFi;
class Client : public Stream { public: virtual int connect(const char*, uint16_t, int32_t)=0; virtual uint8_t connected()=0; virtual void stop()=0; };
class WiFiClient : public Client { public: int connect(const char*, uint16_t, int32_t); uint8_t connected(); void stop(); };
