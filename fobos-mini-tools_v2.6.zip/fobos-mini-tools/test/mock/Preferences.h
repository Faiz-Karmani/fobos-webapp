#pragma once
#include <Arduino.h>
class Preferences { public: bool begin(const char*, bool); void end(); String getString(const char*, const char*); bool getBool(const char*, bool); uint16_t getUShort(const char*, uint16_t);
 uint8_t getUChar(const char*, uint8_t); uint32_t getUInt(const char*, uint32_t); bool isKey(const char*); size_t putString(const char*, const char*); size_t putBool(const char*, bool);
 size_t putUShort(const char*, uint16_t); size_t putUChar(const char*, uint8_t); size_t putUInt(const char*, uint32_t); };
