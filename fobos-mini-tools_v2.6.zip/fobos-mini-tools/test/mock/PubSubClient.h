#pragma once
#include <WiFi.h>
class PubSubClient { public: PubSubClient& setClient(Client&); PubSubClient& setServer(const char*, uint16_t);
 PubSubClient& setCallback(void(*)(char*, uint8_t*, unsigned int)); bool setBufferSize(uint16_t); PubSubClient& setKeepAlive(uint16_t); PubSubClient& setSocketTimeout(uint16_t);
 bool connect(const char*, const char*, const char*, const char*, uint8_t, bool, const char*);
 bool publish(const char*, const char*); bool publish(const char*, const char*, bool); bool publish(const char*, const uint8_t*, unsigned int);
 bool subscribe(const char*); void disconnect(); bool loop(); bool connected(); int state(); };
