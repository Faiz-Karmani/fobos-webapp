#pragma once
#include <WiFi.h>
class WiFiMulti { public: bool addAP(const char*, const char*); uint8_t run(uint32_t); };
