#pragma once
#include <Arduino.h>
class base64 { public: static String encode(const String&); };
