#pragma once
class MDNSResponder { public: bool begin(const char*); void end(); }; extern MDNSResponder MDNS;
