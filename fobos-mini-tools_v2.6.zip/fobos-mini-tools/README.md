# Fobos Mini v2 — streaming posisi, perekaman raw GNSS/IMU, dan web pemantauan

Perangkat lunak gratis untuk prototipe **Fobos Mini** (ZED-F9P + ICM-20948 + ESP32). ZED-F9P diatur lewat u-center; firmware ESP32 hanya membaca, meneruskan, menyimpan, dan mengirim data.

| Folder | Isi |
|---|---|
| `firmware/FobosMini/` | Firmware Arduino-ESP32 (lihat rincian di bawah) |
| `docs/` | Web app statis untuk GitHub Pages (lihat rincian di bawah) |
| `tools/` | Server lokal cadangan (`fobos_local.py`), simulator (`fobos_sim.py`), olah data (`fobos_post.py`) |
| `gambar/` | Diagram pengkabelan dan alur data (`.drawio` + `.png`) |
| `test/` | Uji logika firmware di PC |

**Firmware** (`firmware/FobosMini/`):
- Pindai dan sambung WiFi.
- Teruskan NTRIP Ina-CORS ke ZED-F9P.
- Parse posisi dari UART1.
- Salin UART2 apa adanya ke SD.
- Rekam IMU 200 Hz.
- Buat set file SD baru setiap kali menyala.
- Sediakan portal pengaturan (WiFi, NTRIP, MQTT).

**Web app** (`docs/`):
- Leaflet + OSM + MQTT WebSocket, lewat broker cloud gratis **flespi** atau broker lokal di laptop.
- Jejak berwarna fix/float/single.
- Grafik getaran.
- Record / Stop Record dengan unduhan .zip otomatis.

Petunjuk lengkap dari persiapan sampai demo ada di **[PANDUAN.md](PANDUAN.md)**. Cara menyiapkan broker cloud flespi untuk pemula ada di **[PANDUAN_FLESPI.md](PANDUAN_FLESPI.md)**.

> Token flespi dan isi `firmware/FobosMini/secrets.h` **jangan** diunggah ke GitHub.

Pustaka pihak ketiga di `docs/lib/`: Leaflet 1.9.4 (BSD-2-Clause) dan MQTT.js 5.16.1 (MIT). Berkas lisensinya ada di folder yang sama.
