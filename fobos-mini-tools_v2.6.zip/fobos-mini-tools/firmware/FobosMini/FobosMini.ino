// =====================================================================
//  Fobos Mini v2 — firmware ESP32 (Arduino-ESP32 core 3.x), versi sederhana
//
//  ZED-F9P SUDAH diatur lewat u-center; firmware hanya membaca/meneruskan:
//    UART1 ZED (Serial2, 230400): NMEA GGA/RMC/GST + UBX NAV-PVT keluar  -> posisi (SD _pos.csv + web)
//                                 RTCM Ina-CORS masuk                     <- NTRIP
//    UART2 ZED (Serial1, 460800): UBX RAWX + SFRBX keluar                -> SD _raw.ubx apa adanya
//                                                                          (+ web RAWX 1 Hz saat Record)
//    ICM-20948 I2C 200 Hz -> SD _imu.csv ; ringkasan 5 Hz -> web
//    PPS ZED -> GPIO34 untuk stempel waktu GPS pada IMU
//  File SD baru setiap menyala: /F0001_raw.ubx, _pos.csv, _imu.csv, _event.csv (tidak pernah menimpa).
//  Portal pengaturan di http://IP-ESP32/ (atau AP "FobosMini-<ID>" -> http://192.168.4.1 bila belum ada WiFi):
//  pilih WiFi + password, NTRIP Ina-CORS, broker MQTT. Disimpan di memori ESP32 (NVS).
//
//  Tugas FreeRTOS:  core 1: imuTask (prio 5), gnssTask (prio 4)
//                   core 0: netTask (prio 3: WiFi, portal, NTRIP, MQTT), sdTask (prio 2)
// =====================================================================
#include <Arduino.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include <Preferences.h>
#include <PubSubClient.h>      // Library Manager: "PubSubClient" by Nick O'Leary
#include <Wire.h>
#include <SPI.h>
#include <SD.h>
#include <base64.h>
#include <sys/time.h>
#include "esp_timer.h"
#include "freertos/stream_buffer.h"
#if __has_include("esp_random.h")
#include "esp_random.h"
#endif

#include "config.h"
#if __has_include("secrets.h")
#include "secrets.h"
#else
#warning "secrets.h belum ada: memakai secrets_example.h (salin menjadi secrets.h lalu isi)"
#include "secrets_example.h"
#endif
#include "ca_cert.h"
#include "fobos_proto.h"
#include "icm20948.h"

using namespace fobos;

// =====================================================================
//  Pengaturan tersimpan (NVS) — diubah lewat portal
// =====================================================================
struct Settings {
  bool ntEn; char ntHost[64]; uint16_t ntPort; char ntMount[48]; char ntUser[48]; char ntPass[64];
  char m1Host[96]; uint16_t m1Port; bool m1Tls; bool m1Insecure; char m1User[96]; char m1Pass[96];
  uint8_t pvtHz;   // laju posisi ke web: 10/5/2/1 Hz (SD tetap semua epoch)
  char m2Host[64]; uint16_t m2Port; char m2User[48]; char m2Pass[64];
  int nWifi; char wSsid[MAX_SAVED_WIFI][33]; char wPass[MAX_SAVED_WIFI][65];
} S;
Preferences prefs;

static void getStr(const char *k, const char *def, char *dst, size_t cap) {
  String v = prefs.getString(k, def); strncpy(dst, v.c_str(), cap - 1); dst[cap - 1] = 0;
}
static void loadSettings() {
  prefs.begin("fobos", true);
  S.ntEn = prefs.getBool("ntEn", NTRIP_ENABLE);
  getStr("ntHost", NTRIP_HOST, S.ntHost, sizeof(S.ntHost)); S.ntPort = prefs.getUShort("ntPort", NTRIP_PORT);
  getStr("ntMount", NTRIP_MOUNT, S.ntMount, sizeof(S.ntMount)); getStr("ntUser", NTRIP_USER, S.ntUser, sizeof(S.ntUser));
  getStr("ntPass", NTRIP_PASS, S.ntPass, sizeof(S.ntPass));
  getStr("m1Host", MQTT1_HOST, S.m1Host, sizeof(S.m1Host)); S.m1Port = prefs.getUShort("m1Port", MQTT1_PORT);
  S.m1Tls = prefs.getBool("m1Tls", MQTT1_TLS); S.m1Insecure = prefs.getBool("m1Ins", false);
  getStr("m1User", MQTT1_USER, S.m1User, sizeof(S.m1User));
  S.pvtHz = prefs.getUChar("pvtHz", PVT_WEB_HZ);
  getStr("m1Pass", MQTT1_PASS, S.m1Pass, sizeof(S.m1Pass));
  getStr("m2Host", MQTT2_HOST, S.m2Host, sizeof(S.m2Host)); S.m2Port = prefs.getUShort("m2Port", MQTT2_PORT);
  getStr("m2User", MQTT2_USER, S.m2User, sizeof(S.m2User)); getStr("m2Pass", MQTT2_PASS, S.m2Pass, sizeof(S.m2Pass));
  bool seeded = prefs.isKey("wn");
  S.nWifi = 0;
  if (seeded) {
    S.nWifi = min((int)prefs.getUChar("wn", 0), MAX_SAVED_WIFI);
    for (int i = 0; i < S.nWifi; i++) {
      char k[8]; snprintf(k, sizeof(k), "ws%d", i); getStr(k, "", S.wSsid[i], 33);
      snprintf(k, sizeof(k), "wp%d", i); getStr(k, "", S.wPass[i], 65);
    }
  }
  prefs.end();
  if (!seeded) {    // isi awal dari secrets.h
    if (strlen(WIFI1_SSID)) { strcpy(S.wSsid[S.nWifi], WIFI1_SSID); strcpy(S.wPass[S.nWifi++], WIFI1_PASS); }
    if (strlen(WIFI2_SSID)) { strcpy(S.wSsid[S.nWifi], WIFI2_SSID); strcpy(S.wPass[S.nWifi++], WIFI2_PASS); }
  }
}
static void saveNtrip() {
  prefs.begin("fobos", false);
  prefs.putBool("ntEn", S.ntEn); prefs.putString("ntHost", S.ntHost); prefs.putUShort("ntPort", S.ntPort);
  prefs.putString("ntMount", S.ntMount); prefs.putString("ntUser", S.ntUser); prefs.putString("ntPass", S.ntPass);
  prefs.end();
}
static void saveMqtt() {
  prefs.begin("fobos", false);
  prefs.putString("m1Host", S.m1Host); prefs.putUShort("m1Port", S.m1Port); prefs.putBool("m1Tls", S.m1Tls);
  prefs.putBool("m1Ins", S.m1Insecure); prefs.putUChar("pvtHz", S.pvtHz);
  prefs.putString("m1User", S.m1User); prefs.putString("m1Pass", S.m1Pass);
  prefs.putString("m2Host", S.m2Host); prefs.putUShort("m2Port", S.m2Port);
  prefs.putString("m2User", S.m2User); prefs.putString("m2Pass", S.m2Pass);
  prefs.end();
}
static void saveWifi() {
  prefs.begin("fobos", false);
  prefs.putUChar("wn", (uint8_t)S.nWifi);
  for (int i = 0; i < S.nWifi; i++) {
    char k[8]; snprintf(k, sizeof(k), "ws%d", i); prefs.putString(k, S.wSsid[i]);
    snprintf(k, sizeof(k), "wp%d", i); prefs.putString(k, S.wPass[i]);
  }
  prefs.end();
}

// =====================================================================
//  Objek & status global
// =====================================================================
SPIClass spiSd(VSPI);
Icm20948 imu;
WiFiClientSecure tlsClient;
WiFiClient plainClient, ntripClient;
PubSubClient mqtt;
WebServer server(80);

SemaphoreHandle_t stateMutex;
StreamBufferHandle_t sbRaw, sbPos, sbImu;     // -> SD
QueueHandle_t qPvt, qImu, qRaw, qEvt;

struct PvtItem { Epoch e; int week; float vib; uint32_t seq; };
struct ImuItem { int week; double tow; float a[3], g[3]; uint16_t n; float vib; uint8_t tflag; uint32_t seq; };
struct RawItem { uint16_t len; uint8_t data[RAW_PKT_MAX]; };
struct EvtItem { char line[200]; };

char g_prefix[8] = "F----";
volatile bool g_sdOk = false;
volatile uint32_t g_sdFreeMb = 0, g_sdKbRaw = 0, g_sdKbPos = 0, g_sdKbImu = 0, g_dropSd = 0, g_dropMq = 0;

volatile bool g_sessActive = false, g_rawFlushReq = false;
char g_sess[48] = "";
uint32_t g_sessStartMs = 0, g_sessPvt0 = 0, g_sessImu0 = 0;
volatile uint32_t g_rawSeq = 0, g_pvtSeq = 0, g_imuSeq = 0;

volatile float g_vib = NAN, g_imuHz = 0, g_imuMaxDtMs = 0;
volatile uint32_t g_imuErr = 0;
volatile bool g_imuOk = false;
volatile float g_pvtHz = 0, g_rawxHz = 0;
volatile uint32_t g_u2Bytes = 0;
volatile int g_rawWeek = -1;
GnssMux g_mux;

Epoch g_last; bool g_haveLast = false;      // dilindungi stateMutex
char g_lastGga[100] = "";                   // GGA asli dari ZED (untuk caster VRS), dilindungi stateMutex

// Jangkar waktu GPS (PPS)
volatile int64_t g_ppsUs = 0, g_ppsPrevUs = 0;
struct TimeAnchor { bool valid = false; bool pps = false; int64_t us = 0; double towMs = 0; double usPerSec = 1e6; int week = -1; };
TimeAnchor g_anchor;
portMUX_TYPE anchorMux = portMUX_INITIALIZER_UNLOCKED;
int64_t g_lastPpsUsedUs = 0;
void IRAM_ATTR onPps() { g_ppsPrevUs = g_ppsUs; g_ppsUs = esp_timer_get_time(); }

// Jaringan
char T_PVT[48], T_IMU[48], T_RAW[48], T_STATUS[48], T_CMD[48], T_ACK[48];
int g_broker = 0, g_brokerFails = 0;
volatile bool g_ntripOk = false;
volatile uint32_t g_ntripBytes = 0, g_ntripLastMs = 0;
char g_ntripErr[64] = "";
volatile bool g_ntripReset = false, g_mqttReset = false;
char g_pendingCmd[160] = "";
volatile bool g_cmdPending = false;

// =====================================================================
//  Waktu
// =====================================================================
static void updateAnchor(const Pvt &p, int64_t arrivalUs) {
  if (!p.gnssFixOK() || !(p.valid & 0x02)) return;
  int week = g_rawWeek >= 0 ? g_rawWeek : gpsWeekFromPvt(p);
  int64_t pps = g_ppsUs, ppsPrev = g_ppsPrevUs;
  bool ppsRegular = PPS_ENABLE && ppsPrev != 0 && llabs((pps - ppsPrev) - 1000000LL) < 2000;
  TimeAnchor a;
  portENTER_CRITICAL(&anchorMux); a = g_anchor; portEXIT_CRITICAL(&anchorMux);
  bool ppsFresh = ppsRegular && (arrivalUs - pps) < 1000000 && (arrivalUs - pps) >= 0;
  if (ppsFresh && pps != g_lastPpsUsedUs) {
    double S0 = floor((p.iTOW + (pps - arrivalUs) / 1000.0) / 1000.0 + 0.5) * 1000.0;  // detik GPS bulat saat PPS
    if (a.valid && a.pps && fabs((S0 - a.towMs) - 1000.0) < 1) {
      double meas = (double)(pps - a.us);
      if (fabs(meas - 1e6) < 500) a.usPerSec = 0.8 * a.usPerSec + 0.2 * meas;
    }
    a.valid = true; a.pps = true; a.us = pps; a.towMs = S0; a.week = week;
    g_lastPpsUsedUs = pps;
  } else if (!ppsFresh && (!a.valid || !a.pps || arrivalUs - a.us > 3000000)) {
    a.valid = true; a.pps = false; a.us = arrivalUs; a.towMs = p.iTOW; a.usPerSec = 1e6; a.week = week;
  }
  portENTER_CRITICAL(&anchorMux); g_anchor = a; portEXIT_CRITICAL(&anchorMux);
}
// waktu-minggu GPS [s] untuk stempel esp_timer; tflag: 0 lokal, 1 GPS, 3 GPS+PPS
static double gpsTow(int64_t tUs, uint8_t &tflag, int &week) {
  TimeAnchor a;
  portENTER_CRITICAL(&anchorMux); a = g_anchor; portEXIT_CRITICAL(&anchorMux);
  if (!a.valid || a.week < 0) { tflag = 0; week = 0; return tUs / 1e6; }
  double tow = (a.towMs * 1000.0 + (double)(tUs - a.us) * 1e6 / a.usPerSec) / 1e6;
  week = a.week;
  while (tow >= 604800.0) { tow -= 604800.0; week++; }
  while (tow < 0) { tow += 604800.0; week--; }
  tflag = a.pps ? 3 : 1;
  return tow;
}
static void setClockFromPvt(const Pvt &p) {
  static bool done = false;
  if (done || (p.valid & 0x03) != 0x03) return;
  int64_t unixS = daysFromCivil(p.year, p.month, p.day) * 86400 + p.hour * 3600 + p.min * 60 + p.sec;
  struct timeval tv = {(time_t)unixS, 0};
  settimeofday(&tv, nullptr);
  done = true;
}

// Catatan kejadian ke SD (_event.csv): utc,gps_week,tow_s,kejadian,keterangan
static void logEvent(const char *ev, const char *detail) {
  EvtItem it; uint8_t tf; int wk;
  double tow = gpsTow(esp_timer_get_time(), tf, wk);
  time_t now = time(nullptr); struct tm tmv; gmtime_r(&now, &tmv);
  snprintf(it.line, sizeof(it.line), "%04d-%02d-%02dT%02d:%02d:%02dZ,%d,%.3f,%s,%s\n",
           tmv.tm_year + 1900, tmv.tm_mon + 1, tmv.tm_mday, tmv.tm_hour, tmv.tm_min, tmv.tm_sec,
           tf ? wk : -1, tf ? tow : -1.0, ev, detail ? detail : "");
  if (qEvt) xQueueSend(qEvt, &it, 0);
  Serial.printf("[EVENT] %s", it.line);
}

// =====================================================================
//  Tugas IMU (I2C, 200 Hz)
// =====================================================================
static void imuTask(void *) {
  VibAcc vib; uint32_t nSec = 0; int64_t secStart = esp_timer_get_time(), prevT = 0;
  float maxDt = 0;
  const float accScale = 9.80665f / imu.accLsbPerG();
  const float gyrScale = (float)(M_PI / 180.0) / imu.gyrLsbPerDps();
  const int perWeb = IMU_RATE_HZ / IMU_WEB_HZ;
  double sa[3] = {0, 0, 0}, sg[3] = {0, 0, 0}; int nw = 0; double towFirst = 0; int weekFirst = 0; uint8_t tfFirst = 0;
  char line[128];
  TickType_t last = xTaskGetTickCount();
  const TickType_t period = pdMS_TO_TICKS(1000 / IMU_RATE_HZ) ? pdMS_TO_TICKS(1000 / IMU_RATE_HZ) : 1;
  for (;;) {
    vTaskDelayUntil(&last, period);
    int16_t r[7];
    int64_t t = esp_timer_get_time();
    if (!imu.readRaw(r)) { g_imuErr++; continue; }
    if (prevT) { float dt = (t - prevT) / 1000.0f; if (dt > maxDt) maxDt = dt; }
    prevT = t;
    float a[3] = {r[0] * accScale, r[1] * accScale, r[2] * accScale};
    float g[3] = {r[3] * gyrScale, r[4] * gyrScale, r[5] * gyrScale};
    float tc = r[6] / 333.87f + 21.0f;
    uint8_t tf; int week;
    double tow = gpsTow(t, tf, week);
    // SD: setiap sampel
    if (g_sdOk) {
      int n = imuCsvLine(line, sizeof(line), week, tow, a, g, tc, tf);
      if (xStreamBufferSpacesAvailable(sbImu) >= (size_t)n) xStreamBufferSend(sbImu, line, n, 0); else g_dropSd++;
    }
    // indeks getaran per detik
    vib.add(a[0], a[1], a[2]); nSec++;
    if (t - secStart >= 1000000) {
      g_vib = (float)vib.rms(); vib.reset();
      g_imuHz = nSec * 1e6f / (float)(t - secStart); g_imuMaxDtMs = maxDt;
      nSec = 0; maxDt = 0; secStart = t;
    }
    // web: rata-rata tiap 200 ms
    if (nw == 0) { towFirst = tow; weekFirst = week; tfFirst = tf; }
    for (int k = 0; k < 3; k++) { sa[k] += a[k]; sg[k] += g[k]; }
    if (++nw >= perWeb) {
      ImuItem it; it.week = weekFirst; it.tow = towFirst; it.n = nw; it.vib = g_vib; it.tflag = tfFirst; it.seq = g_imuSeq++;
      for (int k = 0; k < 3; k++) { it.a[k] = sa[k] / nw; it.g[k] = sg[k] / nw; sa[k] = sg[k] = 0; }
      nw = 0;
      xQueueSend(qImu, &it, 0);
    }
  }
}

// =====================================================================
//  Tugas GNSS: UART1 (posisi) dan UART2 (raw)
// =====================================================================
static void handleEpoch(const Epoch &e) {
  int week = g_rawWeek >= 0 ? g_rawWeek : gpsWeekFromPvt(e.p);
  if (g_sdOk) {
    char line[320];
    int n = posCsvLine(line, sizeof(line), e, week);
    if (xStreamBufferSpacesAvailable(sbPos) >= (size_t)n) xStreamBufferSend(sbPos, line, n, 0); else g_dropSd++;
  }
  xSemaphoreTake(stateMutex, portMAX_DELAY); g_last = e; g_haveLast = true; xSemaphoreGive(stateMutex);
  uint32_t stepMs = 1000 / (S.pvtHz ? S.pvtHz : 10);
  if (e.p.iTOW % stepMs >= 50 && stepMs > 100) return;   // penipisan untuk web: 5 Hz=200 ms, 2 Hz=500 ms, 1 Hz=1000 ms
  static PvtItem it;
  it.e = e; it.week = week; it.vib = g_vib; it.seq = g_pvtSeq++;
  xQueueSend(qPvt, &it, 0);
}

static void gnssTask(void *) {
  static EpochMerger merger;
  static UbxParser p2;
  static RawPacket raw; bool rawOpen = false;
  static RawItem ri;
  static uint8_t rx[512];
  uint32_t nPvt = 0, nRawx = 0, secT = millis();
  Epoch out;
  auto sendRaw = [&]() {
    if (rawOpen && !raw.empty()) {
      wrU4(raw.buf + 8, g_rawSeq++);
      ri.len = raw.len; memcpy(ri.data, raw.buf, raw.len);
      if (xQueueSend(qRaw, &ri, 0) != pdTRUE) g_dropMq++;
    }
    rawOpen = false;
  };
  for (;;) {
    bool idle = true;
    if (g_rawFlushReq) { sendRaw(); g_rawFlushReq = false; }
    // ---- UART1: NMEA + NAV-PVT
    int n = Serial2.available();
    if (n > 0) {
      idle = false;
      n = Serial2.read(rx, min(n, (int)sizeof(rx)));
      for (int i = 0; i < n; i++) {
        int ev = g_mux.feed(rx[i]);
        if (ev == GnssMux::UBX && g_mux.ubx.cls == 0x01 && g_mux.ubx.id == 0x07) {
          Pvt p;
          if (!decodePvt(g_mux.ubx.payload(), g_mux.ubx.len, p)) continue;
          updateAnchor(p, esp_timer_get_time());
          setClockFromPvt(p);
          nPvt++;
          if (merger.onPvt(p, millis(), out)) handleEpoch(out);
        } else if (ev == GnssMux::NMEA) {
          const char *s = g_mux.line;
          if (nmeaIs(s, "GGA")) {
            GgaRec g; if (parseGga(s, g)) merger.addGga(g);
            if (g.q > 0) { xSemaphoreTake(stateMutex, portMAX_DELAY); snprintf(g_lastGga, sizeof(g_lastGga), "%s\r\n", s); xSemaphoreGive(stateMutex); }
          } else if (nmeaIs(s, "GST")) {
            GstRec g; if (parseGst(s, g)) merger.addGst(g);
          }
        }
      }
    }
    if (merger.poll(millis(), 150, out)) handleEpoch(out);
    // ---- UART2: RAWX + SFRBX -> SD apa adanya; web 1 Hz saat sesi
    n = Serial1.available();
    if (n > 0) {
      idle = false;
      n = Serial1.read(rx, min(n, (int)sizeof(rx)));
      g_u2Bytes += n;
      if (g_sdOk) { if (xStreamBufferSpacesAvailable(sbRaw) >= (size_t)n) xStreamBufferSend(sbRaw, rx, n, 0); else g_dropSd++; }
      bool active = g_sessActive;
      for (int i = 0; i < n; i++) {
        if (!p2.feed(rx[i])) continue;
        if (p2.cls == 0x02 && p2.id == 0x15) {               // RXM-RAWX
          RawxHead h;
          if (!decodeRawxHead(p2.payload(), p2.len, h)) continue;
          g_rawWeek = h.week; nRawx++;
          if (!active) { rawOpen = false; continue; }
          if (!RAW_STREAM_1HZ || rawxOnWholeSecond(h.rcvTow)) {
            sendRaw();
            raw.begin(0, (uint32_t)llround(h.rcvTow * 1000.0)); rawOpen = true;
            raw.append(p2.frame, p2.frameLen());
          }
        } else if (p2.cls == 0x02 && p2.id == 0x13 && active) {   // RXM-SFRBX
          if (!rawOpen) { raw.begin(0, 0); rawOpen = true; }
          raw.append(p2.frame, p2.frameLen());
        }
      }
    }
    if (millis() - secT >= 2000) {
      float dt = (millis() - secT) / 1000.0f;
      g_pvtHz = nPvt / dt; g_rawxHz = nRawx / dt; nPvt = nRawx = 0; secT = millis();
    }
    if (idle) vTaskDelay(1);
  }
}

// =====================================================================
//  Tugas SD: satu set file per nyala
// =====================================================================
static void sdTask(void *) {
  static uint8_t tmp[2048];
  char path[32];
  File fRaw, fPos, fImu, fEvt;
  if (g_sdOk) {
    snprintf(path, sizeof(path), "/%s_raw.ubx", g_prefix); fRaw = SD.open(path, FILE_WRITE);
    snprintf(path, sizeof(path), "/%s_pos.csv", g_prefix); fPos = SD.open(path, FILE_WRITE);
    snprintf(path, sizeof(path), "/%s_imu.csv", g_prefix); fImu = SD.open(path, FILE_WRITE);
    snprintf(path, sizeof(path), "/%s_event.csv", g_prefix); fEvt = SD.open(path, FILE_WRITE);
    if (!fRaw || !fPos || !fImu || !fEvt) { Serial.println("[SD] gagal membuat file"); g_sdOk = false; }
    else {
      fPos.print(POS_CSV_HEADER); fImu.print(IMU_CSV_HEADER);
      fEvt.print("utc,gps_week,tow_s,kejadian,keterangan\n");
    }
  }
  uint32_t lastFlush = millis();
  uint32_t bRaw = 0, bPos = 0, bImu = 0;
  for (;;) {
    size_t n;
    bool any = false;
    if ((n = xStreamBufferReceive(sbRaw, tmp, sizeof(tmp), pdMS_TO_TICKS(10))) > 0) { any = true; if (fRaw) fRaw.write(tmp, n); bRaw += n; }
    if ((n = xStreamBufferReceive(sbImu, tmp, sizeof(tmp), 0)) > 0) { any = true; if (fImu) fImu.write(tmp, n); bImu += n; }
    if ((n = xStreamBufferReceive(sbPos, tmp, sizeof(tmp), 0)) > 0) { any = true; if (fPos) fPos.write(tmp, n); bPos += n; }
    EvtItem ev;
    while (xQueueReceive(qEvt, &ev, 0) == pdTRUE) { if (fEvt) fEvt.print(ev.line); any = true; }
    if (millis() - lastFlush > SD_FLUSH_MS) {
      if (fRaw) fRaw.flush();
      if (fPos) fPos.flush();
      if (fImu) fImu.flush();
      if (fEvt) fEvt.flush();
      g_sdKbRaw = bRaw / 1024; g_sdKbPos = bPos / 1024; g_sdKbImu = bImu / 1024;
      lastFlush = millis();
    }
    if (!any && !g_sdOk) vTaskDelay(pdMS_TO_TICKS(200));
  }
}

// =====================================================================
//  WiFi: pindai, sambung ke WiFi tersimpan terkuat; AP portal bila gagal
// =====================================================================
enum WState { W_IDLE, W_CONNECTING, W_CONNECTED, W_WAIT };
WState wState = W_IDLE;
uint32_t wTimer = 0, wConnectedAt = 0;
bool apOn = false;
int g_pendingWifi = -1;
char g_apName[32];
struct ScanRec { char ssid[33]; int rssi; bool open; };
ScanRec fobos_scan[20]; int fobos_nScan = 0;

static void doScan() {
  int n = WiFi.scanNetworks();
  fobos_nScan = 0;
  Serial.printf("[WiFi] hasil pindai: %d jaringan\n", n < 0 ? 0 : n);
  for (int i = 0; i < n && fobos_nScan < 20; i++) {
    String s = WiFi.SSID(i);
    if (!s.length()) continue;
    bool dup = false;
    for (int k = 0; k < fobos_nScan; k++) if (!strcmp(fobos_scan[k].ssid, s.c_str())) { dup = true; if (WiFi.RSSI(i) > fobos_scan[k].rssi) fobos_scan[k].rssi = WiFi.RSSI(i); }
    if (dup) continue;
    strncpy(fobos_scan[fobos_nScan].ssid, s.c_str(), 32); fobos_scan[fobos_nScan].ssid[32] = 0;
    fobos_scan[fobos_nScan].rssi = WiFi.RSSI(i); fobos_scan[fobos_nScan].open = WiFi.encryptionType(i) == WIFI_AUTH_OPEN;
    Serial.printf("   %-32s %4d dBm %s\n", fobos_scan[fobos_nScan].ssid, fobos_scan[fobos_nScan].rssi, fobos_scan[fobos_nScan].open ? "(terbuka)" : "");
    fobos_nScan++;
  }
  WiFi.scanDelete();
}
static int bestSaved() {
  int best = -1, bestRssi = -1000;
  for (int k = 0; k < fobos_nScan; k++)
    for (int i = 0; i < S.nWifi; i++)
      if (!strcmp(fobos_scan[k].ssid, S.wSsid[i]) && fobos_scan[k].rssi > bestRssi) { best = i; bestRssi = fobos_scan[k].rssi; }
  return best;
}
static void apStart() {
  WiFi.mode(WIFI_AP_STA);
  WiFi.softAP(g_apName, AP_PASS);
  apOn = true;
  Serial.printf("[WiFi] AP portal '%s' aktif: http://%s (password AP: lihat secrets.h)\n", g_apName, WiFi.softAPIP().toString().c_str());
  logEvent("AP_ON", g_apName);
}
static void apStop() {
  WiFi.softAPdisconnect(true);
  WiFi.mode(WIFI_STA);
  apOn = false;
  logEvent("AP_OFF", "");
}
static void wifiConnect(int i) {
  Serial.printf("[WiFi] menyambung ke '%s'...\n", S.wSsid[i]);
  WiFi.disconnect();
  WiFi.begin(S.wSsid[i], S.wPass[i]);
  wState = W_CONNECTING; wTimer = millis();
}
static void wifiService() {
  uint32_t now = millis();
  if (g_pendingWifi >= 0 && g_pendingWifi < S.nWifi) { int i = g_pendingWifi; g_pendingWifi = -1; wifiConnect(i); return; }
  if (WiFi.status() == WL_CONNECTED) {
    if (wState != W_CONNECTED) {
      wState = W_CONNECTED; wConnectedAt = now;
      char d[96]; snprintf(d, sizeof(d), "%s %s", WiFi.SSID().c_str(), WiFi.localIP().toString().c_str());
      Serial.printf("[WiFi] tersambung: %s  -> portal http://%s/\n", d, WiFi.localIP().toString().c_str());
      logEvent("WIFI_OK", d);
      char host[24]; snprintf(host, sizeof(host), "fobos-%s", DEVICE_ID);
      for (char *c = host; *c; c++) *c = tolower(*c);
      MDNS.end(); MDNS.begin(host);
    }
    if (apOn && now - wConnectedAt > AP_OFF_DELAY_MS && WiFi.softAPgetStationNum() == 0) apStop();
    return;
  }
  if (wState == W_CONNECTED) { wState = W_IDLE; logEvent("WIFI_LOST", ""); }
  if (wState == W_CONNECTING) {
    if (now - wTimer > WIFI_CONNECT_TIMEOUT_MS) {
      Serial.println("[WiFi] gagal tersambung");
      WiFi.disconnect(); wState = W_WAIT; wTimer = now;
      if (!apOn) apStart();
    }
    return;
  }
  if (wState == W_WAIT && now - wTimer < WIFI_RESCAN_MS) return;
  doScan();
  int best = bestSaved();
  if (best >= 0) wifiConnect(best);
  else {
    Serial.println("[WiFi] tidak ada WiFi tersimpan yang terjangkau");
    if (!apOn) apStart();
    wState = W_WAIT; wTimer = now;
  }
}

#include "portal.h"

// =====================================================================
//  Sesi Record (dari web): penanda di SD + streaming raw ke web
// =====================================================================
static void publishAck(const char *json) { if (mqtt.connected()) mqtt.publish(T_ACK, json); Serial.printf("[ACK] %s\n", json); }

static void sessionStart(const char *name) {
  char ack[256];
  if (g_sessActive) { snprintf(ack, sizeof(ack), "{\"cmd\":\"start\",\"ok\":false,\"sess\":\"%s\",\"msg\":\"sesi sedang berjalan\"}", g_sess); publishAck(ack); return; }
  int j = 0;
  for (int i = 0; name[i] && j < (int)sizeof(g_sess) - 1; i++) { char c = name[i]; if (isalnum((unsigned char)c) || c == '_' || c == '-') g_sess[j++] = c; }
  g_sess[j] = 0;
  if (!j) snprintf(g_sess, sizeof(g_sess), "%s_%lu", DEVICE_ID, (unsigned long)(millis() / 1000));
  g_rawSeq = 0; g_dropMq = 0;
  g_sessPvt0 = g_pvtSeq; g_sessImu0 = g_imuSeq;
  g_sessStartMs = millis();
  g_sessActive = true;
  logEvent("REC_START", g_sess);
  snprintf(ack, sizeof(ack), "{\"cmd\":\"start\",\"ok\":true,\"sess\":\"%s\",\"file\":\"%s\",\"sd\":%s,\"pvt_seq0\":%lu,\"imu_seq0\":%lu}",
           g_sess, g_prefix, g_sdOk ? "true" : "false", (unsigned long)g_sessPvt0, (unsigned long)g_sessImu0);
  publishAck(ack);
}
static void sessionStop() {
  char ack[400];
  if (!g_sessActive) { publishAck("{\"cmd\":\"stop\",\"ok\":false,\"msg\":\"tidak ada sesi\"}"); return; }
  g_rawFlushReq = true;
  uint32_t t0 = millis();
  while (g_rawFlushReq && millis() - t0 < 1000) delay(5);
  g_sessActive = false;
  uint32_t pvt1 = g_pvtSeq, imu1 = g_imuSeq;
  for (int k = 0; k < 10 && uxQueueMessagesWaiting(qRaw); k++) {     // kirim sisa raw sebelum ack
    static RawItem rr;
    if (xQueueReceive(qRaw, &rr, 0) == pdTRUE && mqtt.connected()) mqtt.publish(T_RAW, rr.data, rr.len);
    mqtt.loop();
  }
  logEvent("REC_STOP", g_sess);
  snprintf(ack, sizeof(ack),
    "{\"cmd\":\"stop\",\"ok\":true,\"sess\":\"%s\",\"file\":\"%s\",\"dur_s\":%lu,\"raw_pkts\":%lu,"
    "\"pvt_seq0\":%lu,\"pvt_seq1\":%lu,\"imu_seq0\":%lu,\"imu_seq1\":%lu,\"drop_mqtt\":%lu}",
    g_sess, g_prefix, (unsigned long)((millis() - g_sessStartMs) / 1000), (unsigned long)g_rawSeq,
    (unsigned long)g_sessPvt0, (unsigned long)pvt1, (unsigned long)g_sessImu0, (unsigned long)imu1, (unsigned long)g_dropMq);
  publishAck(ack);
  g_sess[0] = 0;
}
static bool jsonStr(const char *js, const char *k, char *out, int cap) {
  char pat[24]; snprintf(pat, sizeof(pat), "\"%s\"", k);
  const char *p = strstr(js, pat); if (!p) return false;
  p = strchr(p + strlen(pat), ':'); if (!p) return false;
  p = strchr(p, '"'); if (!p) return false; p++;
  int i = 0; while (*p && *p != '"' && i < cap - 1) out[i++] = *p++;
  out[i] = 0; return true;
}
static long jsonInt(const char *js, const char *k, long def) {
  char pat[24]; snprintf(pat, sizeof(pat), "\"%s\"", k);
  const char *p = strstr(js, pat); if (!p) return def;
  p = strchr(p + strlen(pat), ':'); if (!p) return def;
  return strtol(p + 1, nullptr, 10);
}
static void handleCmd(const char *js) {
  char cmd[16] = "", sess[48] = "";
  if (!jsonStr(js, "cmd", cmd, sizeof(cmd))) return;
  if (!strcmp(cmd, "rate")) {
    long hz = jsonInt(js, "pvt_hz", 10);
    if (hz == 10 || hz == 5 || hz == 2 || hz == 1) { S.pvtHz = (uint8_t)hz; saveMqtt(); }
    char ack[96]; snprintf(ack, sizeof(ack), "{\"cmd\":\"rate\",\"ok\":true,\"pvt_hz\":%u}", S.pvtHz); publishAck(ack);
    return;
  }
  if (!strcmp(cmd, "start")) { jsonStr(js, "sess", sess, sizeof(sess)); sessionStart(sess); }
  else if (!strcmp(cmd, "stop")) sessionStop();
  else if (!strcmp(cmd, "ping")) publishAck("{\"cmd\":\"ping\",\"ok\":true}");
}
static void mqttCallback(char *topic, uint8_t *payload, unsigned int len) {
  if (strcmp(topic, T_CMD) != 0 || g_cmdPending) return;
  unsigned int n = len < sizeof(g_pendingCmd) - 1 ? len : sizeof(g_pendingCmd) - 1;
  memcpy(g_pendingCmd, payload, n); g_pendingCmd[n] = 0; g_cmdPending = true;
}

// =====================================================================
//  NTRIP Ina-CORS
// =====================================================================
static void ntripService() {
  static uint32_t nextTry = 0, lastGga = 0;
  static bool headerOk = false;
  if (g_ntripReset) { g_ntripReset = false; ntripClient.stop(); headerOk = false; nextTry = 0; g_ntripErr[0] = 0; }
  if (!S.ntEn || !strlen(S.ntMount) || !strlen(S.ntHost)) { g_ntripOk = false; if (!S.ntEn) strcpy(g_ntripErr, "nonaktif"); else strcpy(g_ntripErr, "mountpoint belum diisi"); return; }
  if (WiFi.status() != WL_CONNECTED) { if (ntripClient.connected()) ntripClient.stop(); g_ntripOk = false; return; }
  if (!ntripClient.connected()) {
    g_ntripOk = false; headerOk = false;
    if (millis() < nextTry) return;
    nextTry = millis() + 5000;
    if (!ntripClient.connect(S.ntHost, S.ntPort, 4000)) { snprintf(g_ntripErr, sizeof(g_ntripErr), "tidak tersambung ke caster"); return; }
    String auth = base64::encode(String(S.ntUser) + ":" + String(S.ntPass));
    ntripClient.printf("GET /%s HTTP/1.0\r\nUser-Agent: NTRIP FobosMini/%s\r\nAuthorization: Basic %s\r\n\r\n", S.ntMount, FW_VERSION, auth.c_str());
    uint32_t t0 = millis(); String line;
    while (millis() - t0 < 5000 && ntripClient.connected()) {
      if (ntripClient.available()) { char c = ntripClient.read(); if (c == '\n') break; if (c != '\r') line += c; }
      else delay(5);
    }
    if (line.indexOf("200") >= 0) {
      headerOk = true; g_ntripErr[0] = 0; lastGga = 0;
      Serial.printf("[NTRIP] %s\n", line.c_str()); logEvent("NTRIP_OK", S.ntMount);
    } else {
      snprintf(g_ntripErr, sizeof(g_ntripErr), "%s", line.length() ? line.c_str() : "tanpa jawaban");
      for (char *c = g_ntripErr; *c; c++) if (*c == '"' || *c == '\\' || *c == ',' || (uint8_t)*c < 32) *c = ' ';
      Serial.printf("[NTRIP] ditolak: %s\n", g_ntripErr); logEvent("NTRIP_FAIL", g_ntripErr);
      ntripClient.stop(); nextTry = millis() + 30000;
      return;
    }
  }
  if (!headerOk) return;
  static uint8_t buf[512];
  int n;
  while ((n = ntripClient.available()) > 0) {
    n = ntripClient.read(buf, min(n, (int)sizeof(buf)));
    if (n > 0) { Serial2.write(buf, n); g_ntripBytes += n; g_ntripLastMs = millis(); }
  }
  g_ntripOk = (millis() - g_ntripLastMs) < 5000;
  if (millis() - lastGga > NTRIP_GGA_PERIOD_MS) {
    char gga[100] = ""; Epoch e; bool have;
    xSemaphoreTake(stateMutex, portMAX_DELAY); strcpy(gga, g_lastGga); e = g_last; have = g_haveLast; xSemaphoreGive(stateMutex);
    if (!gga[0] && have && qualityClass(e.p) > 0) ggaFromPvt(e.p, gga, sizeof(gga));
    if (gga[0]) ntripClient.print(gga);
    lastGga = millis();
  }
}

// =====================================================================
//  MQTT
// =====================================================================
static bool mqttConnect() {
  bool second = g_broker == 1;
  const char *host = second ? S.m2Host : S.m1Host;
  if (!strlen(host)) { if (strlen(second ? S.m1Host : S.m2Host)) g_broker ^= 1; return false; }
  uint16_t port = second ? S.m2Port : S.m1Port;
  bool tls = second ? false : S.m1Tls;
  const char *user = second ? S.m2User : S.m1User, *pass = second ? S.m2Pass : S.m1Pass;
  if (tls) {
    if (S.m1Insecure) tlsClient.setInsecure();      // hanya untuk uji: tanpa verifikasi sertifikat server
    else tlsClient.setCACert(ROOT_CA_BUNDLE);
    mqtt.setClient(tlsClient);
  } else mqtt.setClient(plainClient);
  mqtt.setServer(host, port);
  char cid[40]; snprintf(cid, sizeof(cid), "fobos-%s-%04x", DEVICE_ID, (unsigned)(esp_random() & 0xFFFF));
  char will[64]; snprintf(will, sizeof(will), "{\"id\":\"%s\",\"online\":false}", DEVICE_ID);
  Serial.printf("[MQTT] menyambung ke %s (%s:%u)...\n", second ? "lokal" : "cloud", host, port);
  bool ok = mqtt.connect(cid, strlen(user) ? user : nullptr, strlen(pass) ? pass : nullptr, T_STATUS, 0, true, will);
  if (ok) { mqtt.subscribe(T_CMD); g_brokerFails = 0; Serial.println("[MQTT] tersambung"); }
  else {
    Serial.printf("[MQTT] gagal, rc=%d\n", mqtt.state());
    if (++g_brokerFails >= BROKER_FAILOVER_TRIES && strlen(second ? S.m1Host : S.m2Host)) { g_broker ^= 1; g_brokerFails = 0; }
  }
  return ok;
}

static void publishStatus() {
  char js[900];
  float ntripAge = g_ntripLastMs ? (millis() - g_ntripLastMs) / 1000.0f : -1;
  Epoch e; bool have;
  xSemaphoreTake(stateMutex, portMAX_DELAY); e = g_last; have = g_haveLast; xSemaphoreGive(stateMutex);
  TimeAnchor a; portENTER_CRITICAL(&anchorMux); a = g_anchor; portEXIT_CRITICAL(&anchorMux);
  char vib[16]; jnum(vib, sizeof(vib), g_vib, 3);
  String ip = WiFi.localIP().toString();
  snprintf(js, sizeof(js),
    "{\"id\":\"%s\",\"online\":true,\"fw\":\"%s\",\"up\":%lu,\"ssid\":\"%s\",\"rssi\":%d,\"ip\":\"%s\",\"ap\":%s,"
    "\"broker\":\"%s\",\"file\":\"%s\",\"ntrip\":{\"en\":%s,\"ok\":%s,\"age\":%.1f,\"kb\":%lu,\"err\":\"%s\",\"mount\":\"%s\"},"
    "\"gnss\":{\"cfg\":true,\"hz\":%.1f,\"rawx_hz\":%.1f,\"q\":%d,\"sv\":%d,\"nmea_bad\":%lu,\"u2_kb\":%lu},"
    "\"imu\":{\"ok\":%s,\"hz\":%.1f,\"maxdt\":%.1f,\"err\":%lu},\"time\":{\"valid\":%s,\"pps\":%s},\"vib\":%s,"
    "\"sd\":{\"ok\":%s,\"free_mb\":%lu,\"kb_raw\":%lu,\"kb_pos\":%lu,\"kb_imu\":%lu},\"sess\":\"%s\",\"sess_s\":%lu,"
    "\"raw_1hz\":%d,\"pvt_hz\":%u,\"drop\":{\"sd\":%lu,\"mq\":%lu},\"heap\":%lu}",
    DEVICE_ID, FW_VERSION, (unsigned long)(millis() / 1000), WiFi.SSID().c_str(), WiFi.RSSI(), ip.c_str(), apOn ? "true" : "false",
    g_broker ? "lokal" : "cloud", g_prefix,
    S.ntEn ? "true" : "false", g_ntripOk ? "true" : "false", ntripAge, (unsigned long)(g_ntripBytes / 1024), g_ntripErr, S.ntMount,
    g_pvtHz, g_rawxHz, have ? qualityClass(e.p) : 0, have ? e.p.numSV : 0, (unsigned long)g_mux.nNmeaBad, (unsigned long)(g_u2Bytes / 1024),
    g_imuOk ? "true" : "false", g_imuHz, g_imuMaxDtMs, (unsigned long)g_imuErr, a.valid ? "true" : "false", a.pps ? "true" : "false", vib,
    g_sdOk ? "true" : "false", (unsigned long)g_sdFreeMb, (unsigned long)g_sdKbRaw, (unsigned long)g_sdKbPos, (unsigned long)g_sdKbImu,
    g_sessActive ? g_sess : "", (unsigned long)(g_sessActive ? (millis() - g_sessStartMs) / 1000 : 0),
    RAW_STREAM_1HZ, S.pvtHz, (unsigned long)g_dropSd, (unsigned long)g_dropMq, (unsigned long)ESP.getFreeHeap());
  mqtt.publish(T_STATUS, js, true);
}

static void netTask(void *) {
  static RawItem rr; static PvtItem pi; ImuItem ii;
  static char js[640];
  uint32_t lastStatus = 0, nextMqttTry = 0;
  for (;;) {
    wifiService();
    server.handleClient();
    if (g_cmdPending) { handleCmd(g_pendingCmd); g_cmdPending = false; }
    if (WiFi.status() == WL_CONNECTED) {
      ntripService();
      if (g_mqttReset) { g_mqttReset = false; mqtt.disconnect(); g_brokerFails = 0; nextMqttTry = 0; }
      if (!mqtt.connected() && millis() > nextMqttTry) { if (!mqttConnect()) nextMqttTry = millis() + 2000; }
    }
    if (mqtt.connected()) {
      mqtt.loop();
      while (xQueueReceive(qPvt, &pi, 0) == pdTRUE) {
        pvtJson(js, sizeof(js), DEVICE_ID, pi.seq, pi.e, pi.week, pi.vib, g_sessActive ? g_sess : "");
        mqtt.publish(T_PVT, js);
      }
      while (xQueueReceive(qImu, &ii, 0) == pdTRUE) {
        imuJson(js, sizeof(js), DEVICE_ID, ii.seq, ii.week, ii.tow, ii.a, ii.g, ii.n, ii.vib, ii.tflag);
        mqtt.publish(T_IMU, js);
      }
      for (int k = 0; k < 2 && xQueueReceive(qRaw, &rr, 0) == pdTRUE; k++) mqtt.publish(T_RAW, rr.data, rr.len);
      if (millis() - lastStatus >= STATUS_PERIOD_MS) { publishStatus(); lastStatus = millis(); }
    } else {
      while (xQueueReceive(qPvt, &pi, 0) == pdTRUE) {}
      while (xQueueReceive(qImu, &ii, 0) == pdTRUE) {}
      while (xQueueReceive(qRaw, &rr, 0) == pdTRUE) g_dropMq++;
    }
    vTaskDelay(pdMS_TO_TICKS(5));
  }
}

// =====================================================================
//  Konsol serial: status | start NAMA | stop | scan
// =====================================================================
static void serialConsole() {
  static char line[80]; static int n = 0;
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\r') continue;
    if (c != '\n') { if (n < (int)sizeof(line) - 1) line[n++] = c; continue; }
    line[n] = 0; n = 0;
    if (!strncmp(line, "start", 5)) { snprintf(g_pendingCmd, sizeof(g_pendingCmd), "{\"cmd\":\"start\",\"sess\":\"%s\"}", line[5] ? line + 6 : ""); g_cmdPending = true; }
    else if (!strcmp(line, "stop")) { strcpy(g_pendingCmd, "{\"cmd\":\"stop\"}"); g_cmdPending = true; }
    else if (!strcmp(line, "scan")) { wState = W_IDLE; wTimer = 0; }
    else if (!strcmp(line, "status")) {
      Serial.printf("WiFi %s (%s) IP %s AP %s | MQTT %s | NTRIP %s %s | PVT %.1f Hz | RAWX %.1f Hz | IMU %.1f Hz maxdt %.1f ms | PPS %s | SD %s %s | sesi '%s'\n",
        WiFi.status() == WL_CONNECTED ? "OK" : "--", WiFi.SSID().c_str(), WiFi.localIP().toString().c_str(), apOn ? "ON" : "off",
        mqtt.connected() ? (g_broker ? "lokal" : "cloud") : "--", g_ntripOk ? "OK" : "--", g_ntripErr, g_pvtHz, g_rawxHz,
        g_imuHz, g_imuMaxDtMs, g_anchor.pps ? "ya" : "tidak", g_sdOk ? "OK" : "--", g_prefix, g_sess);
    }
  }
}

// =====================================================================
void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.printf("\n=== Fobos Mini %s, perangkat %s ===\n", FW_VERSION, DEVICE_ID);
  pinMode(PIN_LED, OUTPUT);
  pinMode(PIN_SD_CS, OUTPUT); digitalWrite(PIN_SD_CS, HIGH);
  loadSettings();

  stateMutex = xSemaphoreCreateMutex();
  sbRaw = xStreamBufferCreate(32 * 1024, 1);
  sbImu = xStreamBufferCreate(16 * 1024, 1);
  sbPos = xStreamBufferCreate(8 * 1024, 1);
  qPvt = xQueueCreate(16, sizeof(PvtItem));
  qImu = xQueueCreate(10, sizeof(ImuItem));
  qRaw = xQueueCreate(3, sizeof(RawItem));
  qEvt = xQueueCreate(12, sizeof(EvtItem));
  if (!sbRaw || !sbImu || !sbPos || !qPvt || !qImu || !qRaw || !qEvt) Serial.println("[MEM] alokasi buffer GAGAL");

  snprintf(T_PVT, sizeof(T_PVT), "%s/%s/pvt", MQTT_PREFIX, DEVICE_ID);
  snprintf(T_IMU, sizeof(T_IMU), "%s/%s/imu", MQTT_PREFIX, DEVICE_ID);
  snprintf(T_RAW, sizeof(T_RAW), "%s/%s/raw", MQTT_PREFIX, DEVICE_ID);
  snprintf(T_STATUS, sizeof(T_STATUS), "%s/%s/status", MQTT_PREFIX, DEVICE_ID);
  snprintf(T_CMD, sizeof(T_CMD), "%s/%s/cmd", MQTT_PREFIX, DEVICE_ID);
  snprintf(T_ACK, sizeof(T_ACK), "%s/%s/ack", MQTT_PREFIX, DEVICE_ID);
  snprintf(g_apName, sizeof(g_apName), "FobosMini-%s", DEVICE_ID);

  // Kartu SD + nomor file per nyala (tidak pernah menimpa)
  spiSd.begin(PIN_SD_SCK, PIN_SD_MISO, PIN_SD_MOSI, PIN_SD_CS);
  g_sdOk = SD.begin(PIN_SD_CS, spiSd, SD_SPI_HZ);
  if (g_sdOk) {
    prefs.begin("fobos", false);
    uint32_t n = prefs.getUInt("fileN", 0) + 1;
    char path[32];
    for (int guard = 0; guard < 10000; guard++, n++) { snprintf(path, sizeof(path), "/F%04lu_raw.ubx", (unsigned long)(n % 10000)); if (!SD.exists(path)) break; }
    prefs.putUInt("fileN", n);
    prefs.end();
    snprintf(g_prefix, sizeof(g_prefix), "F%04lu", (unsigned long)(n % 10000));
    g_sdFreeMb = (uint32_t)((SD.totalBytes() - SD.usedBytes()) / (1024ULL * 1024ULL));
  }
  Serial.printf("[SD] %s, file %s_*, kosong %lu MB\n", g_sdOk ? "OK" : "TIDAK ADA/gagal", g_prefix, (unsigned long)g_sdFreeMb);

  // IMU I2C
  Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL, I2C_HZ);
  g_imuOk = imu.begin(Wire, IMU_ACC_FS_G, IMU_GYR_FS_DPS);
  Serial.printf("[IMU] ICM-20948 %s (alamat 0x%02X)\n", g_imuOk ? "OK" : "TIDAK TERDETEKSI (cek SDA21/SCL22, 3,3 V)", imu.address());

  // UART ZED-F9P (baud sesuai u-center)
  Serial2.setRxBufferSize(8192);
  Serial2.begin(U1_BAUD, SERIAL_8N1, PIN_U1_RX, PIN_U1_TX);
  Serial1.setRxBufferSize(16384);
  Serial1.begin(U2_BAUD, SERIAL_8N1, PIN_U2_RX, PIN_U2_TX);
  if (PPS_ENABLE) { pinMode(PIN_PPS, INPUT); attachInterrupt(digitalPinToInterrupt(PIN_PPS), onPps, RISING); }

  // WiFi + portal + MQTT
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.setAutoReconnect(false);
  portalBegin();
  mqtt.setBufferSize(RAW_PKT_MAX + 256);
  mqtt.setKeepAlive(15);
  mqtt.setSocketTimeout(5);
  mqtt.setCallback(mqttCallback);

  if (g_imuOk) xTaskCreatePinnedToCore(imuTask, "imu", 4096, nullptr, 5, nullptr, 1);
  xTaskCreatePinnedToCore(gnssTask, "gnss", 8192, nullptr, 4, nullptr, 1);
  xTaskCreatePinnedToCore(sdTask, "sd", 6144, nullptr, 2, nullptr, 0);
  xTaskCreatePinnedToCore(netTask, "net", 12288, nullptr, 3, nullptr, 0);

  char d[96]; snprintf(d, sizeof(d), "fw %s id %s imu %s", FW_VERSION, DEVICE_ID, g_imuOk ? "ok" : "gagal");
  logEvent("BOOT", d);
  Serial.println("Perintah Serial Monitor (115200): status | scan | start NAMA | stop");
}

void loop() {
  serialConsole();
  // LED: kedip cepat = belum WiFi, kedip lambat = WiFi OK, menyala = sesi Record
  static uint32_t t = 0;
  uint32_t per = g_sessActive ? 0 : (WiFi.status() == WL_CONNECTED ? 1000 : 150);
  if (per == 0) digitalWrite(PIN_LED, HIGH);
  else if (millis() - t > per) { t = millis(); digitalWrite(PIN_LED, !digitalRead(PIN_LED)); }
  delay(10);
}
