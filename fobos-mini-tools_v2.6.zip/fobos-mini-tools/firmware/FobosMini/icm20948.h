// icm20948.h — driver I2C minimal ICM-20948 (akselerometer + giroskop; tanpa magnetometer/DMP).
// Alamat register: TDK DS-000189 (sama dengan peta SparkFun ICM-20948 Arduino Library).
// Alamat I2C 0x69 (AD0 = 1, bawaan papan SparkFun) atau 0x68 (AD0 = 0) dideteksi otomatis.
#pragma once
#include <Arduino.h>
#include <Wire.h>

class Icm20948 {
 public:
  static const uint8_t WHO_AM_I = 0x00, USER_CTRL = 0x03, PWR_MGMT_1 = 0x06, PWR_MGMT_2 = 0x07,
                       ACCEL_XOUT_H = 0x2D, REG_BANK_SEL = 0x7F;                       // bank 0
  static const uint8_t GYRO_SMPLRT_DIV = 0x00, GYRO_CONFIG_1 = 0x01, ODR_ALIGN_EN = 0x09,
                       ACCEL_SMPLRT_DIV_1 = 0x10, ACCEL_SMPLRT_DIV_2 = 0x11, ACCEL_CONFIG = 0x14;  // bank 2
  static const uint8_t WHO_AM_I_VAL = 0xEA;

  bool begin(TwoWire &w, uint8_t accFsG, uint16_t gyrFsDps) {
    _w = &w;
    const uint8_t addrs[2] = {0x69, 0x68};
    _addr = 0;
    for (uint8_t a : addrs) { _addr = a; _bank = 0xFF; bank(0); if (read(WHO_AM_I) == WHO_AM_I_VAL) break; _addr = 0; }
    if (!_addr) return false;
    write(PWR_MGMT_1, 0x80);  delay(50);        // DEVICE_RESET
    _bank = 0xFF; bank(0);
    write(PWR_MGMT_1, 0x01);  delay(20);        // bangun, clock otomatis
    if (read(WHO_AM_I) != WHO_AM_I_VAL) return false;
    write(PWR_MGMT_2, 0x00);                    // semua sumbu aktif
    uint8_t afs = accFsG >= 16 ? 3 : accFsG >= 8 ? 2 : accFsG >= 4 ? 1 : 0;
    uint8_t gfs = gyrFsDps >= 2000 ? 3 : gyrFsDps >= 1000 ? 2 : gyrFsDps >= 500 ? 1 : 0;
    _accLsbPerG = 16384.0f / (1 << afs);
    _gyrLsbPerDps = 131.0f / (1 << gfs);
    // ODR gyro = 1100/(1+div), accel = 1125/(1+div): div 4 -> 220/225 Hz, dibaca firmware tiap 5 ms.
    // DLPF ~111-120 Hz agar pita getaran 40-50 Hz tetap lolos.
    bank(2);
    write(ODR_ALIGN_EN, 0x01);
    write(GYRO_SMPLRT_DIV, 4);
    write(GYRO_CONFIG_1, (uint8_t)((2 << 3) | (gfs << 1) | 0x01));
    write(ACCEL_SMPLRT_DIV_1, 0); write(ACCEL_SMPLRT_DIV_2, 4);
    write(ACCEL_CONFIG, (uint8_t)((2 << 3) | (afs << 1) | 0x01));
    bank(0);
    delay(20);
    return true;
  }
  // 14 byte: accel XYZ, gyro XYZ, suhu (big-endian). Kembalikan false bila I2C gagal.
  bool readRaw(int16_t out[7]) {
    uint8_t b[14];
    if (!readBurst(ACCEL_XOUT_H, b, 14)) return false;
    for (int i = 0; i < 7; i++) out[i] = (int16_t)((b[2 * i] << 8) | b[2 * i + 1]);
    return true;
  }
  uint8_t address() const { return _addr; }
  float accLsbPerG() const { return _accLsbPerG; }
  float gyrLsbPerDps() const { return _gyrLsbPerDps; }

 private:
  TwoWire *_w = nullptr; uint8_t _addr = 0, _bank = 0xFF;
  float _accLsbPerG = 4096, _gyrLsbPerDps = 65.5f;
  void bank(uint8_t b) { if (b != _bank) { write(REG_BANK_SEL, (uint8_t)(b << 4)); _bank = b; } }
  void write(uint8_t reg, uint8_t v) { _w->beginTransmission(_addr); _w->write(reg); _w->write(v); _w->endTransmission(); }
  uint8_t read(uint8_t reg) { uint8_t v = 0; readBurst(reg, &v, 1); return v; }
  bool readBurst(uint8_t reg, uint8_t *dst, uint8_t n) {
    _w->beginTransmission(_addr); _w->write(reg);
    if (_w->endTransmission(false) != 0) return false;
    if (_w->requestFrom(_addr, n) != n) return false;
    for (uint8_t i = 0; i < n; i++) dst[i] = _w->read();
    return true;
  }
};
