// secrets_example.h — SALIN menjadi "secrets.h" lalu isi. secrets.h ada di .gitignore: JANGAN diunggah.
// Nilai di sini hanya NILAI AWAL. WiFi, NTRIP, dan broker MQTT bisa diganti kapan saja dari portal ESP32
// (http://IP-ESP32/ atau http://192.168.4.1 saat mode AP); hasilnya disimpan di memori ESP32.
#pragma once

#define DEVICE_ID "FM01"            // unik per perangkat (topik MQTT, nama AP)

// Portal ESP32: nama/password titik akses (min 8 karakter) dan login halaman pengaturan
#define AP_PASS       "fobos1234"
#define PORTAL_USER   "fobos"
#define PORTAL_PASS   "fobos1234"

// WiFi awal (boleh kosong; tambah lewat portal)
#define WIFI1_SSID "HotspotFobos"
#define WIFI1_PASS "isi_password"
#define WIFI2_SSID ""
#define WIFI2_PASS ""

// NTRIP Ina-CORS BIG: registrasi di nrtk.big.go.id; caster nrtk.big.go.id (IP 103.22.171.6) port 2001
#define NTRIP_ENABLE  1
#define NTRIP_HOST    "nrtk.big.go.id"
#define NTRIP_PORT    2001
#define NTRIP_MOUNT   ""
#define NTRIP_USER    ""
#define NTRIP_PASS    ""

// Broker 1 (cloud): flespi — gratis. User = TOKEN flespi untuk perangkat (64 karakter), password kosong.
// (Bisa juga broker lain, mis. EMQX Serverless: host dari konsol, port 8883, user/password.)
#define MQTT1_HOST    "mqtt.flespi.io"
#define MQTT1_PORT    8883
#define MQTT1_TLS     1
#define MQTT1_USER    ""            // tempel token flespi di sini ATAU isi lewat portal ESP32 -> MQTT
#define MQTT1_PASS    ""

// Broker 2 (cadangan): laptop tools/fobos_local.py, tanpa TLS, satu hotspot
#define MQTT2_HOST    ""
#define MQTT2_PORT    1883
#define MQTT2_USER    ""
#define MQTT2_PASS    ""
