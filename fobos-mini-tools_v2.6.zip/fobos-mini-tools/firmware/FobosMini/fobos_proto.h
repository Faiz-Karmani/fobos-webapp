// fobos_proto.h — logika portabel Fobos Mini v2 (tanpa ketergantungan Arduino; diuji di PC).
// Isi: parser UBX + NMEA campuran (UART1), dekoder NAV-PVT/RAWX, NMEA GGA/GST,
// penggabung epoch (PVT + GST + GGA), waktu GPS, paket raw "FOBR", format CSV/JSON, indeks getaran.
#pragma once
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

namespace fobos {

// ---------------------------------------------------------------- UBX parser
static const uint16_t UBX_MAX_PAYLOAD = 8192;   // RAWX maks 16 + 32*255 = 8176

struct UbxParser {
  enum State : uint8_t { SYNC1, SYNC2, CLS, ID, LEN1, LEN2, PAYLOAD, CKA, CKB };
  State st = SYNC1;
  uint8_t cls = 0, id = 0;
  uint16_t len = 0, idx = 0;
  uint8_t cka = 0, ckb = 0;
  uint8_t frame[UBX_MAX_PAYLOAD + 8];  // B5 62 cls id lenL lenH payload ckA ckB
  uint32_t nOk = 0, nBadCk = 0, nOverflow = 0;

  inline uint8_t *payload() { return frame + 6; }
  inline uint16_t frameLen() const { return (uint16_t)(len + 8); }

  bool feed(uint8_t b) {   // true bila satu frame lengkap dengan checksum benar
    switch (st) {
      case SYNC1: if (b == 0xB5) { frame[0] = b; st = SYNC2; } break;
      case SYNC2:
        if (b == 0x62) { frame[1] = b; st = CLS; }
        else st = (b == 0xB5) ? SYNC2 : SYNC1;
        break;
      case CLS: cls = b; frame[2] = b; cka = b; ckb = cka; st = ID; break;
      case ID: id = b; frame[3] = b; cka += b; ckb += cka; st = LEN1; break;
      case LEN1: len = b; frame[4] = b; cka += b; ckb += cka; st = LEN2; break;
      case LEN2:
        len |= (uint16_t)b << 8; frame[5] = b; cka += b; ckb += cka; idx = 0;
        if (len > UBX_MAX_PAYLOAD) { nOverflow++; st = SYNC1; }
        else st = (len == 0) ? CKA : PAYLOAD;
        break;
      case PAYLOAD:
        frame[6 + idx++] = b; cka += b; ckb += cka;
        if (idx >= len) st = CKA;
        break;
      case CKA:
        frame[6 + len] = b;
        if (b == cka) st = CKB; else { nBadCk++; st = SYNC1; }
        break;
      case CKB:
        frame[7 + len] = b; st = SYNC1;
        if (b == ckb) { nOk++; return true; }
        nBadCk++;
        break;
    }
    return false;
  }
};

// ------------------------------------------------- parser campuran UBX + NMEA (UART1)
inline int hexv(char c) { return c >= '0' && c <= '9' ? c - '0' : c >= 'A' && c <= 'F' ? c - 'A' + 10 : c >= 'a' && c <= 'f' ? c - 'a' + 10 : -1; }
inline bool nmeaChecksumOk(const char *s) {
  if (s[0] != '$') return false;
  uint8_t cs = 0; const char *p = s + 1;
  while (*p && *p != '*') cs ^= (uint8_t)*p++;
  if (*p != '*' || hexv(p[1]) < 0 || hexv(p[2]) < 0) return false;
  return cs == (uint8_t)(hexv(p[1]) * 16 + hexv(p[2]));
}

struct GnssMux {
  enum { NONE = 0, UBX = 1, NMEA = 2 };
  UbxParser ubx;
  char line[128]; uint8_t n = 0; bool inLine = false;
  uint32_t nNmeaOk = 0, nNmeaBad = 0;
  int feed(uint8_t b) {
    if (ubx.st != UbxParser::SYNC1) return ubx.feed(b) ? UBX : NONE;
    if (inLine) {
      if (b == '\r' || b == '\n') {
        inLine = false; line[n] = 0;
        if (n > 6 && nmeaChecksumOk(line)) { nNmeaOk++; return NMEA; }
        nNmeaBad++; return NONE;
      }
      if (b == 0xB5) { inLine = false; ubx.feed(b); return NONE; }
      if (n < sizeof(line) - 1) line[n++] = (char)b; else inLine = false;
      return NONE;
    }
    if (b == '$') { inLine = true; n = 0; line[n++] = '$'; return NONE; }
    return ubx.feed(b) ? UBX : NONE;
  }
};

// Ambil field ke-i (0 = "$GNGGA") dari kalimat NMEA; kembalikan panjang.
inline int nmeaField(const char *s, int i, char *out, int cap) {
  int f = 0; const char *p = s;
  while (*p && f < i) { if (*p == ',') f++; else if (*p == '*') return out[0] = 0, 0; p++; }
  int k = 0;
  while (*p && *p != ',' && *p != '*' && k < cap - 1) out[k++] = *p++;
  out[k] = 0; return k;
}
inline bool nmeaIs(const char *s, const char *type) { return strlen(s) > 6 && !strncmp(s + 3, type, 3); }
// "hhmmss.ss" -> seperseratus detik dalam hari
inline int32_t nmeaTimeCs(const char *t) {
  if (strlen(t) < 6) return -1;
  int hh = (t[0] - '0') * 10 + (t[1] - '0'), mm = (t[2] - '0') * 10 + (t[3] - '0');
  double ss = atof(t + 4);
  return (int32_t)lround((hh * 3600 + mm * 60) * 100.0 + ss * 100.0);
}

struct GgaRec { int32_t cs = -1; int q = 0; int sv = 0; float hdop = NAN, age = NAN; };
struct GstRec { int32_t cs = -1; float sLat = NAN, sLon = NAN, sAlt = NAN; };

inline bool parseGga(const char *s, GgaRec &g) {
  char f[24];
  nmeaField(s, 1, f, sizeof(f)); g.cs = nmeaTimeCs(f);
  nmeaField(s, 6, f, sizeof(f)); g.q = atoi(f);
  nmeaField(s, 7, f, sizeof(f)); g.sv = atoi(f);
  nmeaField(s, 8, f, sizeof(f)); g.hdop = f[0] ? (float)atof(f) : NAN;
  nmeaField(s, 13, f, sizeof(f)); g.age = f[0] ? (float)atof(f) : NAN;
  return g.cs >= 0;
}
inline bool parseGst(const char *s, GstRec &g) {
  char f[24];
  nmeaField(s, 1, f, sizeof(f)); g.cs = nmeaTimeCs(f);
  nmeaField(s, 6, f, sizeof(f)); g.sLat = f[0] ? (float)atof(f) : NAN;
  nmeaField(s, 7, f, sizeof(f)); g.sLon = f[0] ? (float)atof(f) : NAN;
  nmeaField(s, 8, f, sizeof(f)); g.sAlt = f[0] ? (float)atof(f) : NAN;
  return g.cs >= 0;
}

// ------------------------------------------------------------ helpers LE
inline uint16_t rdU2(const uint8_t *p) { return (uint16_t)(p[0] | (p[1] << 8)); }
inline uint32_t rdU4(const uint8_t *p) { return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24); }
inline int32_t  rdI4(const uint8_t *p) { return (int32_t)rdU4(p); }
inline double   rdR8(const uint8_t *p) { double d; memcpy(&d, p, 8); return d; }
inline void wrU2(uint8_t *p, uint16_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
inline void wrU4(uint8_t *p, uint32_t v) { for (int i = 0; i < 4; i++) p[i] = (uint8_t)(v >> (8 * i)); }

// ---------------------------------------------------------------- NAV-PVT
struct Pvt {
  uint32_t iTOW;
  uint16_t year; uint8_t month, day, hour, min, sec;
  uint8_t valid;
  int32_t nano;
  uint8_t fixType, flags, numSV;
  double lat, lon, hEll, hMSL, hAcc, vAcc, velN, velE, velD, gSpeed, headMot, pDOP;
  bool gnssFixOK() const { return flags & 0x01; }
  bool diffSoln() const { return flags & 0x02; }
  uint8_t carrSoln() const { return (flags >> 6) & 0x03; }
};

// 0 tanpa fix, 1 single, 2 DGNSS, 3 RTK float, 4 RTK fix
inline uint8_t qualityClass(const Pvt &p) {
  if (!p.gnssFixOK() || p.fixType < 2 || p.fixType == 5) return 0;
  if (p.carrSoln() == 2) return 4;
  if (p.carrSoln() == 1) return 3;
  if (p.diffSoln()) return 2;
  return 1;
}
inline const char *qualityName(uint8_t q) {
  static const char *n[] = {"TANPA_FIX", "SINGLE", "DGNSS", "FLOAT", "FIX"};
  return q < 5 ? n[q] : "?";
}

inline bool decodePvt(const uint8_t *pl, uint16_t len, Pvt &o) {
  if (len < 92) return false;
  o.iTOW = rdU4(pl + 0);
  o.year = rdU2(pl + 4); o.month = pl[6]; o.day = pl[7]; o.hour = pl[8]; o.min = pl[9]; o.sec = pl[10];
  o.valid = pl[11];
  o.nano = rdI4(pl + 16);
  o.fixType = pl[20]; o.flags = pl[21]; o.numSV = pl[23];
  o.lon = rdI4(pl + 24) * 1e-7; o.lat = rdI4(pl + 28) * 1e-7;
  o.hEll = rdI4(pl + 32) * 1e-3; o.hMSL = rdI4(pl + 36) * 1e-3;
  o.hAcc = rdU4(pl + 40) * 1e-3; o.vAcc = rdU4(pl + 44) * 1e-3;
  o.velN = rdI4(pl + 48) * 1e-3; o.velE = rdI4(pl + 52) * 1e-3; o.velD = rdI4(pl + 56) * 1e-3;
  o.gSpeed = rdI4(pl + 60) * 1e-3;
  o.headMot = rdI4(pl + 64) * 1e-5;
  o.pDOP = rdU2(pl + 76) * 0.01;
  return true;
}
inline int32_t pvtTimeCs(const Pvt &p) {
  int64_t cs = (int64_t)(p.hour * 3600 + p.min * 60 + p.sec) * 100 + (int64_t)floor(p.nano / 1e7 + 0.5);
  cs %= 8640000; if (cs < 0) cs += 8640000;
  return (int32_t)cs;
}

// ---------------------------------------------------------------- RAWX
struct RawxHead { double rcvTow; uint16_t week; int8_t leapS; uint8_t numMeas; };
inline bool decodeRawxHead(const uint8_t *pl, uint16_t len, RawxHead &h) {
  if (len < 16) return false;
  h.rcvTow = rdR8(pl); h.week = rdU2(pl + 8); h.leapS = (int8_t)pl[10]; h.numMeas = pl[11];
  return len == 16 + 32 * h.numMeas;
}
inline bool rawxOnWholeSecond(double rcvTow, double tol = 0.005) {
  return fabs(rcvTow - floor(rcvTow + 0.5)) < tol;
}

// ---------------------------------------------------------------- waktu
static const int GPS_UTC_LEAP_S = 18;
inline int64_t daysFromCivil(int y, unsigned m, unsigned d) {   // algoritma H. Hinnant
  y -= m <= 2;
  const int64_t era = (y >= 0 ? y : y - 399) / 400;
  const unsigned yoe = (unsigned)(y - era * 400);
  const unsigned doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1;
  const unsigned doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
  return era * 146097 + (int64_t)doe - 719468;
}
inline int gpsWeekFromPvt(const Pvt &p) {
  if ((p.valid & 0x03) != 0x03) return -1;
  int64_t unixS = daysFromCivil(p.year, p.month, p.day) * 86400 + p.hour * 3600 + p.min * 60 + p.sec;
  double gpsSec = (double)(unixS - 315964800 + GPS_UTC_LEAP_S) - p.iTOW / 1000.0;
  return (int)floor(gpsSec / 604800.0 + 0.5);
}

// ------------------------------------------------- penggabung epoch PVT + GST + GGA
// NMEA dan NAV-PVT satu epoch bisa datang dengan urutan apa pun; baris dikeluarkan saat
// PVT berikutnya tiba atau setelah batas waktu, dengan GST/GGA yang waktunya cocok (±1 cs).
struct Epoch { Pvt p; GgaRec gga; GstRec gst; int32_t cs; };
struct EpochMerger {
  static const int N = 6;
  GgaRec gga[N]; GstRec gst[N]; int ig = 0, is = 0;
  Epoch pend; bool havePend = false; uint32_t pendMs = 0;
  void addGga(const GgaRec &g) { gga[ig] = g; ig = (ig + 1) % N; }
  void addGst(const GstRec &g) { gst[is] = g; is = (is + 1) % N; }
  static bool near(int32_t a, int32_t b) { int32_t d = abs(a - b); return d <= 1 || d >= 8640000 - 1; }
  void attach(Epoch &e) {
    e.gga = GgaRec(); e.gst = GstRec();
    for (int i = 0; i < N; i++) { if (gga[i].cs >= 0 && near(gga[i].cs, e.cs)) e.gga = gga[i]; if (gst[i].cs >= 0 && near(gst[i].cs, e.cs)) e.gst = gst[i]; }
  }
  // PVT baru: keluarkan epoch sebelumnya (bila ada) ke out
  bool onPvt(const Pvt &p, uint32_t nowMs, Epoch &out) {
    bool emit = false;
    if (havePend) { out = pend; attach(out); emit = true; }
    pend.p = p; pend.cs = pvtTimeCs(p); havePend = true; pendMs = nowMs;
    return emit;
  }
  bool poll(uint32_t nowMs, uint32_t timeoutMs, Epoch &out) {
    if (!havePend || nowMs - pendMs < timeoutMs) return false;
    out = pend; attach(out); havePend = false; return true;
  }
};

// ------------------------------------------------- CSV & JSON
static const char POS_CSV_HEADER[] =
  "utc,gps_week,tow_s,lat,lon,h_msl,h_ell,q,status,fix_type,carr_soln,num_sv,h_acc,v_acc,"
  "std_lat,std_lon,std_alt,gga_q,hdop,diff_age,speed,heading,pdop\n";

inline const char *fmtF(char *b, int cap, double v, int dec) {
  if (isnan(v)) { b[0] = 0; return b; }
  snprintf(b, cap, "%.*f", dec, v); return b;
}
inline int utcIso(char *out, int cap, const Pvt &p) {
  return snprintf(out, cap, "%04u-%02u-%02uT%02u:%02u:%02u.%02dZ", p.year, p.month, p.day, p.hour, p.min, p.sec,
                  (int)((p.nano > 0 ? p.nano : 0) / 10000000) % 100);
}
inline int posCsvLine(char *out, int cap, const Epoch &e, int week) {
  const Pvt &p = e.p; char u[32], a[16], b[16], c[16], d[16], f[16];
  utcIso(u, sizeof(u), p);
  uint8_t q = qualityClass(p);
  return snprintf(out, cap, "%s,%d,%.3f,%.9f,%.9f,%.3f,%.3f,%u,%s,%u,%u,%u,%.3f,%.3f,%s,%s,%s,%d,%s,%s,%.3f,%.2f,%.2f\n",
    u, week, p.iTOW / 1000.0, p.lat, p.lon, p.hMSL, p.hEll, q, qualityName(q), p.fixType, p.carrSoln(), p.numSV,
    p.hAcc, p.vAcc, fmtF(a, 16, e.gst.sLat, 3), fmtF(b, 16, e.gst.sLon, 3), fmtF(c, 16, e.gst.sAlt, 3),
    e.gga.cs >= 0 ? e.gga.q : -1, fmtF(d, 16, e.gga.hdop, 2), fmtF(f, 16, e.gga.age, 1),
    p.gSpeed, p.headMot, p.pDOP);
}
inline const char *jnum(char *b, int cap, double v, int dec) {
  if (isnan(v)) snprintf(b, cap, "null"); else snprintf(b, cap, "%.*f", dec, v);
  return b;
}
inline int pvtJson(char *out, int cap, const char *dev, uint32_t seq, const Epoch &e, int week, double vib, const char *sess) {
  const Pvt &p = e.p; char u[32], v[16], a[16], b[16], c[16], d[16], f[16];
  utcIso(u, sizeof(u), p);
  return snprintf(out, cap,
    "{\"id\":\"%s\",\"seq\":%lu,\"tow\":%lu,\"wk\":%d,\"utc\":\"%s\",\"lat\":%.9f,\"lon\":%.9f,\"h\":%.3f,\"hae\":%.3f,"
    "\"q\":%u,\"fix\":%u,\"carr\":%u,\"sv\":%u,\"hacc\":%.3f,\"vacc\":%.3f,\"slat\":%s,\"slon\":%s,\"salt\":%s,"
    "\"hdop\":%s,\"age\":%s,\"spd\":%.2f,\"hdg\":%.1f,\"pdop\":%.2f,\"vib\":%s,\"sess\":\"%s\"}",
    dev, (unsigned long)seq, (unsigned long)p.iTOW, week, u, p.lat, p.lon, p.hMSL, p.hEll,
    qualityClass(p), p.fixType, p.carrSoln(), p.numSV, p.hAcc, p.vAcc,
    jnum(a, 16, e.gst.sLat, 3), jnum(b, 16, e.gst.sLon, 3), jnum(c, 16, e.gst.sAlt, 3),
    jnum(d, 16, e.gga.hdop, 2), jnum(f, 16, e.gga.age, 1), p.gSpeed, p.headMot, p.pDOP,
    jnum(v, 16, vib, 3), sess ? sess : "");
}

// GGA buatan dari PVT (cadangan bila ZED tidak mengeluarkan GGA)
inline int ggaFromPvt(const Pvt &p, char *out, int cap) {
  int q = 0;
  switch (qualityClass(p)) { case 1: q = 1; break; case 2: q = 2; break; case 3: q = 5; break; case 4: q = 4; break; }
  double alat = fabs(p.lat), alon = fabs(p.lon);
  int latd = (int)alat, lond = (int)alon;
  char body[128];
  snprintf(body, sizeof(body), "GPGGA,%02u%02u%02u.%02d,%02d%010.7f,%c,%03d%010.7f,%c,%d,%02u,%.1f,%.3f,M,%.3f,M,,",
           p.hour, p.min, p.sec, (int)((p.nano > 0 ? p.nano : 0) / 10000000) % 100,
           latd, (alat - latd) * 60.0, p.lat < 0 ? 'S' : 'N', lond, (alon - lond) * 60.0, p.lon < 0 ? 'W' : 'E',
           q, p.numSV, p.pDOP > 0 ? p.pDOP : 1.0, p.hMSL, p.hEll - p.hMSL);
  uint8_t cs = 0; for (const char *c = body; *c; c++) cs ^= (uint8_t)*c;
  return snprintf(out, cap, "$%s*%02X\r\n", body, cs);
}

// ------------------------------------------------- paket raw "FOBR" v1 (web, saat sesi)
// Header 16 byte: "FOBR" | ver u8 | flags u8 | rsv u16 | seq u32 | tow_ms u32 ; lalu frame UBX utuh.
static const uint16_t RAW_HDR = 16, RAW_PKT_MAX = 6144;
struct RawPacket {
  uint8_t buf[RAW_PKT_MAX];
  uint16_t len = RAW_HDR;
  uint32_t dropped = 0;
  void begin(uint32_t seq, uint32_t towMs) {
    memcpy(buf, "FOBR", 4); buf[4] = 1; buf[5] = 0; wrU2(buf + 6, 0);
    wrU4(buf + 8, seq); wrU4(buf + 12, towMs); len = RAW_HDR;
  }
  bool append(const uint8_t *f, uint16_t n) {
    if (len + n > RAW_PKT_MAX) { dropped++; return false; }
    memcpy(buf + len, f, n); len += n; return true;
  }
  bool empty() const { return len <= RAW_HDR; }
};

// ------------------------------------------------- indeks getaran
// RMS percepatan dinamis searah gravitasi rata-rata jendela: sqrt(u^T C u), C = kovarians a.
struct VibAcc {
  double s[3] = {0, 0, 0}, ss[6] = {0, 0, 0, 0, 0, 0};
  uint32_t n = 0;
  void reset() { memset(s, 0, sizeof(s)); memset(ss, 0, sizeof(ss)); n = 0; }
  void add(double ax, double ay, double az) {
    s[0] += ax; s[1] += ay; s[2] += az;
    ss[0] += ax * ax; ss[1] += ay * ay; ss[2] += az * az;
    ss[3] += ax * ay; ss[4] += ax * az; ss[5] += ay * az; n++;
  }
  double rms() const {
    if (n < 10) return NAN;
    double m[3] = {s[0] / n, s[1] / n, s[2] / n};
    double g = sqrt(m[0] * m[0] + m[1] * m[1] + m[2] * m[2]);
    if (g < 1e-6) return NAN;
    double u[3] = {m[0] / g, m[1] / g, m[2] / g};
    double cxx = ss[0] / n - m[0] * m[0], cyy = ss[1] / n - m[1] * m[1], czz = ss[2] / n - m[2] * m[2];
    double cxy = ss[3] / n - m[0] * m[1], cxz = ss[4] / n - m[0] * m[2], cyz = ss[5] / n - m[1] * m[2];
    double v = u[0] * u[0] * cxx + u[1] * u[1] * cyy + u[2] * u[2] * czz +
               2 * (u[0] * u[1] * cxy + u[0] * u[2] * cxz + u[1] * u[2] * cyz);
    return v > 0 ? sqrt(v) : 0.0;
  }
};

// ------------------------------------------------- IMU: baris CSV SD (200 Hz) & JSON web (5 Hz)
static const char IMU_CSV_HEADER[] = "gps_week,tow_s,ax,ay,az,gx,gy,gz,temp_c,tflag\n";   // m/s2, rad/s; tflag 0 lokal,1 GPS,3 GPS+PPS
inline int imuCsvLine(char *out, int cap, int week, double towS, const float a[3], const float g[3], float tc, uint8_t tflag) {
  return snprintf(out, cap, "%d,%.6f,%.4f,%.4f,%.4f,%.6f,%.6f,%.6f,%.2f,%u\n",
                  week, towS, a[0], a[1], a[2], g[0], g[1], g[2], tc, tflag);
}
inline int imuJson(char *out, int cap, const char *dev, uint32_t seq, int week, double towS, const float a[3],
                   const float g[3], uint16_t n, double vib, uint8_t tflag) {
  char v[16];
  return snprintf(out, cap,
    "{\"id\":\"%s\",\"seq\":%lu,\"wk\":%d,\"tow\":%.3f,\"ax\":%.4f,\"ay\":%.4f,\"az\":%.4f,"
    "\"gx\":%.5f,\"gy\":%.5f,\"gz\":%.5f,\"n\":%u,\"vib\":%s,\"tflag\":%u}",
    dev, (unsigned long)seq, week, towS, a[0], a[1], a[2], g[0], g[1], g[2], n, jnum(v, 16, vib, 3), tflag);
}

}  // namespace fobos
