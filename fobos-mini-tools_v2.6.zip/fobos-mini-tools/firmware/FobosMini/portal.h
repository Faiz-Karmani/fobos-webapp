// portal.h — halaman pengaturan Fobos Mini di ESP32 (WebServer port 80, login Basic).
// Dibuka dari browser mana pun di jaringan yang sama: http://IP-ESP32/  atau  http://fobos-fm01.local/
// Bila ESP32 belum tersambung WiFi: sambungkan HP ke AP "FobosMini-<ID>" lalu buka http://192.168.4.1/
// Disertakan oleh FobosMini.ino setelah semua variabel global dideklarasikan.
#pragma once

static String esc(const char *s) {
  String o; o.reserve(strlen(s) + 8);
  for (const char *p = s; *p; p++) {
    switch (*p) { case '&': o += "&amp;"; break; case '<': o += "&lt;"; break; case '>': o += "&gt;"; break;
                  case '"': o += "&quot;"; break; case '\'': o += "&#39;"; break; default: o += *p; }
  }
  return o;
}
static bool portalAuth() {
  if (server.authenticate(PORTAL_USER, PORTAL_PASS)) return true;
  server.requestAuthentication(BASIC_AUTH, "Fobos Mini", "Login diperlukan");
  return false;
}
static String pageHead(const char *title) {
  String h = F("<!DOCTYPE html><html lang='id'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
               "<title>Fobos Mini</title><style>body{font:15px system-ui,sans-serif;margin:0;background:#f4f6f9;color:#1d2430}"
               "header{background:#14233c;color:#fff;padding:10px 14px}header a{color:#cfe0ff;margin-right:12px;text-decoration:none}"
               "main{padding:12px;max-width:720px;margin:auto}.card{background:#fff;border:1px solid #dde1e7;border-radius:8px;padding:10px 12px;margin:10px 0}"
               "table{border-collapse:collapse;width:100%}td,th{border-bottom:1px solid #eee;padding:5px;text-align:left;font-size:14px}"
               "input,select{font:inherit;padding:6px;width:100%;box-sizing:border-box;margin:3px 0 8px;border:1px solid #ccd;border-radius:5px}"
               "button{font:inherit;padding:7px 12px;border-radius:6px;border:1px solid #1f5fbf;background:#1f5fbf;color:#fff;cursor:pointer}"
               "button.alt{background:#fff;color:#1f5fbf}.ok{color:#1a9850;font-weight:600}.bad{color:#c62828;font-weight:600}.muted{color:#6b7380;font-size:13px}"
               "</style></head><body><header><b>Fobos Mini ");
  h += DEVICE_ID; h += F("</b><br><a href='/'>Status</a><a href='/wifi'>WiFi</a><a href='/ntrip'>NTRIP</a><a href='/mqtt'>MQTT</a></header><main><h3>");
  h += title; h += F("</h3>");
  return h;
}
static const char *PAGE_END = "</main></body></html>";

static void handleRoot() {
  if (!portalAuth()) return;
  Epoch e; bool have;
  xSemaphoreTake(stateMutex, portMAX_DELAY); e = g_last; have = g_haveLast; xSemaphoreGive(stateMutex);
  String h = pageHead("Status");
  h += F("<div class='card'><table>");
  h += "<tr><td>Firmware</td><td>" FW_VERSION "</td></tr>";
  h += "<tr><td>WiFi</td><td>" + String(WiFi.status() == WL_CONNECTED ? "<span class='ok'>tersambung</span> " + esc(WiFi.SSID().c_str()) + " (" + String(WiFi.RSSI()) + " dBm)" : "<span class='bad'>belum tersambung</span>") + "</td></tr>";
  h += "<tr><td>IP ESP32</td><td>" + WiFi.localIP().toString() + (apOn ? " &nbsp;| AP " + esc(g_apName) + " " + WiFi.softAPIP().toString() : String("")) + "</td></tr>";
  h += "<tr><td>NTRIP</td><td>" + String(g_ntripOk ? "<span class='ok'>OK</span> " : "<span class='bad'>--</span> ") + esc(S.ntMount) + " " + esc(g_ntripErr) + "</td></tr>";
  h += "<tr><td>MQTT</td><td>" + String(mqtt.connected() ? "<span class='ok'>tersambung</span> " : "<span class='bad'>--</span> ") + (g_broker ? "lokal" : "cloud") + "</td></tr>";
  if (have) {
    char b[128]; snprintf(b, sizeof(b), "%s, %u satelit, %.9f, %.9f, &plusmn;%.3f m", qualityName(qualityClass(e.p)), e.p.numSV, e.p.lat, e.p.lon, e.p.hAcc);
    h += "<tr><td>Posisi</td><td>" + String(b) + "</td></tr>";
  } else h += F("<tr><td>Posisi</td><td>belum ada NAV-PVT dari UART1</td></tr>");
  char b[160];
  snprintf(b, sizeof(b), "NAV-PVT %.1f Hz &middot; RAWX %.1f Hz &middot; IMU %.0f Hz (jeda maks %.1f ms) &middot; PPS %s", g_pvtHz, g_rawxHz, g_imuHz, g_imuMaxDtMs, g_anchor.pps ? "ya" : "tidak");
  h += "<tr><td>Laju data</td><td>" + String(b) + "</td></tr>";
  snprintf(b, sizeof(b), "%s &middot; file %s_* &middot; raw %lu KB, pos %lu KB, imu %lu KB &middot; sisa %lu MB", g_sdOk ? "OK" : "TIDAK ADA", g_prefix,
           (unsigned long)g_sdKbRaw, (unsigned long)g_sdKbPos, (unsigned long)g_sdKbImu, (unsigned long)g_sdFreeMb);
  h += "<tr><td>Kartu SD</td><td>" + String(b) + "</td></tr>";
  h += "<tr><td>Sesi Record</td><td>" + String(g_sessActive ? esc(g_sess) : String("-")) + "</td></tr>";
  h += F("</table></div><form method='post' action='/restart' onsubmit=\"return confirm('Mulai ulang ESP32? File SD baru akan dibuat.')\"><button class='alt'>Mulai ulang ESP32</button></form>");
  h += PAGE_END;
  server.send(200, "text/html", h);
}

static void handleWifi() {
  if (!portalAuth()) return;
  if (server.hasArg("scan")) doScan();
  String h = pageHead("WiFi");
  h += F("<div class='card'><b>Jaringan tersimpan</b> <span class='muted'>(disambungkan otomatis ke yang sinyalnya terkuat)</span><table>");
  for (int i = 0; i < S.nWifi; i++) {
    h += "<tr><td>" + esc(S.wSsid[i]) + "</td><td><a href='/wifi/use?i=" + String(i) + "'>sambung</a> &nbsp; <a href='/wifi/del?i=" + String(i) + "' onclick=\"return confirm('Hapus?')\">hapus</a></td></tr>";
  }
  if (!S.nWifi) h += F("<tr><td class='muted'>belum ada</td></tr>");
  h += F("</table></div><div class='card'><b>Jaringan di sekitar</b> <a href='/wifi?scan=1'>[pindai ulang]</a><table>");
  for (int k = 0; k < fobos_nScan; k++) {
    h += "<tr><td><a href='#' onclick=\"document.getElementById('s').value=this.textContent;return false\">" + esc(fobos_scan[k].ssid) + "</a></td><td>" +
         String(fobos_scan[k].rssi) + " dBm" + (fobos_scan[k].open ? " (terbuka)" : "") + "</td></tr>";
  }
  if (!fobos_nScan) h += F("<tr><td class='muted'>belum dipindai — klik [pindai ulang] (koneksi terputus sesaat)</td></tr>");
  h += F("</table></div><div class='card'><b>Tambah / ganti password</b><form method='post' action='/wifi/save'>"
         "SSID<input id='s' name='ssid' maxlength='32' required>Password<input name='pass' type='password' maxlength='64'>"
         "<button>Simpan &amp; sambungkan</button></form><p class='muted'>ESP32 hanya mendukung WiFi 2,4 GHz. Setelah berpindah jaringan, IP ESP32 berubah: "
         "lihat di web app pemantauan, Serial Monitor, atau buka http://fobos-");
  String id = DEVICE_ID; id.toLowerCase(); h += id;
  h += F(".local/</p></div>");
  h += PAGE_END;
  server.send(200, "text/html", h);
}
static void redirect(const char *to) { server.sendHeader("Location", to); server.send(303, "text/plain", ""); }
static void msgPage(const String &title, const String &body) { String h = pageHead(title.c_str()); h += "<div class='card'>" + body + "</div>" + PAGE_END; server.send(200, "text/html", h); }

static void handleWifiSave() {
  if (!portalAuth()) return;
  String ss = server.arg("ssid"), pw = server.arg("pass");
  ss.trim();
  if (!ss.length() || ss.length() > 32 || pw.length() > 64) { msgPage("WiFi", "SSID/password tidak valid."); return; }
  int idx = -1;
  for (int i = 0; i < S.nWifi; i++) if (ss == S.wSsid[i]) idx = i;
  if (idx < 0) {            // tambahkan di depan; buang yang paling lama bila penuh
    if (S.nWifi == MAX_SAVED_WIFI) S.nWifi--;
    for (int i = S.nWifi; i > 0; i--) { strcpy(S.wSsid[i], S.wSsid[i - 1]); strcpy(S.wPass[i], S.wPass[i - 1]); }
    S.nWifi++; idx = 0;
  }
  strncpy(S.wSsid[idx], ss.c_str(), 32); S.wSsid[idx][32] = 0;
  strncpy(S.wPass[idx], pw.c_str(), 64); S.wPass[idx][64] = 0;
  saveWifi();
  g_pendingWifi = idx;
  String id = DEVICE_ID; id.toLowerCase();
  msgPage("WiFi", "Tersimpan. ESP32 sedang menyambung ke <b>" + esc(ss.c_str()) + "</b>. Halaman ini akan terputus bila anda membukanya lewat WiFi lama.<br><br>"
          "Setelah tersambung, buka portal di IP baru (terlihat di web app pemantauan / Serial Monitor) atau http://fobos-" + id + ".local/. "
          "Bila gagal dalam 15 detik, AP <b>" + esc(g_apName) + "</b> menyala lagi (http://192.168.4.1).");
}
static void handleWifiUse() { if (!portalAuth()) return; int i = server.arg("i").toInt(); if (i >= 0 && i < S.nWifi) g_pendingWifi = i; redirect("/"); }
static void handleWifiDel() {
  if (!portalAuth()) return;
  int i = server.arg("i").toInt();
  if (i >= 0 && i < S.nWifi) { for (int k = i; k < S.nWifi - 1; k++) { strcpy(S.wSsid[k], S.wSsid[k + 1]); strcpy(S.wPass[k], S.wPass[k + 1]); } S.nWifi--; saveWifi(); }
  redirect("/wifi");
}

static void handleNtrip() {
  if (!portalAuth()) return;
  String h = pageHead("NTRIP Ina-CORS");
  h += F("<div class='card'><form method='post' action='/ntrip/save'>");
  h += String("<label><input type='checkbox' name='en' value='1' style='width:auto'") + (S.ntEn ? " checked" : "") + "> aktif</label><br>";
  h += "Host caster<input name='host' value='" + esc(S.ntHost) + "'>";
  h += "Port<input name='port' type='number' value='" + String(S.ntPort) + "'>";
  h += "Mountpoint<input name='mount' id='m' value='" + esc(S.ntMount) + "'>";
  h += "User<input name='user' value='" + esc(S.ntUser) + "'>";
  h += F("Password <span class='muted'>(kosongkan = tidak diubah)</span><input name='pass' type='password'>"
         "<button>Simpan &amp; sambung ulang</button></form></div>"
         "<div class='card'><a href='/ntrip/table'>Lihat daftar mountpoint caster</a> <span class='muted'>(diurutkan dari yang terdekat bila sudah ada posisi)</span></div>");
  h += PAGE_END;
  server.send(200, "text/html", h);
}
static void handleNtripSave() {
  if (!portalAuth()) return;
  S.ntEn = server.hasArg("en");
  strncpy(S.ntHost, server.arg("host").c_str(), sizeof(S.ntHost) - 1); S.ntHost[sizeof(S.ntHost) - 1] = 0;
  S.ntPort = (uint16_t)server.arg("port").toInt();
  strncpy(S.ntMount, server.arg("mount").c_str(), sizeof(S.ntMount) - 1); S.ntMount[sizeof(S.ntMount) - 1] = 0;
  strncpy(S.ntUser, server.arg("user").c_str(), sizeof(S.ntUser) - 1); S.ntUser[sizeof(S.ntUser) - 1] = 0;
  if (server.arg("pass").length()) { strncpy(S.ntPass, server.arg("pass").c_str(), sizeof(S.ntPass) - 1); S.ntPass[sizeof(S.ntPass) - 1] = 0; }
  saveNtrip();
  g_ntripReset = true;
  redirect("/");
}
// Ambil sourcetable caster (baris STR;mount;identifier;format;...;lat;lon;...)
static void handleNtripTable() {
  if (!portalAuth()) return;
  if (WiFi.status() != WL_CONNECTED) { msgPage("Mountpoint", "WiFi belum tersambung ke internet."); return; }
  WiFiClient c;
  if (!c.connect(S.ntHost, S.ntPort, 4000)) { msgPage("Mountpoint", "Tidak bisa tersambung ke caster."); return; }
  String auth = base64::encode(String(S.ntUser) + ":" + String(S.ntPass));
  c.printf("GET / HTTP/1.0\r\nUser-Agent: NTRIP FobosMini/%s\r\nAuthorization: Basic %s\r\n\r\n", FW_VERSION, auth.c_str());
  struct Mp { char name[32]; char ident[32]; char fmt[16]; float lat, lon, dist; };
  static Mp mp[120]; int n = 0;
  Epoch e; bool have;
  xSemaphoreTake(stateMutex, portMAX_DELAY); e = g_last; have = g_haveLast && qualityClass(g_last.p) > 0; xSemaphoreGive(stateMutex);
  uint32_t t0 = millis(); String line;
  while (millis() - t0 < 6000 && (c.connected() || c.available())) {
    if (!c.available()) { delay(5); continue; }
    char ch = c.read();
    if (ch != '\n') { if (ch != '\r' && line.length() < 400) line += ch; continue; }
    if (line.startsWith("ENDSOURCETABLE")) break;
    if (line.startsWith("STR;") && n < 120) {
      String f[11]; int k = 0, start = 0;
      for (int i = 0; i <= (int)line.length() && k < 11; i++) if (i == (int)line.length() || line[i] == ';') { f[k++] = line.substring(start, i); start = i + 1; }
      Mp &m = mp[n++];
      strncpy(m.name, f[1].c_str(), 31); m.name[31] = 0; strncpy(m.ident, f[2].c_str(), 31); m.ident[31] = 0;
      strncpy(m.fmt, f[3].c_str(), 15); m.fmt[15] = 0;
      m.lat = f[9].toFloat(); m.lon = f[10].toFloat();
      m.dist = have ? (float)(6371.0 * acos(fmin(1.0, sin(e.p.lat * M_PI / 180) * sin(m.lat * M_PI / 180) +
                       cos(e.p.lat * M_PI / 180) * cos(m.lat * M_PI / 180) * cos((e.p.lon - m.lon) * M_PI / 180)))) : -1;
    }
    line = "";
  }
  c.stop();
  if (have) for (int i = 1; i < n; i++) { Mp t = mp[i]; int j = i - 1; while (j >= 0 && mp[j].dist > t.dist) { mp[j + 1] = mp[j]; j--; } mp[j + 1] = t; }
  String h = pageHead("Mountpoint caster");
  h += "<div class='card'><p class='muted'>" + String(n) + " mountpoint" + (have ? ", diurutkan dari jarak ke posisi sekarang." : ".") + " Klik nama untuk memakainya.</p><table><tr><th>Mountpoint</th><th>Nama</th><th>Format</th><th>Jarak</th></tr>";
  for (int i = 0; i < n; i++) {
    h += "<tr><td><a href='/ntrip/use?m=" + esc(mp[i].name) + "'>" + esc(mp[i].name) + "</a></td><td>" + esc(mp[i].ident) + "</td><td>" + esc(mp[i].fmt) + "</td><td>" +
         (mp[i].dist >= 0 ? String(mp[i].dist, 1) + " km" : String("-")) + "</td></tr>";
  }
  h += F("</table></div>"); h += PAGE_END;
  server.send(200, "text/html", h);
}
static void handleNtripUse() {
  if (!portalAuth()) return;
  strncpy(S.ntMount, server.arg("m").c_str(), sizeof(S.ntMount) - 1); S.ntMount[sizeof(S.ntMount) - 1] = 0;
  saveNtrip(); g_ntripReset = true; redirect("/ntrip");
}

static void handleMqtt() {
  if (!portalAuth()) return;
  String h = pageHead("Broker MQTT");
  h += F("<div class='card'><form method='post' action='/mqtt/save'><b>Broker 1 — cloud (flespi)</b>"
         "<p class='muted'>flespi: host <b>mqtt.flespi.io</b>, port <b>8883</b>, TLS dicentang, User = <b>token perangkat</b> (64 karakter), password kosong.</p>");
  h += "Host<input name='h1' value='" + esc(S.m1Host) + "' placeholder='mqtt.flespi.io'>";
  h += "Port<input name='p1' type='number' value='" + String(S.m1Port) + "'>";
  h += String("<label><input type='checkbox' name='t1' value='1' style='width:auto'") + (S.m1Tls ? " checked" : "") + "> TLS</label><br>";
  h += String("<label><input type='checkbox' name='i1' value='1' style='width:auto'") + (S.m1Insecure ? " checked" : "") +
       "> lewati verifikasi sertifikat <span class='muted'>(HANYA untuk uji bila gagal TLS)</span></label><br>";
  h += "User / token<input name='u1' maxlength='95' value='" + esc(S.m1User) + "'>";
  h += F("Password <span class='muted'>(flespi: kosong; kosongkan = tidak diubah)</span><input name='w1' type='password'>"
         "<label><input type='checkbox' name='c1' value='1' style='width:auto'> hapus password tersimpan</label><br>");
  h += F("Laju posisi ke web <select name='hz'>");
  const uint8_t opts[4] = {10, 5, 2, 1};
  for (uint8_t o : opts) h += "<option value='" + String(o) + "'" + (S.pvtHz == o ? " selected" : "") + ">" + String(o) + " Hz</option>";
  h += F("</select><span class='muted'>Kartu SD tetap merekam semua epoch.</span><hr><b>Broker 2 — laptop (fobos_local.py)</b><br>");
  h += "Host / IP laptop<input name='h2' value='" + esc(S.m2Host) + "'>";
  h += "Port<input name='p2' type='number' value='" + String(S.m2Port) + "'>";
  h += "User<input name='u2' value='" + esc(S.m2User) + "'>";
  h += F("Password <span class='muted'>(kosongkan = tidak diubah)</span><input name='w2' type='password'><button>Simpan &amp; sambung ulang</button></form></div>");
  h += PAGE_END;
  server.send(200, "text/html", h);
}
static void cpArg(const char *name, char *dst, size_t cap) { strncpy(dst, server.arg(name).c_str(), cap - 1); dst[cap - 1] = 0; }
static void handleMqttSave() {
  if (!portalAuth()) return;
  cpArg("h1", S.m1Host, sizeof(S.m1Host)); S.m1Port = (uint16_t)server.arg("p1").toInt(); S.m1Tls = server.hasArg("t1");
  S.m1Insecure = server.hasArg("i1");
  { String u = server.arg("u1"); u.trim(); strncpy(S.m1User, u.c_str(), sizeof(S.m1User) - 1); S.m1User[sizeof(S.m1User) - 1] = 0; }
  if (server.hasArg("c1")) S.m1Pass[0] = 0; else if (server.arg("w1").length()) cpArg("w1", S.m1Pass, sizeof(S.m1Pass));
  { long hz = server.arg("hz").toInt(); if (hz == 10 || hz == 5 || hz == 2 || hz == 1) S.pvtHz = (uint8_t)hz; }
  cpArg("h2", S.m2Host, sizeof(S.m2Host)); S.m2Port = (uint16_t)server.arg("p2").toInt();
  cpArg("u2", S.m2User, sizeof(S.m2User)); if (server.arg("w2").length()) cpArg("w2", S.m2Pass, sizeof(S.m2Pass));
  saveMqtt();
  g_broker = 0; g_mqttReset = true;
  redirect("/");
}
static void handleRestart() { if (!portalAuth()) return; msgPage("Mulai ulang", "ESP32 dimulai ulang..."); delay(500); ESP.restart(); }

static void portalBegin() {
  server.on("/", HTTP_GET, handleRoot);
  server.on("/wifi", HTTP_GET, handleWifi);
  server.on("/wifi/save", HTTP_POST, handleWifiSave);
  server.on("/wifi/use", HTTP_GET, handleWifiUse);
  server.on("/wifi/del", HTTP_GET, handleWifiDel);
  server.on("/ntrip", HTTP_GET, handleNtrip);
  server.on("/ntrip/save", HTTP_POST, handleNtripSave);
  server.on("/ntrip/table", HTTP_GET, handleNtripTable);
  server.on("/ntrip/use", HTTP_GET, handleNtripUse);
  server.on("/mqtt", HTTP_GET, handleMqtt);
  server.on("/mqtt/save", HTTP_POST, handleMqttSave);
  server.on("/restart", HTTP_POST, handleRestart);
  server.onNotFound([]() { redirect("/"); });
  server.begin();
}
