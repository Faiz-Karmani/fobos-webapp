// config.h — konfigurasi Fobos Mini v2 yang TIDAK rahasia (boleh masuk GitHub).
// ZED-F9P sudah diatur lewat u-center (pesan, frekuensi, baud): firmware TIDAK mengubah konfigurasi penerima.
#pragma once

#define FW_VERSION "2.0.0"

// ---------------- Pinout ESP32 DevKitC (ESP32-WROOM-32) ----------------
// ZED-F9P UART1 (NMEA GGA/RMC/GST + UBX NAV-PVT keluar; RTCM masuk) <-> ESP32 Serial2
#define PIN_U1_RX       16   // ESP32 RX  <- TX1 ZED-F9P
#define PIN_U1_TX       17   // ESP32 TX  -> RX1 ZED-F9P (RTCM Ina-CORS)
// ZED-F9P UART2 (UBX RAWX + SFRBX keluar) -> ESP32 Serial1 (cukup 1 kabel)
#define PIN_U2_RX       25   // ESP32 RX  <- TX2 ZED-F9P
#define PIN_U2_TX       27   // tidak perlu disambung
// TIMEPULSE ZED-F9P -> sinkron waktu IMU
#define PIN_PPS         34
// ICM-20948 I2C
#define PIN_I2C_SDA     21
#define PIN_I2C_SCL     22
// Kartu microSD (SPI VSPI)
#define PIN_SD_SCK      18
#define PIN_SD_MISO     19
#define PIN_SD_MOSI     23
#define PIN_SD_CS        4
#define PIN_LED          2   // LED biru (bila papan punya)

// ---------------- Baud UART (HARUS sama dengan setelan u-center) ----------------
#define U1_BAUD         230400
#define U2_BAUD         460800
#define PPS_ENABLE      1        // 0 bila kabel TIMEPULSE->GPIO34 tidak dipasang

// ---------------- IMU ----------------
#define IMU_RATE_HZ     200
#define IMU_WEB_HZ      5        // ringkasan IMU ke web (rata-rata 200 ms + indeks getaran per detik)
#define IMU_ACC_FS_G    8
#define IMU_GYR_FS_DPS  500
#define I2C_HZ          400000

// ---------------- Jaringan ----------------
#define MQTT_PREFIX         "fobos"
#define PVT_WEB_HZ          10       // laju awal posisi ke web (10/5/2/1); bisa diubah dari portal/web
#define RAW_STREAM_1HZ      1        // RAWX ke web 1 Hz saat sesi Record (SD tetap salinan penuh UART2)
#define STATUS_PERIOD_MS    1000
#define NTRIP_GGA_PERIOD_MS 10000
#define BROKER_FAILOVER_TRIES 3
#define WIFI_CONNECT_TIMEOUT_MS 15000
#define WIFI_RESCAN_MS      30000    // pindai ulang tiap 30 s bila belum tersambung
#define AP_OFF_DELAY_MS     60000    // AP portal dimatikan 60 s setelah tersambung ke WiFi
#define MAX_SAVED_WIFI      5

// ---------------- SD ----------------
#define SD_SPI_HZ       16000000
#define SD_FLUSH_MS     2000
