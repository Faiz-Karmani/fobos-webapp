# Panduan flespi untuk Pemula — Broker MQTT Cloud Gratis untuk Fobos Mini

Panduan ini ditulis untuk anda yang **belum pernah memakai MQTT atau flespi**. Ikuti langkahnya berurutan. Setiap langkah punya cara memeriksa bahwa langkah itu berhasil, sebelum anda lanjut ke langkah berikutnya.

> **Catatan jujur.** Alamat, port, dan aturan token di panduan ini diambil dari dokumentasi resmi flespi (daftar sumber ada di akhir). Namun **tampilan panel flespi bisa berbeda** dari uraian di sini: letak tombol, nama menu, dan bahasa bisa berubah. Bagian yang **belum bisa diuji langsung** dari server pengembangan diberi tanda ⚠️. Bila tampilan di layar anda tidak sama, cari tombol dengan fungsi yang sama, atau kirimkan tangkapan layarnya.

---

## Daftar isi
1. [Gambaran singkat](#1-gambaran-singkat)
2. [Yang perlu disiapkan](#2-yang-perlu-disiapkan)
3. [Langkah 1 — Membuat akun flespi](#3-langkah-1--membuat-akun-flespi)
4. [Langkah 2 — Membuat dua token](#4-langkah-2--membuat-dua-token)
5. [Langkah 3 — Uji token dengan MQTT Board](#5-langkah-3--uji-token-dengan-mqtt-board)
6. [Langkah 4 — Uji dengan simulator dari laptop (disarankan)](#6-langkah-4--uji-dengan-simulator-dari-laptop-disarankan)
7. [Langkah 5 — Mengisi web app](#7-langkah-5--mengisi-web-app)
8. [Langkah 6 — Mengisi ESP32](#8-langkah-6--mengisi-esp32)
9. [Langkah 7 — Pemeriksaan akhir](#9-langkah-7--pemeriksaan-akhir)
10. [Batas akun gratis dan laju data](#10-batas-akun-gratis-dan-laju-data)
11. [Keamanan token](#11-keamanan-token)
12. [Pemecahan masalah](#12-pemecahan-masalah)
13. [Yang belum diverifikasi](#13-yang-belum-diverifikasi)
14. [Cadangan bila flespi tidak bisa dipakai](#14-cadangan-bila-flespi-tidak-bisa-dipakai)
15. [Sumber](#15-sumber)

---

## 1. Gambaran singkat

**MQTT** adalah cara mengirim pesan kecil lewat internet, mirip grup chat:
- ESP32 **mengirim** (*publish*) posisi ke sebuah "topik", misalnya `fobos/FM01/pvt`.
- Web app **berlangganan** (*subscribe*) ke topik itu, jadi menerima posisinya.
- Di tengahnya ada **broker**, yaitu server yang meneruskan pesan. Dalam panduan ini brokernya **flespi**.

```
 ESP32 Fobos Mini ──(internet, TLS port 8883)──►  mqtt.flespi.io  ◄──(internet, WSS port 443)── Web app di browser
      token PERANGKAT                                 broker                                       token WEB
```

**Mengapa flespi?**
- HiveMQ Cloud Serverless (rencana awal) sudah tidak menerima cluster baru dan akan dihentikan akhir 2026. Pilihan berbayarnya mahal untuk lomba.
- flespi punya **akun gratis** tanpa kartu kredit. Dokumentasi resminya menyebut akun gratis ditujukan untuk **pengujian dan pengembangan** (*testing and development*). Itu cocok untuk prototipe dan demo lomba.

**Hal penting tentang flespi**

| Hal | Nilai |
|---|---|
| Alamat broker | `mqtt.flespi.io` |
| Port untuk ESP32 | **8883** (TLS) |
| Port untuk browser | **443** (WebSocket aman, `wss://`) |
| Username | **token flespi** |
| Password | **kosong** (tidak dipakai) |
| Client ID | bebas, tetapi harus **unik** per sambungan. Firmware dan web app sudah membuatnya acak. |
| Topik | bebas, **kecuali** yang diawali `flespi/`. Fobos memakai `fobos/…`. |
| Ruang topik | Setiap akun punya ruang topik sendiri. Orang lain yang memakai `fobos/#` di akunnya **tidak** melihat data anda. |

---

## 2. Yang perlu disiapkan

- Laptop dengan browser (Chrome atau Edge).
- Alamat email aktif, **atau** akun Google/GitHub untuk login cepat.
- Sebuah tempat aman untuk menyimpan token sementara, misalnya Notepad di laptop sendiri atau pengelola kata sandi. **Jangan** di grup chat dan **jangan** di repo GitHub.
- Paket Fobos Mini (folder ini). Web app sudah terbit di GitHub Pages, atau dapat dibuka lokal lewat `fobos_local.py`.

Waktu yang dibutuhkan: sekitar **20–30 menit** untuk pertama kali.

---

## 3. Langkah 1 — Membuat akun flespi

1. Buka **https://flespi.io** di browser.
2. Pilih cara mendaftar. Menurut dokumentasi flespi, pilihannya:
   - akun sosial: **Google**, **GitHub**, Facebook, atau Bitbucket; atau
   - **email + password**.

   Cara paling mudah: klik **Google** atau **GitHub**, lalu izinkan.
3. Setelah masuk, anda berada di **panel flespi**. ⚠️ Panel mungkin menanyakan **mode tampilan**: *Telematics Hub*, *MQTT Broker*, atau *Both*. Pilih **MQTT Broker**. Mode ini hanya mengatur tampilan dan dapat diganti kapan saja; fungsi broker tetap sama.
4. Bila ada jendela sambutan atau tur, tutup saja.

**Periksa:** anda melihat panel dengan menu di sisi kiri yang memuat **Tokens** dan bagian **MQTT**.

> ⚠️ **Akun gratis dihapus otomatis bila tidak aktif selama 2 bulan** (dokumentasi flespi). Bila jeda antara uji coba dan hari lomba lebih dari 2 bulan, buka panel atau jalankan simulator sesekali agar akun tetap aktif.

---

## 4. Langkah 2 — Membuat dua token

**Token** adalah kunci rahasia sepanjang **64 karakter**. Siapa pun yang memegang token dapat mengirim dan membaca pesan sesuai izin token itu. Karena itu anda membuat **dua token terpisah**:

| Token | Dipasang di | Alasan |
|---|---|---|
| **fobos-perangkat** | ESP32, lewat portal | Hanya tersimpan di memori ESP32 |
| **fobos-web** | Web app di browser | Tersimpan di browser. Bila bocor, cukup token ini yang dihapus; ESP32 tidak perlu diatur ulang. |

Kedua token diberi izin **sempit**: hanya MQTT, dan hanya topik `fobos/#`. Bila token bocor, pemegangnya tidak dapat mengubah pengaturan akun anda.

### 4.1 Membuat token fobos-perangkat

1. Di menu kiri panel, klik **Tokens**.
2. Klik tombol **+** (biasanya bulat merah, di kanan bawah).
3. ⚠️ Bila muncul jendela **pilihan template**, tutup dan buat token kosong. Anda boleh mencentang *"Don't auto-offer templates anymore"* agar jendela ini tidak muncul lagi.
4. Isi formulir token:

   | Kolom | Isi |
   |---|---|
   | **Info / nama** | `fobos-perangkat` |
   | **Access type** | **ACL** |
   | **TTL** dan/atau **Expire** | Lihat catatan di bawah tabel |

   Catatan untuk TTL/Expire:
   - Token **wajib** punya TTL (masa berlaku sejak terakhir dipakai) dan/atau tanggal kedaluwarsa.
   - Isi **TTL panjang, misalnya 1 tahun**. Menurut dokumentasi flespi, TTL dihitung sejak token dibuat **atau terakhir dipakai**. Jadi selama ESP32 rutin tersambung, token tidak kedaluwarsa.
   - ⚠️ Satuan TTL di panel bisa detik atau hari. 1 tahun = 365 hari = 31 536 000 detik.
5. Di bagian **ACL**, tambahkan aturan:
   1. Pada daftar modul atau URI, pilih **`mqtt`**, lalu klik **Add**.
   2. Pada aturan `mqtt` yang muncul, isi **topik `fobos/#`** untuk **publish** dan **subscribe**. ⚠️ Panel mungkin menampilkannya sebagai dua kotak (publish dan subscribe) atau satu kotak dengan pilihan aksi; isi keduanya dengan `fobos/#`.
   3. ⚠️ Bila ada kolom **origins** (pembatas asal halaman web), biarkan kosong untuk token perangkat.
6. Klik **Save**.
7. Token baru muncul di daftar. Buka token itu, lalu **salin kuncinya** (*key*, 64 karakter) dengan tombol salin.
8. Tempel kunci itu di Notepad dengan label `PERANGKAT: …`.

### 4.2 Membuat token fobos-web

Ulangi langkah 4.1 dengan dua perbedaan:
- nama **`fobos-web`**;
- ⚠️ bila ada kolom **origins**, biarkan **kosong**. Bila ingin lebih ketat, isi alamat GitHub Pages anda (misalnya `https://akunanda.github.io`). Bila setelah itu web app gagal tersambung, kosongkan lagi kolom ini.

Salin kuncinya ke Notepad dengan label `WEB: …`.

> **Bila langkah ACL membingungkan:** sebagai jalan pintas untuk **uji coba saja**, anda boleh memilih *Access type* = **Standard** untuk token perangkat. Menurut dokumentasi flespi, token Standard dapat memakai semua fitur, kecuali membuat token lain. Untuk **token web**, tetap usahakan ACL, karena token web tersimpan di browser.

**Periksa:** di menu **Tokens** ada dua token baru, **fobos-perangkat** dan **fobos-web**. Kedua kuncinya sudah tersalin di Notepad.

---

## 5. Langkah 3 — Uji token dengan MQTT Board

**MQTT Board** adalah alat uji di browser buatan flespi. Dengan alat ini anda bisa memastikan token berfungsi **sebelum** menyentuh ESP32.

1. Buka **https://flespi.com/tools/mqtt-board**. Alat yang sama juga ada di panel, bagian **MQTT → MQTT Board**.
2. ⚠️ Buat sambungan baru, biasanya lewat ikon pengaturan atau **+** di pojok:

   | Kolom | Isi |
   |---|---|
   | Host | `wss://mqtt.flespi.io` |
   | Token / Username | kunci **WEB** |
   | Password | kosong |

   Lalu klik **Connect**.
3. Tambahkan **Subscriber** dengan topik **`fobos/#`**.
4. Tambahkan **Publisher**:
   - topik `fobos/UJI/pvt`;
   - isi pesan `{"halo":1}`.

   Klik **Publish**.
5. **Periksa:** pesan `{"halo":1}` muncul di panel Subscriber. Artinya token WEB dapat publish dan subscribe di `fobos/#`. ✔
6. Ulangi dengan kunci **PERANGKAT** bila ingin memastikan token kedua juga benar.
7. Biarkan tab MQTT Board ini terbuka. Tab ini berguna untuk "mengintip" data dari ESP32 di langkah berikutnya.

---

## 6. Langkah 4 — Uji dengan simulator dari laptop (disarankan)

Simulator meniru ESP32. Dengan simulator, anda bisa menguji web app dan flespi **tanpa merakit perangkat**.

1. Buka Command Prompt atau terminal di folder `tools`:
   ```bash
   pip install -r requirements.txt
   python fobos_sim.py --broker mqtts://mqtt.flespi.io:8883 --user KUNCI_PERANGKAT
   ```
   Ganti `KUNCI_PERANGKAT` dengan kunci 64 karakter. **Tanpa tanda kutip dan tanpa `< >`.**
2. **Periksa di terminal:** muncul tulisan tersambung, dan tidak ada galat `Not authorized` atau `Bad user name or password`.
3. **Periksa di MQTT Board** (langkah 3): pesan mulai mengalir di `fobos/FM01/pvt`, `fobos/FM01/imu`, dan `fobos/FM01/status`.
4. Biarkan simulator berjalan, lalu lanjut ke langkah 5. Hentikan simulator dengan `Ctrl + C`.

> Data simulator **sintetis** (bukan pengamatan nyata). Simulator hanya untuk menguji alur aplikasi.

---

## 7. Langkah 5 — Mengisi web app

1. Buka web app anda di `https://<akun>.github.io/<repo>/`.
2. Klik **Pengaturan**, lalu isi:

   | Kolom | Isi |
   |---|---|
   | Broker yang dipakai | **Cloud (flespi, lewat internet)** |
   | URL WebSocket | `wss://mqtt.flespi.io:443` (sudah terisi sebagai bawaan) |
   | Username / token | kunci **WEB** |
   | Password | **kosong** |
   | "ingat token/password di browser ini" | Centang **hanya** di laptop atau HP anda sendiri. Bila tidak dicentang, token hilang saat halaman ditutup dan harus ditempel lagi. |

3. Klik **Simpan**, lalu **Sambungkan**.
4. **Periksa:**
   - lencana di atas berubah menjadi **Tersambung**;
   - bila simulator berjalan, kartu **FM01** muncul, dan titik bergerak di peta.
5. ⚠️ **Bila gagal tersambung** (lencana tetap "Menyambung ulang…" atau muncul "Galat"), ganti URL menjadi **`wss://mqtt.flespi.io:443/mqtt`**, lalu Simpan dan Sambungkan lagi. Dokumentasi flespi tidak menyebut *path* WebSocket. Contoh resmi flespi memakai URL tanpa path, sedangkan sebagian pengguna memakai `/mqtt`. Catat URL mana yang berhasil.
6. Uji tombol **● Record** selama 10–20 detik, lalu **■ Stop Record**. Satu file `.zip` harus terunduh otomatis.

---

## 8. Langkah 6 — Mengisi ESP32

Ada dua cara. **Cara A** (portal) disarankan, karena token tidak pernah masuk ke file kode.

### Cara A — lewat portal ESP32 (disarankan)
1. Nyalakan Fobos Mini. Buka portal:
   - bila ESP32 sudah tersambung WiFi: `http://IP-ESP32/` (IP tampil di Serial Monitor);
   - bila belum: sambungkan HP ke WiFi **`FobosMini-FM01`**, lalu buka `http://192.168.4.1`.
2. Login dengan `PORTAL_USER` / `PORTAL_PASS`.
3. Buka halaman **MQTT**, lalu isi **Broker 1 (cloud)**:

   | Kolom | Isi |
   |---|---|
   | Host | `mqtt.flespi.io` |
   | Port | `8883` |
   | TLS | ✔ dicentang |
   | lewati verifikasi sertifikat | **tidak** dicentang (lihat bagian 12 bila gagal) |
   | User / token | kunci **PERANGKAT** |
   | Password | kosong. Bila sebelumnya pernah terisi (misalnya dari HiveMQ), centang **"hapus password tersimpan"**. |
   | Laju posisi ke web | **10 Hz** untuk demo. Pilih 5 atau 2 Hz bila sinyal hotspot lemah. |

4. Klik **Simpan**. ESP32 menyambung ulang ke broker.
5. **Periksa:**
   - **Serial Monitor (115200)** menampilkan:
     ```
     [MQTT] menyambung ke cloud (mqtt.flespi.io:8883)...
     [MQTT] tersambung
     ```
   - **MQTT Board** menerima `fobos/FM01/status`.
   - **Web app** menampilkan kartu FM01 dengan tanda **online** hijau.

### Cara B — lewat `secrets.h` (nilai awal saat upload)
Isi di `firmware/FobosMini/secrets.h`:
```cpp
#define MQTT1_HOST "mqtt.flespi.io"
#define MQTT1_PORT 8883
#define MQTT1_TLS  1
#define MQTT1_USER "KUNCI_PERANGKAT_64_KARAKTER"
#define MQTT1_PASS ""
```
> ⚠️ `secrets.h` **tidak boleh** diunggah ke GitHub. File ini sudah tercantum di `.gitignore`. Periksa lagi sebelum *commit*.
>
> Isian yang pernah disimpan lewat portal **mengalahkan** `secrets.h`. Bila anda sudah memakai Cara A, Cara B tidak berpengaruh.

### Mengubah laju posisi dari web
Kartu perangkat di web app punya pilihan **posisi 10/5/2/1 Hz**. Perubahan langsung dikirim ke ESP32 dan disimpan. Laju ini hanya berlaku untuk data yang dikirim ke web; **kartu SD tetap menyimpan semua epoch**.

---

## 9. Langkah 7 — Pemeriksaan akhir

- [ ] MQTT Board menerima `fobos/FM01/pvt` sekitar 10 kali per detik.
- [ ] Web app: kartu FM01 **online**, posisi bergerak, status NTRIP **OK**.
- [ ] **Record** lalu **Stop Record**: file `.zip` terunduh. Laporan kelengkapan posisi dan IMU mendekati 100%.
- [ ] Kunci WEB dan PERANGKAT tersimpan aman, **tidak** di GitHub.
- [ ] Tanggal kedaluwarsa/TTL token tercatat dan lewat jauh setelah hari lomba.
- [ ] Rencana cadangan siap: `fobos_local.py` di laptop (lihat PANDUAN.md bagian 8).

---

## 10. Batas akun gratis dan laju data

Batas akun gratis flespi untuk MQTT, menurut halaman harga flespi saat panduan ini ditulis:

| Batas | Nilai akun gratis |
|---|---|
| Sesi MQTT aktif bersamaan | **50** |
| Pesan MQTT | **20 000 per menit** |
| Trafik MQTT/REST | **50 MB per menit** |
| Penyimpanan pesan *retained* | 100 MB |
| Kuota bulanan | tidak disebutkan |

⚠️ Batas ini dapat berubah. Lihat angka terbaru di panel (dashboard) atau di halaman *pricing* flespi.

**Perkiraan pemakaian Fobos** (hitungan, bukan pengukuran), per perangkat:

| Aliran | Pesan per menit |
|---|---|
| Posisi 10 Hz | 600 |
| IMU 5 Hz | 300 |
| Status 1 Hz | 60 |
| Raw UBX (hanya saat Record) | ±120–180 |
| **Total** | **±1 100 pesan/menit** (sekitar 0,5 MB/menit) |

Cara membaca angka ini:
- Setiap **penonton** (browser yang tersambung) menerima pesan yang sama, jadi jumlahnya bertambah kira-kira sebesar itu lagi per penonton.
- Dengan **2 perangkat dan 5 penonton**, totalnya sekitar 2 × 1 100 × (1 + 5) ≈ **13 000 pesan/menit**. Ini masih di bawah 20 000.
- Bila penonton banyak, turunkan laju posisi ke **5 Hz** atau **2 Hz** lewat pilihan di kartu perangkat.

Setiap sambungan memakai satu sesi: setiap ESP32, setiap tab browser, MQTT Board, dan simulator. Batas 50 sesi cukup untuk demo, tetapi **tutup tab yang tidak dipakai**.

---

## 11. Keamanan token

- **Token = kata sandi.** Jangan difoto, jangan dikirim ke grup, jangan di-*commit* ke GitHub.
- Token WEB tersimpan di browser hanya bila "ingat token" dicentang. **Jangan** mencentangnya di komputer umum atau milik panitia.
- **Bila token bocor:** buka panel → **Tokens** → hapus token itu → buat token baru → tempel di tempat yang sama (web app atau portal ESP32). Token lain tidak terpengaruh.
- Token ACL yang dibatasi ke `mqtt` + `fobos/#` tidak dapat dipakai untuk mengubah akun anda. Pemegangnya hanya dapat membaca dan mengirim pesan di topik `fobos/…`. Artinya ia masih bisa melihat posisi dan **mengirim perintah Record/Stop**. Karena itu tetap jaga token.
- Login panel flespi (Google, GitHub, atau email) adalah kunci utama akun anda. Lindungi dengan verifikasi dua langkah di akun Google/GitHub anda.

---

## 12. Pemecahan masalah

### ESP32 (lihat Serial Monitor)

| Pesan | Arti | Tindakan |
|---|---|---|
| `[MQTT] gagal, rc=4` | Username atau password ditolak | Kunci PERANGKAT salah atau terpotong. Tempel ulang di portal; pastikan tidak ada spasi di awal atau akhir. Centang "hapus password tersimpan". |
| `[MQTT] gagal, rc=5` | Tidak diizinkan | Token kedaluwarsa/dihapus, atau ACL tidak mencakup modul `mqtt`. Periksa token di panel. |
| `[MQTT] gagal, rc=-2` | Sambungan TCP/TLS gagal | Lihat tiga kemungkinan di bawah tabel. |
| `[MQTT] gagal, rc=-4` | Waktu habis | Sinyal lemah atau internet lambat. Dekatkan ke hotspot. |
| Tersambung tetapi web tidak menerima data | Topik tidak cocok | Pastikan ACL memakai `fobos/#` (bukan `fobos/*` dan bukan `/fobos/#`). |

Untuk `rc=-2`, ada tiga kemungkinan:
- **(a) Tidak ada internet.** Periksa hotspot.
- **(b) Jam atau sertifikat.** Untuk menguji, centang **"lewati verifikasi sertifikat"** di portal → MQTT, lalu Simpan:
  - Bila setelah itu **tersambung**, masalahnya di sertifikat CA. Kembalikan centang ke kosong setelah menguji, lalu laporkan; daftar sertifikat di `ca_cert.h` perlu ditambah.
  - Bila tetap gagal, masalahnya bukan sertifikat.
- **(c) Port 8883 diblokir** jaringan, misalnya WiFi kampus atau kantor. Pakai hotspot HP.

Kode `rc` di atas adalah kode status library PubSubClient.

### Web app

| Gejala | Tindakan |
|---|---|
| "Isi token flespi … di Pengaturan dulu" | Kolom Username/token kosong. Tempel kunci WEB. |
| Lencana "Menyambung ulang…" terus | ⚠️ Coba URL `wss://mqtt.flespi.io:443/mqtt` (lihat langkah 5). Periksa juga apakah token benar dan apakah kolom *origins* token WEB kosong. |
| "MQTT: Not authorized" / "Bad username or password" | Kunci WEB salah, kedaluwarsa, atau ACL-nya tidak mencakup `fobos/#`. |
| Tersambung, tetapi kartu perangkat tidak muncul | ESP32 belum tersambung (lihat Serial Monitor), atau ESP32 memakai token dari **akun flespi lain**. Kedua token harus dari **akun yang sama**. |
| Posisi tersendat-sendat | Turunkan laju posisi ke 5/2 Hz. SD tetap merekam penuh. |

### Satu Client ID dipakai dua kali
flespi memutus sambungan bergantian bila dua sambungan memakai Client ID yang sama. Firmware dan web app sudah membuat Client ID acak. Masalah ini hanya muncul bila anda mengubah kode.

---

## 13. Yang belum diverifikasi

Server pengembangan **tidak dapat menghubungi `mqtt.flespi.io`** secara langsung, karena jaringannya dibatasi. Karena itu hal-hal berikut perlu anda pastikan sendiri saat langkah 3–6:

1. ⚠️ **Path WebSocket browser:** `wss://mqtt.flespi.io:443` (tanpa path) atau `…/mqtt`.
2. ⚠️ **Sertifikat TLS di ESP32.** `ca_cert.h` sudah memuat **GlobalSign Root CA – R6**, yang dipakai contoh ESP32 resmi flespi, ditambah 8 sertifikat akar umum lainnya. Bila tetap gagal, pakai uji "lewati verifikasi" (bagian 12).
3. ⚠️ **Nama tombol dan kolom di panel flespi** (template, ACL, TTL, origins).
4. Firmware **belum dikompilasi dengan toolchain ESP32 asli**. Bila Arduino IDE memunculkan galat, kirimkan pesannya.

Yang **sudah** diuji: alur web app + simulator + broker lokal (Record → Stop → .zip otomatis, perintah laju 2 Hz, kelengkapan 100%).

---

## 14. Cadangan bila flespi tidak bisa dipakai

- **Hari-H tanpa internet:** pakai broker lokal `fobos_local.py` (PANDUAN.md bagian 8). ESP32 otomatis pindah ke broker 2 setelah sekitar 3 kali gagal.
- **Broker cloud lain:** **EMQX Serverless** gratis (1 juta menit-sesi dan 1 GB per bulan; layanan berhenti sampai bulan berikutnya bila kuota habis).
  - ESP32: port 8883 TLS, dengan username dan password yang dibuat di konsol EMQX.
  - Browser: `wss://<alamat-deployment>:8084/mqtt`.
  - Sertifikat EMQX (DigiCert Global Root G2) sudah termasuk di `ca_cert.h`.

---

## 15. Sumber

- flespi — MQTT broker (host, port, otorisasi token, Client ID, batasan topik): https://flespi.com/mqtt
- flespi — MQTT API (topik bebas kecuali `flespi/`): https://flespi.com/mqtt-api
- flespi KB — Account (cara daftar, akun gratis dihapus setelah 2 bulan tidak aktif, tujuan pengujian/pengembangan): https://flespi.com/kb/account-getting-inside-flespi
- flespi KB — Tokens (Master/Standard/ACL, TTL/expire, ACL MQTT tidak berlaku untuk topik `flespi/`): https://flespi.com/kb/tokens-access-keys-to-flespi-platform
- flespi KB — Menerima pesan via MQTT (token sebagai username, password kosong): https://flespi.com/kb/how-to-consume-telematics-hub-messages-via-mqtt
- flespi — Harga dan batas akun: https://flespi.com/kb/how-flespi-pricing-works
- flespi — MQTT Board: https://flespi.com/tools/mqtt-board
- flespi blog — pilihan mode panel (Telematics Hub / MQTT Broker / Both): https://flespi.com/blog/flespi-panel-split-more-customization-fewer-distractions
- HiveMQ — pengumuman penghentian Serverless (EOL 31-12-2026): dokumentasi HiveMQ Cloud
- EMQX Serverless — batas paket gratis: dokumentasi EMQX Cloud
